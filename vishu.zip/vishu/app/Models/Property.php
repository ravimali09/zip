<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'price',
        'location',
        'address',
        'property_type',
        'furnishing_status',
        'bedrooms',
        'bathrooms',
        'balcony',
        'car_parking',
        'super_area',
        'carpet_area',
        'status',
        'age_of_property',
        'image',
        'description',
    ];

    public function images()
    {
        return $this->hasMany(PropertyImage::class);
    }
}
