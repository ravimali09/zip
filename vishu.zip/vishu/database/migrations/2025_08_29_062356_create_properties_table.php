<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('properties', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->decimal('price', 12, 2);
            $table->string('location');
            $table->text('address')->nullable();
            $table->enum('property_type', ['residential', 'commercial', 'plot']);
            $table->enum('furnishing_status', ['furnished', 'semi-furnished', 'unfurnished']);
            $table->integer('bedrooms')->default(0);
            $table->integer('bathrooms')->default(0);
            $table->integer('balcony')->default(0);
            $table->integer('car_parking')->default(0);
            $table->decimal('super_area', 8, 2)->nullable();
            $table->decimal('carpet_area', 8, 2)->nullable();
            $table->enum('status', ['ready_to_move', 'under_construction']);
            $table->string('age_of_property')->nullable();
            $table->string('image')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('properties');
    }
};
