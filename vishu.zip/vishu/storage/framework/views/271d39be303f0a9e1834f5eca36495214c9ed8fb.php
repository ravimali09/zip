<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
 
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
    <style>
        img:is([sizes="auto" i], [sizes^="auto," i]) {
            contain-intrinsic-size: 3000px 1500px
        }
    </style>

    <title>Vishu Real Estate | Home</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.7/js/bootstrap.min.js" 
    integrity="sha512-zKeerWHHuP3ar7kX2WKBSENzb+GJytFSBL6HrR2nPSR1kOX1qjm+oHooQtbDpDBSITgyl7QXZApvDfDWvKjkUw==" 
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <link rel="icon" type="image/png" href="<?php echo e(url('images/logo.png')); ?>">


    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel="alternate" type="application/rss+xml" title="Construction Company &raquo; Feed" href="https://websitedemos.net/brikly-construction-company-04/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Construction Company &raquo; Comments Feed" href="https://websitedemos.net/brikly-construction-company-04/comments/feed/" />
    <link rel='stylesheet' id='astra-theme-css-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/themes/astra/assets/css/minified/main.min.css?ver=4.11.10' media='all' />
    <style id='astra-theme-css-inline-css'>
        :root {
            --ast-post-nav-space: 0;
            --ast-container-default-xlg-padding: 2.5em;
            --ast-container-default-lg-padding: 2.5em;
            --ast-container-default-slg-padding: 2em;
            --ast-container-default-md-padding: 2.5em;
            --ast-container-default-sm-padding: 2.5em;
            --ast-container-default-xs-padding: 2.4em;
            --ast-container-default-xxs-padding: 1.8em;
            --ast-code-block-background: #ECEFF3;
            --ast-comment-inputs-background: #F9FAFB;
            --ast-normal-container-width: 1200px;
            --ast-narrow-container-width: 750px;
            --ast-blog-title-font-weight: 600;
            --ast-blog-meta-weight: 600;
            --ast-global-color-primary: var(--ast-global-color-4);
            --ast-global-color-secondary: var(--ast-global-color-5);
            --ast-global-color-alternate-background: var(--ast-global-color-6);
            --ast-global-color-subtle-background: var(--ast-global-color-7);
            --ast-bg-style-guide: #F8FAFC;
            --ast-shadow-style-guide: 0px 0px 4px 0 #00000057;
            --ast-global-dark-bg-style: #fff;
            --ast-global-dark-lfs: #fbfbfb;
            --ast-widget-bg-color: #fafafa;
            --ast-wc-container-head-bg-color: #fbfbfb;
            --ast-title-layout-bg: #eeeeee;
            --ast-search-border-color: #e7e7e7;
            --ast-lifter-hover-bg: #e6e6e6;
            --ast-gallery-block-color: #000;
            --srfm-color-input-label: var(--ast-global-color-2);
        }

        html {
            font-size: 100%;
        }

        a {
            color: var(--ast-global-color-2);
        }

        a:hover,
        a:focus {
            color: var(--ast-global-color-3);
        }

        body,
        button,
        input,
        select,
        textarea,
        .ast-button,
        .ast-custom-button {
            font-family: 'Roboto', sans-serif;
            font-weight: 400;
            font-size: 16px;
            font-size: 1rem;
            line-height: var(--ast-body-line-height, 1.65);
        }

        blockquote {
            color: var(--ast-global-color-3);
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .entry-content :where(h1, h2, h3, h4, h5, h6),
        .site-title,
        .site-title a {
            font-family: 'Inter', sans-serif;
            font-weight: 700;
            letter-spacing: -2px;
        }

        .ast-site-identity .site-title a {
            color: var(--ast-global-color-2);
        }

        .site-title {
            font-size: 26px;
            font-size: 1.625rem;
            display: none;
        }

        .site-header .site-description {
            font-size: 15px;
            font-size: 0.9375rem;
            display: none;
        }

        .entry-title {
            font-size: 24px;
            font-size: 1.5rem;
        }

        .ast-blog-single-element.ast-taxonomy-container a {
            font-size: 12px;
            font-size: 0.75rem;
        }

        .ast-blog-meta-container {
            font-size: 14px;
            font-size: 0.875rem;
        }

        .archive .ast-article-post .ast-article-inner,
        .blog .ast-article-post .ast-article-inner,
        .archive .ast-article-post .ast-article-inner:hover,
        .blog .ast-article-post .ast-article-inner:hover {
            border-top-left-radius: 18px;
            border-top-right-radius: 18px;
            border-bottom-right-radius: 18px;
            border-bottom-left-radius: 18px;
            overflow: hidden;
        }

        h1,
        .entry-content :where(h1) {
            font-size: 80px;
            font-size: 5rem;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            line-height: 1.1em;
        }

        h2,
        .entry-content :where(h2) {
            font-size: 54px;
            font-size: 3.375rem;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            line-height: 1.3em;
        }

        h3,
        .entry-content :where(h3) {
            font-size: 42px;
            font-size: 2.625rem;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            line-height: 1.3em;
        }

        h4,
        .entry-content :where(h4) {
            font-size: 32px;
            font-size: 2rem;
            line-height: 1.2em;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            letter-spacing: -1px;
        }

        h5,
        .entry-content :where(h5) {
            font-size: 24px;
            font-size: 1.5rem;
            line-height: 1.2em;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            letter-spacing: -1px;
        }

        h6,
        .entry-content :where(h6) {
            font-size: 20px;
            font-size: 1.25rem;
            line-height: 1.25em;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            letter-spacing: -1px;
        }

        ::selection {
            background-color: var(--ast-global-color-0);
            color: #000000;
        }

        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .entry-title a,
        .entry-content :where(h1, h2, h3, h4, h5, h6) {
            color: var(--ast-global-color-3);
        }

        .tagcloud a:hover,
        .tagcloud a:focus,
        .tagcloud a.current-item {
            color: #ffffff;
            border-color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-2);
        }

        input:focus,
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="url"]:focus,
        input[type="password"]:focus,
        input[type="reset"]:focus,
        input[type="search"]:focus,
        textarea:focus {
            border-color: var(--ast-global-color-2);
        }

        input[type="radio"]:checked,
        input[type=reset],
        input[type="checkbox"]:checked,
        input[type="checkbox"]:hover:checked,
        input[type="checkbox"]:focus:checked,
        input[type=range]::-webkit-slider-thumb {
            border-color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-2);
            box-shadow: none;
        }

        .site-footer a:hover+.post-count,
        .site-footer a:focus+.post-count {
            background: var(--ast-global-color-2);
            border-color: var(--ast-global-color-2);
        }

        .single .nav-links .nav-previous,
        .single .nav-links .nav-next {
            color: var(--ast-global-color-2);
        }

        .entry-meta,
        .entry-meta * {
            line-height: 1.45;
            color: var(--ast-global-color-2);
        }

        .entry-meta a:not(.ast-button):hover,
        .entry-meta a:not(.ast-button):hover *,
        .entry-meta a:not(.ast-button):focus,
        .entry-meta a:not(.ast-button):focus *,
        .page-links>.page-link,
        .page-links .page-link:hover,
        .post-navigation a:hover {
            color: var(--ast-global-color-3);
        }

        #cat option,
        .secondary .calendar_wrap thead a,
        .secondary .calendar_wrap thead a:visited {
            color: var(--ast-global-color-2);
        }

        .secondary .calendar_wrap #today,
        .ast-progress-val span {
            background: var(--ast-global-color-2);
        }

        .secondary a:hover+.post-count,
        .secondary a:focus+.post-count {
            background: var(--ast-global-color-2);
            border-color: var(--ast-global-color-2);
        }

        .calendar_wrap #today>a {
            color: #ffffff;
        }

        .page-links .page-link,
        .single .post-navigation a {
            color: var(--ast-global-color-3);
        }

        .ast-search-menu-icon .search-form button.search-submit {
            padding: 0 4px;
        }

        .ast-search-menu-icon form.search-form {
            padding-right: 0;
        }

        .ast-search-menu-icon.slide-search input.search-field {
            width: 0;
        }

        .ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-form,
        .ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-field:focus {
            transition: all 0.2s;
        }

        .search-form input.search-field:focus {
            outline: none;
        }

        .ast-search-menu-icon .search-form button.search-submit:focus,
        .ast-theme-transparent-header .ast-header-search .ast-dropdown-active .ast-icon,
        .ast-theme-transparent-header .ast-inline-search .search-field:focus .ast-icon {
            color: var(--ast-global-color-1);
        }

        .ast-header-search .slide-search .search-form {
            border: 2px solid var(--ast-global-color-0);
        }

        .ast-header-search .slide-search .search-field {
            background-color: (--ast-global-dark-bg-style);
        }

        .ast-archive-title {
            color: var(--ast-global-color-2);
        }

        .widget-title {
            font-size: 22px;
            font-size: 1.375rem;
            color: var(--ast-global-color-2);
        }

        .single .ast-author-details .author-title {
            color: var(--ast-global-color-3);
        }

        .ast-single-post .entry-content a,
        .ast-comment-content a:not(.ast-comment-edit-reply-wrap a) {
            text-decoration: underline;
        }

        .ast-single-post .elementor-widget-button .elementor-button,
        .ast-single-post .entry-content .uagb-tab a,
        .ast-single-post .entry-content .uagb-ifb-cta a,
        .ast-single-post .entry-content .uabb-module-content a,
        .ast-single-post .entry-content .uagb-post-grid a,
        .ast-single-post .entry-content .uagb-timeline a,
        .ast-single-post .entry-content .uagb-toc__wrap a,
        .ast-single-post .entry-content .uagb-taxomony-box a,
        .entry-content .wp-block-latest-posts>li>a,
        .ast-single-post .entry-content .wp-block-file__button,
        a.ast-post-filter-single,
        .ast-single-post .ast-comment-content .comment-reply-link,
        .ast-single-post .ast-comment-content .comment-edit-link {
            text-decoration: none;
        }

        .ast-search-menu-icon.slide-search a:focus-visible:focus-visible,
        .astra-search-icon:focus-visible,
        #close:focus-visible,
        a:focus-visible,
        .ast-menu-toggle:focus-visible,
        .site .skip-link:focus-visible,
        .wp-block-loginout input:focus-visible,
        .wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper,
        .ast-header-navigation-arrow:focus-visible,
        .ast-orders-table__row .ast-orders-table__cell:focus-visible,
        a#ast-apply-coupon:focus-visible,
        #ast-apply-coupon:focus-visible,
        #close:focus-visible,
        .button.search-submit:focus-visible,
        #search_submit:focus,
        .normal-search:focus-visible,
        .ast-header-account-wrap:focus-visible,
        .astra-cart-drawer-close:focus,
        .ast-single-variation:focus,
        .ast-button:focus {
            outline-style: dotted;
            outline-color: inherit;
            outline-width: thin;
        }

        input:focus,
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="url"]:focus,
        input[type="password"]:focus,
        input[type="reset"]:focus,
        input[type="search"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        .wp-block-search__input:focus,
        [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal:focus,
        .ast-mobile-popup-drawer.active .menu-toggle-close:focus,
        #ast-scroll-top:focus,
        #coupon_code:focus,
        #ast-coupon-code:focus {
            border-style: dotted;
            border-color: inherit;
            border-width: thin;
        }

        input {
            outline: none;
        }

        .ast-logo-title-inline .site-logo-img {
            padding-right: 1em;
        }

        .site-logo-img img {
            transition: all 0.2s linear;
        }

        body .ast-oembed-container * {
            position: absolute;
            top: 0;
            width: 100%;
            height: 100%;
            left: 0;
        }

        body .wp-block-embed-pocket-casts .ast-oembed-container * {
            position: unset;
        }

        .ast-single-post-featured-section+article {
            margin-top: 2em;
        }

        .site-content .ast-single-post-featured-section img {
            width: 100%;
            overflow: hidden;
            object-fit: cover;
        }

        .ast-separate-container .site-content .ast-single-post-featured-section+article {
            margin-top: -80px;
            z-index: 9;
            position: relative;
            border-radius: 4px;
        }

        @media (min-width: 922px) {
            .ast-no-sidebar .site-content .ast-article-image-container--wide {
                margin-left: -120px;
                margin-right: -120px;
                max-width: unset;
                width: unset;
            }

            .ast-left-sidebar .site-content .ast-article-image-container--wide,
            .ast-right-sidebar .site-content .ast-article-image-container--wide {
                margin-left: -10px;
                margin-right: -10px;
            }

            .site-content .ast-article-image-container--full {
                margin-left: calc(-50vw + 50%);
                margin-right: calc(-50vw + 50%);
                max-width: 100vw;
                width: 100vw;
            }

            .ast-left-sidebar .site-content .ast-article-image-container--full,
            .ast-right-sidebar .site-content .ast-article-image-container--full {
                margin-left: -10px;
                margin-right: -10px;
                max-width: inherit;
                width: auto;
            }
        }

        .site>.ast-single-related-posts-container {
            margin-top: 0;
        }

        @media (min-width: 922px) {
            .ast-desktop .ast-container--narrow {
                max-width: var(--ast-narrow-container-width);
                margin: 0 auto;
            }
        }

        .ast-page-builder-template .hentry {
            margin: 0;
        }

        .ast-page-builder-template .site-content>.ast-container {
            max-width: 100%;
            padding: 0;
        }

        .ast-page-builder-template .site .site-content #primary {
            padding: 0;
            margin: 0;
        }

        .ast-page-builder-template .no-results {
            text-align: center;
            margin: 4em auto;
        }

        .ast-page-builder-template .ast-pagination {
            padding: 2em;
        }

        .ast-page-builder-template .entry-header.ast-no-title.ast-no-thumbnail {
            margin-top: 0;
        }

        .ast-page-builder-template .entry-header.ast-header-without-markup {
            margin-top: 0;
            margin-bottom: 0;
        }

        .ast-page-builder-template .entry-header.ast-no-title.ast-no-meta {
            margin-bottom: 0;
        }

        .ast-page-builder-template.single .post-navigation {
            padding-bottom: 2em;
        }

        .ast-page-builder-template.single-post .site-content>.ast-container {
            max-width: 100%;
        }

        .ast-page-builder-template .entry-header {
            margin-top: 2em;
            margin-left: auto;
            margin-right: auto;
        }

        .ast-page-builder-template .ast-archive-description {
            margin: 2em auto 0;
            padding-left: 20px;
            padding-right: 20px;
        }

        .ast-page-builder-template .ast-row {
            margin-left: 0;
            margin-right: 0;
        }

        .single.ast-page-builder-template .entry-header+.entry-content,
        .single.ast-page-builder-template .ast-single-entry-banner+.site-content article .entry-content {
            margin-bottom: 2em;
        }

        @media(min-width: 921px) {

            .ast-page-builder-template.archive.ast-right-sidebar .ast-row article,
            .ast-page-builder-template.archive.ast-left-sidebar .ast-row article {
                padding-left: 0;
                padding-right: 0;
            }
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="url"],
        input[type="password"],
        input[type="search"],
        input[type=reset],
        input[type=tel],
        input[type=date],
        select,
        textarea {
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: 24px;
            width: 100%;
            padding: 12px 16px;
            border-radius: 4px;
            box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
            color: var(--ast-form-input-text, #475569);
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="url"],
        input[type="password"],
        input[type="search"],
        input[type=reset],
        input[type=tel],
        input[type=date],
        select {
            height: 40px;
        }

        input[type="date"] {
            border-width: 1px;
            border-style: solid;
            border-color: var(--ast-border-color);
            background: var(--ast-global-color-secondary, --ast-global-color-5);
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="email"]:focus,
        input[type="url"]:focus,
        input[type="password"]:focus,
        input[type="search"]:focus,
        input[type=reset]:focus,
        input[type="tel"]:focus,
        input[type="date"]:focus,
        select:focus,
        textarea:focus {
            border-color: #046BD2;
            box-shadow: none;
            outline: none;
            color: var(--ast-form-input-focus-text, #475569);
        }

        label,
        legend {
            color: #111827;
            font-size: 14px;
            font-style: normal;
            font-weight: 500;
            line-height: 20px;
        }

        select {
            padding: 6px 10px;
        }

        fieldset {
            padding: 30px;
            border-radius: 4px;
        }

        button,
        .ast-button,
        .button,
        input[type="button"],
        input[type="reset"],
        input[type="submit"] {
            border-radius: 4px;
            box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
        }

        :root {
            --ast-comment-inputs-background: #FFF;
        }

        ::placeholder {
            color: var(--ast-form-field-color, #9CA3AF);
        }

        ::-ms-input-placeholder {
            color: var(--ast-form-field-color, #9CA3AF);
        }

        @media (max-width:921.9px) {
            #ast-desktop-header {
                display: none;
            }
        }

        @media (min-width:922px) {
            #ast-mobile-header {
                display: none;
            }
        }

        .wp-block-buttons.aligncenter {
            justify-content: center;
        }

        @media (max-width:921px) {

            .ast-theme-transparent-header #primary,
            .ast-theme-transparent-header #secondary {
                padding: 0;
            }
        }

        @media (max-width:921px) {
            .ast-plain-container.ast-no-sidebar #primary {
                padding: 0;
            }
        }

        .ast-plain-container.ast-no-sidebar #primary {
            margin-top: 0;
            margin-bottom: 0;
        }

        .wp-block-button.is-style-outline .wp-block-button__link {
            border-color: var(--ast-global-color-0);
        }

        div.wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
        div.wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color) {
            color: var(--ast-global-color-0);
        }

        .wp-block-button.is-style-outline .wp-block-button__link:hover,
        .wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,
        .wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color):hover,
        .wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-1);
            border-color: var(--ast-global-color-1);
        }

        .post-page-numbers.current .page-link,
        .ast-pagination .page-numbers.current {
            color: #000000;
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
        }

        .wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
        .ast-outline-button,
        .wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
            border-color: var(--ast-global-color-0);
            border-top-width: 2px;
            border-right-width: 2px;
            border-bottom-width: 2px;
            border-left-width: 2px;
            font-family: inherit;
            font-weight: 500;
            font-size: 16px;
            font-size: 1rem;
            line-height: 1em;
            padding-top: 13px;
            padding-right: 30px;
            padding-bottom: 13px;
            padding-left: 30px;
        }

        .wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
        .wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color),
        .ast-outline-button {
            color: var(--ast-global-color-0);
        }

        .wp-block-button.is-style-outline .wp-block-button__link:hover,
        .wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,
        .wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color):hover,
        .wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover,
        .ast-outline-button:hover,
        .ast-outline-button:focus,
        .wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:hover,
        .wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:focus {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-1);
            border-color: var(--ast-global-color-1);
        }

        .ast-single-post .entry-content a.ast-outline-button,
        .ast-single-post .entry-content .is-style-outline>.wp-block-button__link {
            text-decoration: none;
        }

        .wp-block-button .wp-block-button__link.wp-element-button.is-style-outline:not(.has-background),
        .wp-block-button.is-style-outline>.wp-block-button__link.wp-element-button:not(.has-background),
        .ast-outline-button {
            background-color: transparent;
        }

        .uagb-buttons-repeater.ast-outline-button {
            border-radius: 9999px;
        }

        @media (max-width:921px) {

            .wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
            .ast-outline-button,
            .wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
                padding-top: 12px;
                padding-right: 28px;
                padding-bottom: 12px;
                padding-left: 28px;
            }
        }

        @media (max-width:544px) {

            .wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
            .ast-outline-button,
            .wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
                padding-top: 10px;
                padding-right: 24px;
                padding-bottom: 10px;
                padding-left: 24px;
            }
        }

        .entry-content[data-ast-blocks-layout]>figure {
            margin-bottom: 1em;
        }

        h1.widget-title {
            font-weight: 700;
        }

        h2.widget-title {
            font-weight: 700;
        }

        h3.widget-title {
            font-weight: 700;
        }

        #page {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .ast-404-layout-1 h1.page-title {
            color: var(--ast-global-color-2);
        }

        .single .post-navigation a {
            line-height: 1em;
            height: inherit;
        }

        .error-404 .page-sub-title {
            font-size: 1.5rem;
            font-weight: inherit;
        }

        .search .site-content .content-area .search-form {
            margin-bottom: 0;
        }

        #page .site-content {
            flex-grow: 1;
        }

        .widget {
            margin-bottom: 1.25em;
        }

        #secondary li {
            line-height: 1.5em;
        }

        #secondary .wp-block-group h2 {
            margin-bottom: 0.7em;
        }

        #secondary h2 {
            font-size: 1.7rem;
        }

        .ast-separate-container .ast-article-post,
        .ast-separate-container .ast-article-single,
        .ast-separate-container .comment-respond {
            padding: 3em;
        }

        .ast-separate-container .ast-article-single .ast-article-single {
            padding: 0;
        }

        .ast-article-single .wp-block-post-template-is-layout-grid {
            padding-left: 0;
        }

        .ast-separate-container .comments-title,
        .ast-narrow-container .comments-title {
            padding: 1.5em 2em;
        }

        .ast-page-builder-template .comment-form-textarea,
        .ast-comment-formwrap .ast-grid-common-col {
            padding: 0;
        }

        .ast-comment-formwrap {
            padding: 0;
            display: inline-flex;
            column-gap: 20px;
            width: 100%;
            margin-left: 0;
            margin-right: 0;
        }

        .comments-area textarea#comment:focus,
        .comments-area textarea#comment:active,
        .comments-area .ast-comment-formwrap input[type="text"]:focus,
        .comments-area .ast-comment-formwrap input[type="text"]:active {
            box-shadow: none;
            outline: none;
        }

        .archive.ast-page-builder-template .entry-header {
            margin-top: 2em;
        }

        .ast-page-builder-template .ast-comment-formwrap {
            width: 100%;
        }

        .entry-title {
            margin-bottom: 0.6em;
        }

        .ast-archive-description p {
            font-size: inherit;
            font-weight: inherit;
            line-height: inherit;
        }

        .ast-separate-container .ast-comment-list li.depth-1,
        .hentry {
            margin-bottom: 1.5em;
        }

        .site-content section.ast-archive-description {
            margin-bottom: 2em;
        }

        @media (min-width:921px) {

            .ast-left-sidebar.ast-page-builder-template #secondary,
            .archive.ast-right-sidebar.ast-page-builder-template .site-main {
                padding-left: 20px;
                padding-right: 20px;
            }
        }

        @media (max-width:544px) {
            .ast-comment-formwrap.ast-row {
                column-gap: 10px;
                display: inline-block;
            }

            #ast-commentform .ast-grid-common-col {
                position: relative;
                width: 100%;
            }
        }

        @media (min-width:1201px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .ast-author-box,
            .ast-separate-container .ast-404-layout-1,
            .ast-separate-container .no-results {
                padding: 3em;
            }
        }

        @media (max-width:921px) {

            .ast-separate-container #primary,
            .ast-separate-container #secondary {
                padding: 1.5em 0;
            }

            #primary,
            #secondary {
                padding: 1.5em 0;
                margin: 0;
            }

            .ast-left-sidebar #content>.ast-container {
                display: flex;
                flex-direction: column-reverse;
                width: 100%;
            }
        }

        @media (min-width:922px) {

            .ast-separate-container.ast-right-sidebar #primary,
            .ast-separate-container.ast-left-sidebar #primary {
                border: 0;
            }

            .search-no-results.ast-separate-container #primary {
                margin-bottom: 4em;
            }
        }

        .elementor-widget-button .elementor-button {
            border-style: solid;
            text-decoration: none;
            border-top-width: 0;
            border-right-width: 0;
            border-left-width: 0;
            border-bottom-width: 0;
        }

        .elementor-button.elementor-size-sm,
        .elementor-button.elementor-size-xs,
        .elementor-button.elementor-size-md,
        .elementor-button.elementor-size-lg,
        .elementor-button.elementor-size-xl,
        .elementor-button {
            padding-top: 15px;
            padding-right: 30px;
            padding-bottom: 15px;
            padding-left: 30px;
        }

        @media (max-width:921px) {

            .elementor-widget-button .elementor-button.elementor-size-sm,
            .elementor-widget-button .elementor-button.elementor-size-xs,
            .elementor-widget-button .elementor-button.elementor-size-md,
            .elementor-widget-button .elementor-button.elementor-size-lg,
            .elementor-widget-button .elementor-button.elementor-size-xl,
            .elementor-widget-button .elementor-button {
                padding-top: 14px;
                padding-right: 28px;
                padding-bottom: 14px;
                padding-left: 28px;
            }
        }

        @media (max-width:544px) {

            .elementor-widget-button .elementor-button.elementor-size-sm,
            .elementor-widget-button .elementor-button.elementor-size-xs,
            .elementor-widget-button .elementor-button.elementor-size-md,
            .elementor-widget-button .elementor-button.elementor-size-lg,
            .elementor-widget-button .elementor-button.elementor-size-xl,
            .elementor-widget-button .elementor-button {
                padding-top: 12px;
                padding-right: 24px;
                padding-bottom: 12px;
                padding-left: 24px;
            }
        }

        .elementor-widget-button .elementor-button {
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
        }

        .elementor-widget-button .elementor-button:hover,
        .elementor-widget-button .elementor-button:focus {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-1);
            border-color: var(--ast-global-color-1);
        }

        .wp-block-button .wp-block-button__link,
        .elementor-widget-button .elementor-button,
        .elementor-widget-button .elementor-button:visited {
            color: var(--ast-global-color-2);
        }

        .elementor-widget-button .elementor-button {
            font-weight: 600;
            font-size: 16px;
            font-size: 1rem;
            line-height: 1em;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        body .elementor-button.elementor-size-sm,
        body .elementor-button.elementor-size-xs,
        body .elementor-button.elementor-size-md,
        body .elementor-button.elementor-size-lg,
        body .elementor-button.elementor-size-xl,
        body .elementor-button {
            font-size: 16px;
            font-size: 1rem;
        }

        .wp-block-button .wp-block-button__link:hover,
        .wp-block-button .wp-block-button__link:focus {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-1);
            border-color: var(--ast-global-color-1);
        }

        .elementor-widget-heading h1.elementor-heading-title {
            line-height: 1.1em;
        }

        .elementor-widget-heading h2.elementor-heading-title {
            line-height: 1.3em;
        }

        .elementor-widget-heading h3.elementor-heading-title {
            line-height: 1.3em;
        }

        .elementor-widget-heading h4.elementor-heading-title {
            line-height: 1.2em;
        }

        .elementor-widget-heading h5.elementor-heading-title {
            line-height: 1.2em;
        }

        .elementor-widget-heading h6.elementor-heading-title {
            line-height: 1.25em;
        }

        .wp-block-button .wp-block-button__link,
        .wp-block-search .wp-block-search__button,
        body .wp-block-file .wp-block-file__button {
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
            color: var(--ast-global-color-2);
            font-family: inherit;
            font-weight: 600;
            line-height: 1em;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-size: 16px;
            font-size: 1rem;
            padding-top: 15px;
            padding-right: 30px;
            padding-bottom: 15px;
            padding-left: 30px;
        }

        .ast-single-post .entry-content .wp-block-button .wp-block-button__link,
        .ast-single-post .entry-content .wp-block-search .wp-block-search__button,
        body .entry-content .wp-block-file .wp-block-file__button {
            text-decoration: none;
        }

        @media (max-width:921px) {

            .wp-block-button .wp-block-button__link,
            .wp-block-search .wp-block-search__button,
            body .wp-block-file .wp-block-file__button {
                padding-top: 14px;
                padding-right: 28px;
                padding-bottom: 14px;
                padding-left: 28px;
            }
        }

        @media (max-width:544px) {

            .wp-block-button .wp-block-button__link,
            .wp-block-search .wp-block-search__button,
            body .wp-block-file .wp-block-file__button {
                padding-top: 12px;
                padding-right: 24px;
                padding-bottom: 12px;
                padding-left: 24px;
            }
        }

        .menu-toggle,
        button,
        .ast-button,
        .ast-custom-button,
        .button,
        input#submit,
        input[type="button"],
        input[type="submit"],
        input[type="reset"],
        #comments .submit,
        .search .search-submit,
        form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
        body .wp-block-file .wp-block-file__button,
        .search .search-submit {
            border-style: solid;
            border-top-width: 0;
            border-right-width: 0;
            border-left-width: 0;
            border-bottom-width: 0;
            color: var(--ast-global-color-2);
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
            padding-top: 15px;
            padding-right: 30px;
            padding-bottom: 15px;
            padding-left: 30px;
            font-family: inherit;
            font-weight: 600;
            font-size: 16px;
            font-size: 1rem;
            line-height: 1em;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        button:focus,
        .menu-toggle:hover,
        button:hover,
        .ast-button:hover,
        .ast-custom-button:hover .button:hover,
        .ast-custom-button:hover,
        input[type=reset]:hover,
        input[type=reset]:focus,
        input#submit:hover,
        input#submit:focus,
        input[type="button"]:hover,
        input[type="button"]:focus,
        input[type="submit"]:hover,
        input[type="submit"]:focus,
        form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:hover,
        form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:focus,
        body .wp-block-file .wp-block-file__button:hover,
        body .wp-block-file .wp-block-file__button:focus {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-1);
            border-color: var(--ast-global-color-1);
        }

        form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button.has-icon {
            padding-top: calc(15px - 3px);
            padding-right: calc(30px - 3px);
            padding-bottom: calc(15px - 3px);
            padding-left: calc(30px - 3px);
        }

        @media (max-width:921px) {

            .menu-toggle,
            button,
            .ast-button,
            .ast-custom-button,
            .button,
            input#submit,
            input[type="button"],
            input[type="submit"],
            input[type="reset"],
            #comments .submit,
            .search .search-submit,
            form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
            body .wp-block-file .wp-block-file__button,
            .search .search-submit {
                padding-top: 14px;
                padding-right: 28px;
                padding-bottom: 14px;
                padding-left: 28px;
            }
        }

        @media (max-width:544px) {

            .menu-toggle,
            button,
            .ast-button,
            .ast-custom-button,
            .button,
            input#submit,
            input[type="button"],
            input[type="submit"],
            input[type="reset"],
            #comments .submit,
            .search .search-submit,
            form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
            body .wp-block-file .wp-block-file__button,
            .search .search-submit {
                padding-top: 12px;
                padding-right: 24px;
                padding-bottom: 12px;
                padding-left: 24px;
            }
        }

        @media (max-width:921px) {
            .ast-mobile-header-stack .main-header-bar .ast-search-menu-icon {
                display: inline-block;
            }

            .ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon {
                margin: 0;
            }

            .ast-comment-avatar-wrap img {
                max-width: 2.5em;
            }

            .ast-comment-meta {
                padding: 0 1.8888em 1.3333em;
            }
        }

        @media (min-width:544px) {
            .ast-container {
                max-width: 100%;
            }
        }

        @media (max-width:544px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .comments-title,
            .ast-separate-container .ast-archive-description {
                padding: 1.5em 1em;
            }

            .ast-separate-container #content .ast-container {
                padding-left: 0.54em;
                padding-right: 0.54em;
            }

            .ast-separate-container .ast-comment-list .bypostauthor {
                padding: .5em;
            }

            .ast-search-menu-icon.ast-dropdown-active .search-field {
                width: 170px;
            }
        }

        #ast-mobile-header .ast-site-header-cart-li a {
            pointer-events: none;
        }

        .ast-separate-container {
            background-color: var(--ast-global-color-5);
            background-image: none;
        }

        @media (max-width:921px) {
            .site-title {
                display: none;
            }

            .site-header .site-description {
                display: none;
            }

            h1,
            .entry-content :where(h1) {
                font-size: 44px;
                font-size: 2.75rem;
            }

            h2,
            .entry-content :where(h2) {
                font-size: 32px;
                font-size: 2rem;
            }

            h3,
            .entry-content :where(h3) {
                font-size: 26px;
                font-size: 1.625rem;
            }

            h4,
            .entry-content :where(h4) {
                font-size: 22px;
                font-size: 1.375rem;
            }

            h5,
            .entry-content :where(h5) {
                font-size: 20px;
                font-size: 1.25rem;
            }

            h6,
            .entry-content :where(h6) {
                font-size: 18px;
                font-size: 1.125rem;
            }
        }

        @media (max-width:544px) {
            .site-title {
                display: none;
            }

            .site-header .site-description {
                display: none;
            }

            h1,
            .entry-content :where(h1) {
                font-size: 36px;
                font-size: 2.25rem;
            }

            h2,
            .entry-content :where(h2) {
                font-size: 30px;
                font-size: 1.875rem;
            }

            h3,
            .entry-content :where(h3) {
                font-size: 26px;
                font-size: 1.625rem;
            }

            h4,
            .entry-content :where(h4) {
                font-size: 24px;
                font-size: 1.5rem;
            }

            h5,
            .entry-content :where(h5) {
                font-size: 20px;
                font-size: 1.25rem;
            }

            h6,
            .entry-content :where(h6) {
                font-size: 18px;
                font-size: 1.125rem;
            }

            header .custom-logo-link img,
            .ast-header-break-point .site-branding img,
            .ast-header-break-point .custom-logo-link img {
                max-width: 80px;
                width: 80px;
            }

            .astra-logo-svg {
                width: 80px;
            }

            .astra-logo-svg:not(.sticky-custom-logo .astra-logo-svg, .transparent-custom-logo .astra-logo-svg, .advanced-header-logo .astra-logo-svg) {
                height: 19px;
            }

            .ast-header-break-point .site-logo-img .custom-mobile-logo-link img {
                max-width: 80px;
            }
        }

        @media (max-width:921px) {
            html {
                font-size: 91.2%;
            }
        }

        @media (max-width:544px) {
            html {
                font-size: 91.2%;
            }
        }

        @media (min-width:922px) {
            .ast-container {
                max-width: 1240px;
            }
        }

        @media (min-width:922px) {
            .site-content .ast-container {
                display: flex;
            }
        }

        @media (max-width:921px) {
            .site-content .ast-container {
                flex-direction: column;
            }
        }

        .entry-content :where(h1, h2, h3, h4, h5, h6) {
            clear: none;
        }

        @media (min-width:922px) {

            .main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover>.sub-menu,
            .main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus>.sub-menu {
                margin-left: -0px;
            }
        }

        .ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
            background: transparent;
        }

        .entry-content li>p {
            margin-bottom: 0;
        }

        .site .comments-area {
            padding-bottom: 2em;
            margin-top: 0em;
        }

        .wp-block-file {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .wp-block-pullquote {
            border: none;
        }

        .wp-block-pullquote blockquote::before {
            content: "\201D";
            font-family: "Helvetica", sans-serif;
            display: flex;
            transform: rotate(180deg);
            font-size: 6rem;
            font-style: normal;
            line-height: 1;
            font-weight: bold;
            align-items: center;
            justify-content: center;
        }

        .has-text-align-right>blockquote::before {
            justify-content: flex-start;
        }

        .has-text-align-left>blockquote::before {
            justify-content: flex-end;
        }

        figure.wp-block-pullquote.is-style-solid-color blockquote {
            max-width: 100%;
            text-align: inherit;
        }

        :root {
            --wp--custom--ast-default-block-top-padding: 3em;
            --wp--custom--ast-default-block-right-padding: 3em;
            --wp--custom--ast-default-block-bottom-padding: 3em;
            --wp--custom--ast-default-block-left-padding: 3em;
            --wp--custom--ast-container-width: 1200px;
            --wp--custom--ast-content-width-size: 1200px;
            --wp--custom--ast-wide-width-size: calc(1200px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));
        }

        .ast-narrow-container {
            --wp--custom--ast-content-width-size: 750px;
            --wp--custom--ast-wide-width-size: 750px;
        }

        @media(max-width: 921px) {
            :root {
                --wp--custom--ast-default-block-top-padding: 3em;
                --wp--custom--ast-default-block-right-padding: 2em;
                --wp--custom--ast-default-block-bottom-padding: 3em;
                --wp--custom--ast-default-block-left-padding: 2em;
            }
        }

        @media(max-width: 544px) {
            :root {
                --wp--custom--ast-default-block-top-padding: 3em;
                --wp--custom--ast-default-block-right-padding: 1.5em;
                --wp--custom--ast-default-block-bottom-padding: 3em;
                --wp--custom--ast-default-block-left-padding: 1.5em;
            }
        }

        .entry-content>.wp-block-group,
        .entry-content>.wp-block-cover,
        .entry-content>.wp-block-columns {
            padding-top: var(--wp--custom--ast-default-block-top-padding);
            padding-right: var(--wp--custom--ast-default-block-right-padding);
            padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);
            padding-left: var(--wp--custom--ast-default-block-left-padding);
        }

        .ast-plain-container.ast-no-sidebar .entry-content>.alignfull,
        .ast-page-builder-template .ast-no-sidebar .entry-content>.alignfull {
            margin-left: calc(-50vw + 50%);
            margin-right: calc(-50vw + 50%);
            max-width: 100vw;
            width: 100vw;
        }

        .ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,
        .ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,
        .ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {
            margin-left: auto;
            margin-right: auto;
            width: 100%;
        }

        [data-ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {
            height: 0;
        }

        [data-ast-blocks-layout] .wp-block-separator {
            margin: 20px auto;
        }

        [data-ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
            max-width: 100px;
        }

        [data-ast-blocks-layout] .wp-block-separator.has-background {
            padding: 0;
        }

        .entry-content[data-ast-blocks-layout]>* {
            max-width: var(--wp--custom--ast-content-width-size);
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content[data-ast-blocks-layout]>.alignwide {
            max-width: var(--wp--custom--ast-wide-width-size);
        }

        .entry-content[data-ast-blocks-layout] .alignfull {
            max-width: none;
        }

        .entry-content .wp-block-columns {
            margin-bottom: 0;
        }

        blockquote {
            margin: 1.5em;
            border-color: rgba(0, 0, 0, 0.05);
        }

        .wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {
            border-left: 5px solid rgba(0, 0, 0, 0.05);
        }

        .has-text-align-right>blockquote,
        blockquote.has-text-align-right {
            border-right: 5px solid rgba(0, 0, 0, 0.05);
        }

        .has-text-align-left>blockquote,
        blockquote.has-text-align-left {
            border-left: 5px solid rgba(0, 0, 0, 0.05);
        }

        .wp-block-site-tagline,
        .wp-block-latest-posts .read-more {
            margin-top: 15px;
        }

        .wp-block-loginout p label {
            display: block;
        }

        .wp-block-loginout p:not(.login-remember):not(.login-submit) input {
            width: 100%;
        }

        .wp-block-loginout input:focus {
            border-color: transparent;
        }

        .wp-block-loginout input:focus {
            outline: thin dotted;
        }

        .entry-content .wp-block-media-text .wp-block-media-text__content {
            padding: 0 0 0 8%;
        }

        .entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
            padding: 0 8% 0 0;
        }

        .entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
            padding: 8%;
        }

        .entry-content .wp-block-cover:not([class*="background-color"]):not(.has-text-color.has-link-color) .wp-block-cover__inner-container,
        .entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-image-text,
        .entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-text,
        .entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover__inner-container,
        .entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-image-text,
        .entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-text {
            color: var(--ast-global-color-primary, var(--ast-global-color-5));
        }

        .wp-block-loginout .login-remember input {
            width: 1.1rem;
            height: 1.1rem;
            margin: 0 5px 4px 0;
            vertical-align: middle;
        }

        .wp-block-latest-posts>li>*:first-child,
        .wp-block-latest-posts:not(.is-grid)>li:first-child {
            margin-top: 0;
        }

        .entry-content>.wp-block-buttons,
        .entry-content>.wp-block-uagb-buttons {
            margin-bottom: 1.5em;
        }

        .wp-block-search__inside-wrapper .wp-block-search__input {
            padding: 0 10px;
            color: var(--ast-global-color-3);
            background: var(--ast-global-color-primary, var(--ast-global-color-5));
            border-color: var(--ast-border-color);
        }

        .wp-block-latest-posts .read-more {
            margin-bottom: 1.5em;
        }

        .wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {
            padding-top: 5px;
            padding-bottom: 5px;
        }

        .wp-block-latest-posts .wp-block-latest-posts__post-date,
        .wp-block-latest-posts .wp-block-latest-posts__post-author {
            font-size: 1rem;
        }

        .wp-block-latest-posts>li>*,
        .wp-block-latest-posts:not(.is-grid)>li {
            margin-top: 12px;
            margin-bottom: 12px;
        }

        .ast-page-builder-template .entry-content[data-ast-blocks-layout]>*,
        .ast-page-builder-template .entry-content[data-ast-blocks-layout]>.alignfull:not(.wp-block-group):not(.uagb-is-root-container)>* {
            max-width: none;
        }

        .ast-page-builder-template .entry-content[data-ast-blocks-layout]>.alignwide:not(.uagb-is-root-container)>* {
            max-width: var(--wp--custom--ast-wide-width-size);
        }

        .ast-page-builder-template .entry-content[data-ast-blocks-layout]>.inherit-container-width>*,
        .ast-page-builder-template .entry-content[data-ast-blocks-layout]>*:not(.wp-block-group):not(.uagb-is-root-container)>*,
        .entry-content[data-ast-blocks-layout]>.wp-block-cover .wp-block-cover__inner-container {
            max-width: none;
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content[data-ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {
            width: auto;
        }

        @media(max-width: 1200px) {

            .ast-separate-container .entry-content>.alignfull,
            .ast-separate-container .entry-content[data-ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content[data-ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content .alignfull {
                margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
                margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
            }
        }

        @media(min-width: 1201px) {
            .ast-separate-container .entry-content>.alignfull {
                margin-left: calc(-1 * var(--ast-container-default-xlg-padding));
                margin-right: calc(-1 * var(--ast-container-default-xlg-padding));
            }

            .ast-separate-container .entry-content[data-ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content[data-ast-blocks-layout]>.alignwide {
                margin-left: auto;
                margin-right: auto;
            }
        }

        @media(min-width: 921px) {

            .ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)),
            .ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)) {
                max-width: calc(var(--wp--custom--ast-content-width-size) + 80px);
            }

            .ast-plain-container.ast-right-sidebar .entry-content[data-ast-blocks-layout] .alignfull,
            .ast-plain-container.ast-left-sidebar .entry-content[data-ast-blocks-layout] .alignfull {
                margin-left: -60px;
                margin-right: -60px;
            }
        }

        @media(min-width: 544px) {
            .entry-content>.alignleft {
                margin-right: 20px;
            }

            .entry-content>.alignright {
                margin-left: 20px;
            }
        }

        @media (max-width:544px) {
            .wp-block-columns .wp-block-column:not(:last-child) {
                margin-bottom: 20px;
            }

            .wp-block-latest-posts {
                margin: 0;
            }
        }

        @media(max-width: 600px) {

            .entry-content .wp-block-media-text .wp-block-media-text__content,
            .entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
                padding: 8% 0 0;
            }

            .entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
                padding: 8%;
            }
        }

        .ast-page-builder-template .entry-header {
            padding-left: 0;
        }

        .ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {
            max-width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content ul,
        .entry-content ol {
            padding: revert;
            margin: revert;
            padding-left: 20px;
        }

        :root .has-ast-global-color-0-color {
            color: var(--ast-global-color-0);
        }

        :root .has-ast-global-color-0-background-color {
            background-color: var(--ast-global-color-0);
        }

        :root .wp-block-button .has-ast-global-color-0-color {
            color: var(--ast-global-color-0);
        }

        :root .wp-block-button .has-ast-global-color-0-background-color {
            background-color: var(--ast-global-color-0);
        }

        :root .has-ast-global-color-1-color {
            color: var(--ast-global-color-1);
        }

        :root .has-ast-global-color-1-background-color {
            background-color: var(--ast-global-color-1);
        }

        :root .wp-block-button .has-ast-global-color-1-color {
            color: var(--ast-global-color-1);
        }

        :root .wp-block-button .has-ast-global-color-1-background-color {
            background-color: var(--ast-global-color-1);
        }

        :root .has-ast-global-color-2-color {
            color: var(--ast-global-color-2);
        }

        :root .has-ast-global-color-2-background-color {
            background-color: var(--ast-global-color-2);
        }

        :root .wp-block-button .has-ast-global-color-2-color {
            color: var(--ast-global-color-2);
        }

        :root .wp-block-button .has-ast-global-color-2-background-color {
            background-color: var(--ast-global-color-2);
        }

        :root .has-ast-global-color-3-color {
            color: var(--ast-global-color-3);
        }

        :root .has-ast-global-color-3-background-color {
            background-color: var(--ast-global-color-3);
        }

        :root .wp-block-button .has-ast-global-color-3-color {
            color: var(--ast-global-color-3);
        }

        :root .wp-block-button .has-ast-global-color-3-background-color {
            background-color: var(--ast-global-color-3);
        }

        :root .has-ast-global-color-4-color {
            color: var(--ast-global-color-4);
        }

        :root .has-ast-global-color-4-background-color {
            background-color: var(--ast-global-color-4);
        }

        :root .wp-block-button .has-ast-global-color-4-color {
            color: var(--ast-global-color-4);
        }

        :root .wp-block-button .has-ast-global-color-4-background-color {
            background-color: var(--ast-global-color-4);
        }

        :root .has-ast-global-color-5-color {
            color: var(--ast-global-color-5);
        }

        :root .has-ast-global-color-5-background-color {
            background-color: var(--ast-global-color-5);
        }

        :root .wp-block-button .has-ast-global-color-5-color {
            color: var(--ast-global-color-5);
        }

        :root .wp-block-button .has-ast-global-color-5-background-color {
            background-color: var(--ast-global-color-5);
        }

        :root .has-ast-global-color-6-color {
            color: var(--ast-global-color-6);
        }

        :root .has-ast-global-color-6-background-color {
            background-color: var(--ast-global-color-6);
        }

        :root .wp-block-button .has-ast-global-color-6-color {
            color: var(--ast-global-color-6);
        }

        :root .wp-block-button .has-ast-global-color-6-background-color {
            background-color: var(--ast-global-color-6);
        }

        :root .has-ast-global-color-7-color {
            color: var(--ast-global-color-7);
        }

        :root .has-ast-global-color-7-background-color {
            background-color: var(--ast-global-color-7);
        }

        :root .wp-block-button .has-ast-global-color-7-color {
            color: var(--ast-global-color-7);
        }

        :root .wp-block-button .has-ast-global-color-7-background-color {
            background-color: var(--ast-global-color-7);
        }

        :root .has-ast-global-color-8-color {
            color: var(--ast-global-color-8);
        }

        :root .has-ast-global-color-8-background-color {
            background-color: var(--ast-global-color-8);
        }

        :root .wp-block-button .has-ast-global-color-8-color {
            color: var(--ast-global-color-8);
        }

        :root .wp-block-button .has-ast-global-color-8-background-color {
            background-color: var(--ast-global-color-8);
        }

        :root {
            --ast-global-color-0: #cbff54;
            --ast-global-color-1: #b4f625;
            --ast-global-color-2: #063231;
            --ast-global-color-3: #495b55;
            --ast-global-color-4: #f6f7f7;
            --ast-global-color-5: #ffffff;
            --ast-global-color-6: #e0e7e3;
            --ast-global-color-7: #D1D5DB;
            --ast-global-color-8: #033231;
        }

        :root {
            --ast-border-color: var(--ast-global-color-7);
        }

        .ast-single-entry-banner {
            -js-display: flex;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            position: relative;
            background: var(--ast-title-layout-bg);
        }

        .ast-single-entry-banner[data-banner-layout="layout-1"] {
            max-width: 1200px;
            background: inherit;
            padding: 20px 0;
        }

        .ast-single-entry-banner[data-banner-width-type="custom"] {
            margin: 0 auto;
            width: 100%;
        }

        .ast-single-entry-banner+.site-content .entry-header {
            margin-bottom: 0;
        }

        .site .ast-author-avatar {
            --ast-author-avatar-size: ;
        }

        a.ast-underline-text {
            text-decoration: underline;
        }

        .ast-container>.ast-terms-link {
            position: relative;
            display: block;
        }

        a.ast-button.ast-badge-tax {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: inherit;
        }

        header.entry-header:not(.related-entry-header) .entry-title {
            font-weight: 600;
            font-size: 32px;
            font-size: 2rem;
        }

        header.entry-header:not(.related-entry-header)>*:not(:last-child) {
            margin-bottom: 10px;
        }

        header.entry-header:not(.related-entry-header) .post-thumb-img-content {
            text-align: center;
        }

        header.entry-header:not(.related-entry-header) .post-thumb img,
        .ast-single-post-featured-section.post-thumb img {
            aspect-ratio: 16/9;
            width: 100%;
            height: 100%;
        }

        .ast-archive-entry-banner {
            -js-display: flex;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            position: relative;
            background: var(--ast-title-layout-bg);
        }

        .ast-archive-entry-banner[data-banner-width-type="custom"] {
            margin: 0 auto;
            width: 100%;
        }

        .ast-archive-entry-banner[data-banner-layout="layout-1"] {
            background: inherit;
            padding: 20px 0;
            text-align: left;
        }

        body.archive .ast-archive-description {
            max-width: 1200px;
            width: 100%;
            text-align: left;
            padding-top: 3em;
            padding-right: 3em;
            padding-bottom: 3em;
            padding-left: 3em;
        }

        body.archive .ast-archive-description .ast-archive-title,
        body.archive .ast-archive-description .ast-archive-title * {
            font-weight: 600;
            font-size: 32px;
            font-size: 2rem;
        }

        body.archive .ast-archive-description>*:not(:last-child) {
            margin-bottom: 10px;
        }

        @media (max-width:921px) {
            body.archive .ast-archive-description {
                text-align: left;
            }
        }

        @media (max-width:544px) {
            body.archive .ast-archive-description {
                text-align: left;
            }
        }

        .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
            width: 150px;
        }

        .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
            max-width: 150px;
            width: 150px;
        }

        @media (max-width:921px) {
            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
                width: 120px;
            }

            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
                max-width: 120px;
                width: 120px;
            }
        }

        @media (max-width:543px) {
            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
                width: 100px;
            }

            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
                max-width: 100px;
                width: 100px;
            }
        }

        @media (min-width:921px) {
            .ast-theme-transparent-header #masthead {
                position: absolute;
                left: 0;
                right: 0;
            }

            .ast-theme-transparent-header .main-header-bar,
            .ast-theme-transparent-header.ast-header-break-point .main-header-bar {
                background: none;
            }

            body.elementor-editor-active.ast-theme-transparent-header #masthead,
            .fl-builder-edit .ast-theme-transparent-header #masthead,
            body.vc_editor.ast-theme-transparent-header #masthead,
            body.brz-ed.ast-theme-transparent-header #masthead {
                z-index: 0;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
                display: none;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
                display: inline-block;
            }

            .ast-theme-transparent-header .ast-above-header,
            .ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
                background-image: none;
                background-color: transparent;
            }

            .ast-theme-transparent-header .ast-below-header,
            .ast-theme-transparent-header .ast-below-header.ast-below-header-bar {
                background-image: none;
                background-color: transparent;
            }
        }

        .ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu .menu-link,
        .ast-theme-transparent-header .main-header-menu .menu-item .sub-menu .menu-link {
            background-color: transparent;
        }

        @media (max-width:921px) {
            .ast-theme-transparent-header #masthead {
                position: absolute;
                left: 0;
                right: 0;
            }

            .ast-theme-transparent-header .main-header-bar,
            .ast-theme-transparent-header.ast-header-break-point .main-header-bar {
                background: none;
            }

            body.elementor-editor-active.ast-theme-transparent-header #masthead,
            .fl-builder-edit .ast-theme-transparent-header #masthead,
            body.vc_editor.ast-theme-transparent-header #masthead,
            body.brz-ed.ast-theme-transparent-header #masthead {
                z-index: 0;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
                display: none;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
                display: inline-block;
            }

            .ast-theme-transparent-header .ast-above-header,
            .ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
                background-image: none;
                background-color: transparent;
            }

            .ast-theme-transparent-header .ast-below-header,
            .ast-theme-transparent-header .ast-below-header.ast-below-header-bar {
                background-image: none;
                background-color: transparent;
            }
        }

        .ast-theme-transparent-header #ast-desktop-header>.ast-main-header-wrap>.main-header-bar,
        .ast-theme-transparent-header.ast-header-break-point #ast-mobile-header>.ast-main-header-wrap>.main-header-bar {
            border-bottom-width: 0px;
            border-bottom-style: solid;
        }

        .ast-breadcrumbs .trail-browse,
        .ast-breadcrumbs .trail-items,
        .ast-breadcrumbs .trail-items li {
            display: inline-block;
            margin: 0;
            padding: 0;
            border: none;
            background: inherit;
            text-indent: 0;
            text-decoration: none;
        }

        .ast-breadcrumbs .trail-browse {
            font-size: inherit;
            font-style: inherit;
            font-weight: inherit;
            color: inherit;
        }

        .ast-breadcrumbs .trail-items {
            list-style: none;
        }

        .trail-items li::after {
            padding: 0 0.3em;
            content: "\00bb";
        }

        .trail-items li:last-of-type::after {
            display: none;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .entry-content :where(h1, h2, h3, h4, h5, h6) {
            color: var(--ast-global-color-2);
        }

        .entry-title a {
            color: var(--ast-global-color-2);
        }

        @media (max-width:921px) {

            .ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row>*:first-child,
            .ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row>*:last-child {
                grid-column: 1 / -1;
            }
        }

        @media (max-width:544px) {

            .ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row>*:first-child,
            .ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row>*:last-child {
                grid-column: 1 / -1;
            }
        }

        @media (max-width:544px) {
            .ast-builder-layout-element .ast-site-identity {
                margin-top: 24px;
                margin-bottom: 24px;
                margin-left: 24px;
                margin-right: 24px;
            }
        }

        .ast-builder-layout-element[data-section="title_tagline"] {
            display: flex;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
                display: flex;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
                display: flex;
            }
        }

        [data-section*="section-hb-button-"] .menu-link {
            display: none;
        }

        .ast-header-button-1 .ast-custom-button {
            border-top-left-radius: 40px;
            border-top-right-radius: 40px;
            border-bottom-right-radius: 40px;
            border-bottom-left-radius: 40px;
        }

        .ast-header-button-1[data-section*="section-hb-button-"] .ast-builder-button-wrap .ast-custom-button {
            padding-top: 15px;
            padding-bottom: 15px;
            padding-left: 30px;
            padding-right: 30px;
        }

        .ast-header-button-1[data-section="section-hb-button-1"] {
            display: flex;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"] {
                display: flex;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"] {
                display: flex;
            }
        }

        .ast-builder-menu-1 {
            font-family: inherit;
            font-weight: inherit;
        }

        .ast-builder-menu-1 .menu-item>.menu-link {
            color: #ffffff;
        }

        .ast-builder-menu-1 .menu-item>.ast-menu-toggle {
            color: #ffffff;
        }

        .ast-builder-menu-1 .menu-item:hover>.menu-link,
        .ast-builder-menu-1 .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-1 .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-1 .menu-item.current-menu-item>.menu-link,
        .ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
        .ast-builder-menu-1 .current-menu-ancestor>.menu-link {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-1 .menu-item.current-menu-item>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-1 .sub-menu,
        .ast-builder-menu-1 .inline-on-mobile .sub-menu {
            border-top-width: 2px;
            border-bottom-width: 0px;
            border-right-width: 0px;
            border-left-width: 0px;
            border-color: #ffffff;
            border-style: solid;
        }

        .ast-builder-menu-1 .sub-menu .sub-menu {
            top: -2px;
        }

        .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
        .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
            margin-top: 0px;
        }

        .ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu:before,
        .ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper:before {
            height: calc(0px + 2px + 5px);
        }

        .ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link {
            border-style: none;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }

            .ast-builder-menu-1 .inline-on-mobile .menu-item.menu-item-has-children>.ast-menu-toggle {
                right: -15px;
            }

            .ast-builder-menu-1 .menu-item-has-children>.menu-link:after {
                content: unset;
            }

            .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
            .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
                margin-top: 0;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }

            .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
            .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
                margin-top: 0;
            }
        }

        .ast-builder-menu-1 {
            display: flex;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-builder-menu-1 {
                display: flex;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-builder-menu-1 {
                display: flex;
            }
        }

        .ast-desktop .ast-menu-hover-style-underline>.menu-item>.menu-link:before,
        .ast-desktop .ast-menu-hover-style-overline>.menu-item>.menu-link:before {
            content: "";
            position: absolute;
            width: 100%;
            right: 50%;
            height: 1px;
            background-color: transparent;
            transform: scale(0, 0) translate(-50%, 0);
            transition: transform .3s ease-in-out, color .0s ease-in-out;
        }

        .ast-desktop .ast-menu-hover-style-underline>.menu-item:hover>.menu-link:before,
        .ast-desktop .ast-menu-hover-style-overline>.menu-item:hover>.menu-link:before {
            width: calc(100% - 1.2em);
            background-color: currentColor;
            transform: scale(1, 1) translate(50%, 0);
        }

        .ast-desktop .ast-menu-hover-style-underline>.menu-item>.menu-link:before {
            bottom: 0;
        }

        .ast-desktop .ast-menu-hover-style-overline>.menu-item>.menu-link:before {
            top: 0;
        }

        .ast-desktop .ast-menu-hover-style-zoom>.menu-item>.menu-link:hover {
            transition: all .3s ease;
            transform: scale(1.2);
        }

        .footer-widget-area.widget-area.site-footer-focus-item {
            width: auto;
        }

        .ast-footer-row-inline .footer-widget-area.widget-area.site-footer-focus-item {
            width: 100%;
        }

        .elementor-widget-heading .elementor-heading-title {
            margin: 0;
        }

        .elementor-page .ast-menu-toggle {
            color: unset !important;
            background: unset !important;
        }

        .elementor-post.elementor-grid-item.hentry {
            margin-bottom: 0;
        }

        .woocommerce div.product .elementor-element.elementor-products-grid .related.products ul.products li.product,
        .elementor-element .elementor-wc-products .woocommerce[class*='columns-'] ul.products li.product {
            width: auto;
            margin: 0;
            float: none;
        }

        .elementor-toc__list-wrapper {
            margin: 0;
        }

        body .elementor hr {
            background-color: #ccc;
            margin: 0;
        }

        .ast-left-sidebar .elementor-section.elementor-section-stretched,
        .ast-right-sidebar .elementor-section.elementor-section-stretched {
            max-width: 100%;
            left: 0 !important;
        }

        .elementor-posts-container [CLASS*="ast-width-"] {
            width: 100%;
        }

        .elementor-template-full-width .ast-container {
            display: block;
        }

        .elementor-screen-only,
        .screen-reader-text,
        .screen-reader-text span,
        .ui-helper-hidden-accessible {
            top: 0 !important;
        }

        @media (max-width:544px) {
            .elementor-element .elementor-wc-products .woocommerce[class*="columns-"] ul.products li.product {
                width: auto;
                margin: 0;
            }

            .elementor-element .woocommerce .woocommerce-result-count {
                float: none;
            }
        }

        .ast-header-button-1 .ast-custom-button {
            box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0.1);
        }

        .ast-desktop .ast-mega-menu-enabled .ast-builder-menu-1 div:not(.astra-full-megamenu-wrapper) .sub-menu,
        .ast-builder-menu-1 .inline-on-mobile .sub-menu,
        .ast-desktop .ast-builder-menu-1 .astra-full-megamenu-wrapper,
        .ast-desktop .ast-builder-menu-1 .menu-item .sub-menu {
            box-shadow: 0px 4px 10px -2px rgba(0, 0, 0, 0.1);
        }

        .ast-desktop .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
            max-width: 35%;
        }

        @media (max-width:921px) {
            .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
                max-width: 90%;
            }
        }

        @media (max-width:544px) {
            .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
                max-width: 90%;
            }
        }

        .ast-header-break-point .main-header-bar {
            border-bottom-width: 1px;
        }

        @media (min-width:922px) {
            .main-header-bar {
                border-bottom-width: 1px;
            }
        }

        .main-header-menu .menu-item,
        #astra-footer-menu .menu-item,
        .main-header-bar .ast-masthead-custom-menu-items {
            -js-display: flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -moz-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -moz-box-orient: vertical;
            -moz-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .main-header-menu>.menu-item>.menu-link,
        #astra-footer-menu>.menu-item>.menu-link {
            height: 100%;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -moz-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -js-display: flex;
            display: flex;
        }

        .ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg {
            top: .2em;
            margin-top: 0px;
            margin-left: 0px;
            width: .65em;
            transform: translate(0, -2px) rotateZ(270deg);
        }

        .ast-mobile-popup-content .ast-submenu-expanded>.ast-menu-toggle {
            transform: rotateX(180deg);
            overflow-y: auto;
        }

        @media (min-width:922px) {
            .ast-builder-menu .main-navigation>ul>li:last-child a {
                margin-right: 0;
            }
        }

        .ast-separate-container .ast-article-inner {
            background-color: var(--ast-global-color-4);
            background-image: none;
        }

        @media (max-width:921px) {
            .ast-separate-container .ast-article-inner {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        @media (max-width:544px) {
            .ast-separate-container .ast-article-inner {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        .ast-separate-container .ast-article-single:not(.ast-related-post),
        .ast-separate-container .error-404,
        .ast-separate-container .no-results,
        .single.ast-separate-container .site-main .ast-author-meta,
        .ast-separate-container .related-posts-title-wrapper,
        .ast-separate-container .comments-count-wrapper,
        .ast-box-layout.ast-plain-container .site-content,
        .ast-padded-layout.ast-plain-container .site-content,
        .ast-separate-container .ast-archive-description,
        .ast-separate-container .comments-area {
            background-color: var(--ast-global-color-4);
            background-image: none;
        }

        @media (max-width:921px) {

            .ast-separate-container .ast-article-single:not(.ast-related-post),
            .ast-separate-container .error-404,
            .ast-separate-container .no-results,
            .single.ast-separate-container .site-main .ast-author-meta,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container .comments-count-wrapper,
            .ast-box-layout.ast-plain-container .site-content,
            .ast-padded-layout.ast-plain-container .site-content,
            .ast-separate-container .ast-archive-description {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        @media (max-width:544px) {

            .ast-separate-container .ast-article-single:not(.ast-related-post),
            .ast-separate-container .error-404,
            .ast-separate-container .no-results,
            .single.ast-separate-container .site-main .ast-author-meta,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container .comments-count-wrapper,
            .ast-box-layout.ast-plain-container .site-content,
            .ast-padded-layout.ast-plain-container .site-content,
            .ast-separate-container .ast-archive-description {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        .ast-separate-container.ast-two-container #secondary .widget {
            background-color: var(--ast-global-color-4);
            background-image: none;
        }

        @media (max-width:921px) {
            .ast-separate-container.ast-two-container #secondary .widget {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        @media (max-width:544px) {
            .ast-separate-container.ast-two-container #secondary .widget {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        .ast-plain-container,
        .ast-page-builder-template {
            background-color: var(--ast-global-color-4);
            background-image: none;
        }

        @media (max-width:921px) {

            .ast-plain-container,
            .ast-page-builder-template {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        @media (max-width:544px) {

            .ast-plain-container,
            .ast-page-builder-template {
                background-color: var(--ast-global-color-4);
                background-image: none;
            }
        }

        #ast-scroll-top {
            display: none;
            position: fixed;
            text-align: center;
            cursor: pointer;
            z-index: 99;
            width: 2.1em;
            height: 2.1em;
            line-height: 2.1;
            color: #ffffff;
            border-radius: 2px;
            content: "";
            outline: inherit;
        }

        @media (min-width: 769px) {
            #ast-scroll-top {
                content: "769";
            }
        }

        #ast-scroll-top .ast-icon.icon-arrow svg {
            margin-left: 0px;
            vertical-align: middle;
            transform: translate(0, -20%) rotate(180deg);
            width: 1.6em;
        }

        .ast-scroll-to-top-right {
            right: 30px;
            bottom: 30px;
        }

        .ast-scroll-to-top-left {
            left: 30px;
            bottom: 30px;
        }

        #ast-scroll-top {
            background-color: var(--ast-global-color-2);
            font-size: 15px;
        }

        @media (max-width:921px) {
            #ast-scroll-top .ast-icon.icon-arrow svg {
                width: 1em;
            }
        }

        .ast-mobile-header-content>*,
        .ast-desktop-header-content>* {
            padding: 10px 0;
            height: auto;
        }

        .ast-mobile-header-content>*:first-child,
        .ast-desktop-header-content>*:first-child {
            padding-top: 10px;
        }

        .ast-mobile-header-content>.ast-builder-menu,
        .ast-desktop-header-content>.ast-builder-menu {
            padding-top: 0;
        }

        .ast-mobile-header-content>*:last-child,
        .ast-desktop-header-content>*:last-child {
            padding-bottom: 0;
        }

        .ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,
        .ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {
            width: 100%;
        }

        .ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded>.ast-menu-toggle::before {
            transform: rotateX(180deg);
        }

        #ast-desktop-header .ast-desktop-header-content,
        .ast-mobile-header-content .ast-search-icon,
        .ast-desktop-header-content .ast-search-icon,
        .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {
            display: none;
        }

        .ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,
        .ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {
            display: block;
        }

        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item .menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item .menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item .menu-item>.sub-menu {
            opacity: 1;
            visibility: visible;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {
            width: unset;
            margin: unset;
        }

        .ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle,
        .ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle {
            left: calc(20px - 0.907em);
            right: auto;
        }

        .ast-mobile-header-content .ast-search-menu-icon,
        .ast-mobile-header-content .ast-search-menu-icon.slide-search,
        .ast-desktop-header-content .ast-search-menu-icon,
        .ast-desktop-header-content .ast-search-menu-icon.slide-search {
            width: 100%;
            position: relative;
            display: block;
            right: auto;
            transform: none;
        }

        .ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,
        .ast-mobile-header-content .ast-search-menu-icon .search-form,
        .ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,
        .ast-desktop-header-content .ast-search-menu-icon .search-form {
            right: 0;
            visibility: visible;
            opacity: 1;
            position: relative;
            top: auto;
            transform: none;
            padding: 0;
            display: block;
            overflow: hidden;
        }

        .ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,
        .ast-mobile-header-content .ast-search-menu-icon .search-field,
        .ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,
        .ast-desktop-header-content .ast-search-menu-icon .search-field {
            width: 100%;
            padding-right: 5.5em;
        }

        .ast-mobile-header-content .ast-search-menu-icon .search-submit,
        .ast-desktop-header-content .ast-search-menu-icon .search-submit {
            display: block;
            position: absolute;
            height: 100%;
            top: 0;
            right: 0;
            padding: 0 1em;
            border-radius: 0;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {
            padding-left: 30px;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {
            padding-left: 40px;
        }

        .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
            background-color: #ffffff;
            ;
        }

        .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-desktop-header-content {
            background-color: #ffffff;
            ;
        }

        .ast-mobile-popup-content>*,
        .ast-mobile-header-content>*,
        .ast-desktop-popup-content>*,
        .ast-desktop-header-content>* {
            padding-top: 0px;
            padding-bottom: 0px;
        }

        .content-align-flex-start .ast-builder-layout-element {
            justify-content: flex-start;
        }

        .content-align-flex-start .main-header-menu {
            text-align: left;
        }

        .ast-desktop-header-content,
        .ast-mobile-header-content {
            position: absolute;
            width: 100%;
        }

        .ast-mobile-popup-drawer.active .menu-toggle-close {
            color: #3a3a3a;
        }

        .ast-mobile-header-wrap .ast-primary-header-bar,
        .ast-primary-header-bar .site-primary-header-wrap {
            min-height: 80px;
        }

        .ast-desktop .ast-primary-header-bar .main-header-menu>.menu-item {
            line-height: 80px;
        }

        .ast-header-break-point #masthead .ast-mobile-header-wrap .ast-primary-header-bar,
        .ast-header-break-point #masthead .ast-mobile-header-wrap .ast-below-header-bar,
        .ast-header-break-point #masthead .ast-mobile-header-wrap .ast-above-header-bar {
            padding-left: 20px;
            padding-right: 20px;
        }

        .ast-header-break-point .ast-primary-header-bar {
            border-bottom-width: 1px;
            border-bottom-color: var(--ast-global-color-subtle-background, --ast-global-color-7);
            border-bottom-style: solid;
        }

        @media (min-width:922px) {
            .ast-primary-header-bar {
                border-bottom-width: 1px;
                border-bottom-color: var(--ast-global-color-subtle-background, --ast-global-color-7);
                border-bottom-style: solid;
            }
        }

        .ast-primary-header-bar {
            background-color: var(--ast-global-color-primary, --ast-global-color-4);
            background-image: none;
        }

        @media (max-width:921px) {

            .ast-mobile-header-wrap .ast-primary-header-bar,
            .ast-primary-header-bar .site-primary-header-wrap {
                min-height: 70px;
            }
        }

        @media (max-width:544px) {

            .ast-mobile-header-wrap .ast-primary-header-bar,
            .ast-primary-header-bar .site-primary-header-wrap {
                min-height: 70px;
            }
        }

        @media (max-width:921px) {

            .ast-desktop .ast-primary-header-bar.main-header-bar,
            .ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar {
                padding-top: 0px;
                padding-left: 32px;
                padding-right: 32px;
            }
        }

        @media (max-width:544px) {

            .ast-desktop .ast-primary-header-bar.main-header-bar,
            .ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar {
                padding-top: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
                padding-right: 0px;
                margin-top: 0px;
                margin-bottom: 0px;
                margin-left: 0px;
                margin-right: 0px;
            }
        }

        .ast-primary-header-bar {
            display: block;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-primary-header-bar {
                display: grid;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-primary-header-bar {
                display: grid;
            }
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
            color: var(--ast-global-color-0);
            border: none;
            background: transparent;
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg {
            width: 24px;
            height: 24px;
            fill: var(--ast-global-color-0);
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu {
            color: var(--ast-global-color-0);
        }

        @media (max-width:544px) {
            [data-section="section-header-mobile-trigger"] .ast-button-wrap .menu-toggle {
                margin-top: 24px;
                margin-bottom: 24px;
                margin-left: 24px;
                margin-right: 24px;
            }
        }

        .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
            color: var(--ast-global-color-3);
        }

        .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.ast-menu-toggle {
            color: var(--ast-global-color-3);
        }

        .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover>.menu-link,
        .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-mobile .menu-item:hover>.menu-link,
        .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-mobile .main-navigation .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.menu-link,
        .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
        .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.menu-link,
        .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.ast-menu-toggle {
            color: var(--ast-global-color-1);
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
            top: 0;
        }

        .ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
            content: unset;
        }

        .ast-hfb-header .ast-builder-menu-mobile .main-header-menu,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link {
            border-style: none;
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
            top: 0;
        }

        @media (max-width:921px) {
            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
                color: #ffffff;
                padding-top: 0px;
                padding-left: 32px;
                padding-right: 32px;
            }

            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.ast-menu-toggle {
                color: #ffffff;
            }

            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover>.menu-link,
            .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
                color: var(--ast-global-color-1);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item:hover>.ast-menu-toggle {
                color: var(--ast-global-color-1);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.menu-link,
            .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.menu-link,
            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.ast-menu-toggle {
                color: var(--ast-global-color-1);
                background: rgba(255, 255, 255, 0.31);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.ast-menu-toggle {
                color: var(--ast-global-color-1);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0px;
                right: calc(32px - 0.907em);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
                content: unset;
            }

            .ast-builder-menu-mobile .main-navigation .main-header-menu,
            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-link,
            .ast-builder-menu-mobile .main-navigation .main-header-menu .sub-menu {
                background-color: var(--ast-global-color-2);
                background-image: none;
            }
        }

        @media (max-width:544px) {
            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
                padding-top: 1px;
                padding-bottom: 1px;
                padding-left: 24px;
                padding-right: 24px;
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 1px;
                right: calc(24px - 0.907em);
            }
        }

        .ast-builder-menu-mobile .main-navigation {
            display: block;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-builder-menu-mobile .main-navigation {
                display: block;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-builder-menu-mobile .main-navigation {
                display: block;
            }
        }

        :root {
            --e-global-color-astglobalcolor0: #cbff54;
            --e-global-color-astglobalcolor1: #b4f625;
            --e-global-color-astglobalcolor2: #063231;
            --e-global-color-astglobalcolor3: #495b55;
            --e-global-color-astglobalcolor4: #f6f7f7;
            --e-global-color-astglobalcolor5: #ffffff;
            --e-global-color-astglobalcolor6: #e0e7e3;
            --e-global-color-astglobalcolor7: #D1D5DB;
            --e-global-color-astglobalcolor8: #033231;
        }

        .ast-desktop .astra-menu-animation-slide-up>.menu-item>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu .sub-menu {
            opacity: 0;
            visibility: hidden;
            transform: translateY(.5em);
            transition: visibility .2s ease, transform .2s ease
        }

        .ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item:hover>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.sub-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            transition: opacity .2s ease, visibility .2s ease, transform .2s ease
        }

        .ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
            -js-display: flex;
            display: flex
        }

        .ast-desktop .astra-menu-animation-slide-down>.menu-item>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu .sub-menu {
            opacity: 0;
            visibility: hidden;
            transform: translateY(-.5em);
            transition: visibility .2s ease, transform .2s ease
        }

        .ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item:hover>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.sub-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            transition: opacity .2s ease, visibility .2s ease, transform .2s ease
        }

        .ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
            -js-display: flex;
            display: flex
        }

        .ast-desktop .astra-menu-animation-fade>.menu-item>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu,
        .ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu .sub-menu {
            opacity: 0;
            visibility: hidden;
            transition: opacity ease-in-out .3s
        }

        .ast-desktop .astra-menu-animation-fade>.menu-item .menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-fade>.menu-item .menu-item:hover>.sub-menu,
        .ast-desktop .astra-menu-animation-fade>.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-fade>.menu-item.focus>.sub-menu,
        .ast-desktop .astra-menu-animation-fade>.menu-item:hover>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-fade>.menu-item:hover>.sub-menu {
            opacity: 1;
            visibility: visible;
            transition: opacity ease-in-out .3s
        }

        .ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
        .ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
            -js-display: flex;
            display: flex
        }

        .ast-desktop .menu-item.ast-menu-hover>.sub-menu.toggled-on {
            opacity: 1;
            visibility: visible
        }
    </style>
    <style id="astra-google-fonts-css" media="all">
        /* cyrillic-ext */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZJhiI2B.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZthiI2B.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* greek-ext */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZNhiI2B.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        /* greek */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZxhiI2B.woff2) format('woff2');
            unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
        }

        /* vietnamese */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZBhiI2B.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZFhiI2B.woff2) format('woff2');
            unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 700;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/inter/v19/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiA.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmZiArmlw.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmQiArmlw.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* greek-ext */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmYiArmlw.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        /* greek */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmXiArmlw.woff2) format('woff2');
            unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
        }

        /* math */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVnoiArmlw.woff2) format('woff2');
            unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
        }

        /* symbols */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVn6iArmlw.woff2) format('woff2');
            unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF;
        }

        /* vietnamese */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmbiArmlw.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmaiArmlw.woff2) format('woff2');
            unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */
        @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-stretch: 100%;
            font-display: fallback;
            src: url(/fonts.gstatic.com/s/roboto/v48/KFOMCnqEu92Fr1ME7kSn66aGLdTylUAMQXC89YmC2DPNWubEbVmUiAo.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
    </style>
    <link rel='stylesheet' id='hfe-widgets-style-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.4.8' media='all' />
    <style id='wp-emoji-styles-inline-css'>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <style id='global-styles-inline-css'>
        :root {
            --wp--preset--aspect-ratio--square: 1;
            --wp--preset--aspect-ratio--4-3: 4/3;
            --wp--preset--aspect-ratio--3-4: 3/4;
            --wp--preset--aspect-ratio--3-2: 3/2;
            --wp--preset--aspect-ratio--2-3: 2/3;
            --wp--preset--aspect-ratio--16-9: 16/9;
            --wp--preset--aspect-ratio--9-16: 9/16;
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--color--ast-global-color-0: var(--ast-global-color-0);
            --wp--preset--color--ast-global-color-1: var(--ast-global-color-1);
            --wp--preset--color--ast-global-color-2: var(--ast-global-color-2);
            --wp--preset--color--ast-global-color-3: var(--ast-global-color-3);
            --wp--preset--color--ast-global-color-4: var(--ast-global-color-4);
            --wp--preset--color--ast-global-color-5: var(--ast-global-color-5);
            --wp--preset--color--ast-global-color-6: var(--ast-global-color-6);
            --wp--preset--color--ast-global-color-7: var(--ast-global-color-7);
            --wp--preset--color--ast-global-color-8: var(--ast-global-color-8);
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :root {
            --wp--style--global--content-size: var(--wp--custom--ast-content-width-size);
            --wp--style--global--wide-size: var(--wp--custom--ast-wide-width-size);
        }

        :where(body) {
            margin: 0;
        }

        .wp-site-blocks>.alignleft {
            float: left;
            margin-right: 2em;
        }

        .wp-site-blocks>.alignright {
            float: right;
            margin-left: 2em;
        }

        .wp-site-blocks>.aligncenter {
            justify-content: center;
            margin-left: auto;
            margin-right: auto;
        }

        :where(.wp-site-blocks)>* {
            margin-block-start: 24px;
            margin-block-end: 0;
        }

        :where(.wp-site-blocks)> :first-child {
            margin-block-start: 0;
        }

        :where(.wp-site-blocks)> :last-child {
            margin-block-end: 0;
        }

        :root {
            --wp--style--block-gap: 24px;
        }

        :root :where(.is-layout-flow)> :first-child {
            margin-block-start: 0;
        }

        :root :where(.is-layout-flow)> :last-child {
            margin-block-end: 0;
        }

        :root :where(.is-layout-flow)>* {
            margin-block-start: 24px;
            margin-block-end: 0;
        }

        :root :where(.is-layout-constrained)> :first-child {
            margin-block-start: 0;
        }

        :root :where(.is-layout-constrained)> :last-child {
            margin-block-end: 0;
        }

        :root :where(.is-layout-constrained)>* {
            margin-block-start: 24px;
            margin-block-end: 0;
        }

        :root :where(.is-layout-flex) {
            gap: 24px;
        }

        :root :where(.is-layout-grid) {
            gap: 24px;
        }

        .is-layout-flow>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        .is-layout-flow>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        .is-layout-flow>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        .is-layout-constrained>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        .is-layout-constrained>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        .is-layout-constrained>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: var(--wp--style--global--content-size);
            margin-left: auto !important;
            margin-right: auto !important;
        }

        .is-layout-constrained>.alignwide {
            max-width: var(--wp--style--global--wide-size);
        }

        body .is-layout-flex {
            display: flex;
        }

        .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        .is-layout-flex> :is(*, div) {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        .is-layout-grid> :is(*, div) {
            margin: 0;
        }

        body {
            padding-top: 0px;
            padding-right: 0px;
            padding-bottom: 0px;
            padding-left: 0px;
        }

        a:where(:not(.wp-element-button)) {
            text-decoration: none;
        }

        :root :where(.wp-element-button, .wp-block-button__link) {
            background-color: #32373c;
            border-width: 0;
            color: #fff;
            font-family: inherit;
            font-size: inherit;
            line-height: inherit;
            padding: calc(0.667em + 2px) calc(1.333em + 2px);
            text-decoration: none;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-color {
            color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-color {
            color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-color {
            color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-color {
            color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-color {
            color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-color {
            color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-color {
            color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-color {
            color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-color {
            color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-background-color {
            background-color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-background-color {
            background-color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-background-color {
            background-color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-background-color {
            background-color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-background-color {
            background-color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-background-color {
            background-color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-background-color {
            background-color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-background-color {
            background-color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-background-color {
            background-color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-border-color {
            border-color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-border-color {
            border-color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-border-color {
            border-color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-border-color {
            border-color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-border-color {
            border-color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-border-color {
            border-color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-border-color {
            border-color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-border-color {
            border-color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-border-color {
            border-color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        :root :where(.wp-block-pullquote) {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link rel='stylesheet' id='latepoint-main-front-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/latepoint/public/stylesheets/front.css?ver=5.1.94' media='all' />
    <style id='latepoint-main-front-inline-css'>
        :root {
            --latepoint-brand-primary: #033231;
            --latepoint-body-color: #1f222b;
            --latepoint-headings-color: #14161d;
            --latepoint-color-text-faded: #7c85a3;
            --latepoint-timeslot-selected-color: --latepoint-brand-primary;
            --latepoint-calendar-weekday-label-color: var(--latepoint-headings-color);
            --latepoint-calendar-weekday-label-bg: #fff;
            --latepoint-side-panel-bg: #fff;
            --latepoint-summary-panel-bg: #fff;
        }
    </style>
    <link rel='stylesheet' id='hfe-style-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.4.8' media='all' />
    <link rel='stylesheet' id='elementor-frontend-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='elementor-post-4-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-4.css?ver=1754577259' media='all' />
    <link rel='stylesheet' id='astra-sites-showcase-blocks-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/astra-sites-showcase/assets/css/blocks.css?ver=2.4.12' media='all' />
    <link rel='stylesheet' id='uael-frontend-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/ultimate-elementor/assets/min-css/uael-frontend.min.css?ver=1.39.9' media='all' />
    <link rel='stylesheet' id='wpforms-modern-full-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-full.min.css?ver=1.9.7.2' media='all' />
    <style id='wpforms-modern-full-inline-css'>
        :root {
            --wpforms-field-border-radius: 3px;
            --wpforms-field-border-style: solid;
            --wpforms-field-border-size: 1px;
            --wpforms-field-background-color: #ffffff;
            --wpforms-field-border-color: rgba(0, 0, 0, 0.25);
            --wpforms-field-border-color-spare: rgba(0, 0, 0, 0.25);
            --wpforms-field-text-color: rgba(0, 0, 0, 0.7);
            --wpforms-field-menu-color: #ffffff;
            --wpforms-label-color: rgba(0, 0, 0, 0.85);
            --wpforms-label-sublabel-color: rgba(0, 0, 0, 0.55);
            --wpforms-label-error-color: #d63637;
            --wpforms-button-border-radius: 3px;
            --wpforms-button-border-style: none;
            --wpforms-button-border-size: 1px;
            --wpforms-button-background-color: #066aab;
            --wpforms-button-border-color: #066aab;
            --wpforms-button-text-color: #ffffff;
            --wpforms-page-break-color: #066aab;
            --wpforms-background-image: none;
            --wpforms-background-position: center center;
            --wpforms-background-repeat: no-repeat;
            --wpforms-background-size: cover;
            --wpforms-background-width: 100px;
            --wpforms-background-height: 100px;
            --wpforms-background-color: rgba(0, 0, 0, 0);
            --wpforms-background-url: none;
            --wpforms-container-padding: 0px;
            --wpforms-container-border-style: none;
            --wpforms-container-border-width: 1px;
            --wpforms-container-border-color: #000000;
            --wpforms-container-border-radius: 3px;
            --wpforms-field-size-input-height: 43px;
            --wpforms-field-size-input-spacing: 15px;
            --wpforms-field-size-font-size: 16px;
            --wpforms-field-size-line-height: 19px;
            --wpforms-field-size-padding-h: 14px;
            --wpforms-field-size-checkbox-size: 16px;
            --wpforms-field-size-sublabel-spacing: 5px;
            --wpforms-field-size-icon-size: 1;
            --wpforms-label-size-font-size: 16px;
            --wpforms-label-size-line-height: 19px;
            --wpforms-label-size-sublabel-font-size: 14px;
            --wpforms-label-size-sublabel-line-height: 17px;
            --wpforms-button-size-font-size: 17px;
            --wpforms-button-size-height: 41px;
            --wpforms-button-size-padding-h: 15px;
            --wpforms-button-size-margin-top: 10px;
            --wpforms-container-shadow-size-box-shadow: none;

        }
    </style>
    <link rel='stylesheet' id='uael-teammember-social-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
    <link rel='stylesheet' id='uael-social-share-icons-brands-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='uael-social-share-icons-fontawesome-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='uael-nav-menu-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='e-shapes-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/conditionals/shapes.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='widget-image-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='widget-heading-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='widget-icon-box-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='widget-rating-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-rating.min.css?ver=3.31.1' media='all' />
    <link rel='stylesheet' id='elementor-post-6-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-6.css?ver=1755185819' media='all' />
    <link rel='stylesheet' id='elementor-post-536-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-536.css?ver=1754577260' media='all' />
    <link rel='stylesheet' id='astra-addon-css-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/astra-addon/astra-addon-689579e29583f2-35016433.css?ver=4.11.6' media='all' />
    <style id='astra-addon-css-inline-css'>
        #content:before {
            content: "921";
            position: absolute;
            overflow: hidden;
            opacity: 0;
            visibility: hidden;
        }

        .blog-layout-2 {
            position: relative;
        }

        .single .ast-author-details .author-title {
            color: var(--ast-global-color-2);
        }

        .single.ast-page-builder-template .ast-single-author-box {
            padding: 2em 20px;
        }

        .single.ast-separate-container .ast-author-meta {
            padding: 3em;
        }

        @media (max-width:921px) {
            .single.ast-separate-container .ast-author-meta {
                padding: 1.5em 2.14em;
            }

            .single .ast-author-meta .post-author-avatar {
                margin-bottom: 1em;
            }

            .ast-separate-container .ast-grid-2 .ast-article-post,
            .ast-separate-container .ast-grid-3 .ast-article-post,
            .ast-separate-container .ast-grid-4 .ast-article-post {
                width: 100%;
            }

            .ast-separate-container .ast-grid-md-2 .ast-article-post {
                width: 50%;
            }

            .ast-separate-container .ast-grid-md-2 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-md-3 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-md-4 .ast-article-post.ast-separate-posts {
                padding: 0 .75em 0;
            }

            .blog-layout-1 .post-content,
            .blog-layout-1 .ast-blog-featured-section {
                float: none;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on {
                margin-top: 0;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
                margin-top: 1em;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
                margin-top: -1.5em;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
                margin-left: -2.14em;
                margin-right: -2.14em;
            }

            .ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .entry-header .post-thumb-img-content:first-child {
                margin-top: -1.5em;
            }

            .ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .post-thumb-img-content {
                margin-left: -2.14em;
                margin-right: -2.14em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
                margin-left: -1.5em;
                margin-right: -1.5em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
                margin-left: -0.5em;
                margin-right: -0.5em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on {
                margin-top: 0;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
                margin-top: 1em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
                margin-top: -1.5em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
                margin-left: -1.5em;
                margin-right: -1.5em;
            }

            .blog-layout-2 {
                display: flex;
                flex-direction: column-reverse;
            }

            .ast-separate-container .blog-layout-3,
            .ast-separate-container .blog-layout-1 {
                display: block;
            }

            .ast-plain-container .ast-grid-2 .ast-article-post,
            .ast-plain-container .ast-grid-3 .ast-article-post,
            .ast-plain-container .ast-grid-4 .ast-article-post,
            .ast-page-builder-template .ast-grid-2 .ast-article-post,
            .ast-page-builder-template .ast-grid-3 .ast-article-post,
            .ast-page-builder-template .ast-grid-4 .ast-article-post {
                width: 100%;
            }

            .ast-separate-container .ast-blog-layout-4-grid .ast-article-post {
                display: flex;
            }
        }

        @media (max-width:921px) {
            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
                margin-top: 0;
                margin-left: -2.14em;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
                margin-top: 0;
                margin-left: -1.14em;
            }
        }

        @media (min-width:922px) {

            .ast-separate-container.ast-blog-grid-2 .ast-archive-description,
            .ast-separate-container.ast-blog-grid-3 .ast-archive-description,
            .ast-separate-container.ast-blog-grid-4 .ast-archive-description {
                margin-bottom: 1.33333em;
            }

            .blog-layout-2.ast-no-thumb .post-content,
            .blog-layout-3.ast-no-thumb .post-content {
                width: calc(100% - 5.714285714em);
            }

            .blog-layout-2.ast-no-thumb.ast-no-date-box .post-content,
            .blog-layout-3.ast-no-thumb.ast-no-date-box .post-content {
                width: 100%;
            }

            .ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts {
                border-bottom: 0;
            }

            .ast-separate-container .ast-grid-2>.site-main>.ast-row:before,
            .ast-separate-container .ast-grid-2>.site-main>.ast-row:after,
            .ast-separate-container .ast-grid-3>.site-main>.ast-row:before,
            .ast-separate-container .ast-grid-3>.site-main>.ast-row:after,
            .ast-separate-container .ast-grid-4>.site-main>.ast-row:before,
            .ast-separate-container .ast-grid-4>.site-main>.ast-row:after {
                flex-basis: 0;
                width: 0;
            }

            .ast-separate-container .ast-grid-2 .ast-article-post,
            .ast-separate-container .ast-grid-3 .ast-article-post,
            .ast-separate-container .ast-grid-4 .ast-article-post {
                display: flex;
                padding: 0;
            }

            .ast-plain-container .ast-grid-2>.site-main>.ast-row,
            .ast-plain-container .ast-grid-3>.site-main>.ast-row,
            .ast-plain-container .ast-grid-4>.site-main>.ast-row,
            .ast-page-builder-template .ast-grid-2>.site-main>.ast-row,
            .ast-page-builder-template .ast-grid-3>.site-main>.ast-row,
            .ast-page-builder-template .ast-grid-4>.site-main>.ast-row {
                margin-left: -1em;
                margin-right: -1em;
                display: flex;
                flex-flow: row wrap;
                align-items: stretch;
            }

            .ast-plain-container .ast-grid-2>.site-main>.ast-row:before,
            .ast-plain-container .ast-grid-2>.site-main>.ast-row:after,
            .ast-plain-container .ast-grid-3>.site-main>.ast-row:before,
            .ast-plain-container .ast-grid-3>.site-main>.ast-row:after,
            .ast-plain-container .ast-grid-4>.site-main>.ast-row:before,
            .ast-plain-container .ast-grid-4>.site-main>.ast-row:after,
            .ast-page-builder-template .ast-grid-2>.site-main>.ast-row:before,
            .ast-page-builder-template .ast-grid-2>.site-main>.ast-row:after,
            .ast-page-builder-template .ast-grid-3>.site-main>.ast-row:before,
            .ast-page-builder-template .ast-grid-3>.site-main>.ast-row:after,
            .ast-page-builder-template .ast-grid-4>.site-main>.ast-row:before,
            .ast-page-builder-template .ast-grid-4>.site-main>.ast-row:after {
                flex-basis: 0;
                width: 0;
            }

            .ast-plain-container .ast-grid-2 .ast-article-post,
            .ast-plain-container .ast-grid-3 .ast-article-post,
            .ast-plain-container .ast-grid-4 .ast-article-post,
            .ast-page-builder-template .ast-grid-2 .ast-article-post,
            .ast-page-builder-template .ast-grid-3 .ast-article-post,
            .ast-page-builder-template .ast-grid-4 .ast-article-post {
                display: flex;
            }

            .ast-plain-container .ast-grid-2 .ast-article-post:last-child,
            .ast-plain-container .ast-grid-3 .ast-article-post:last-child,
            .ast-plain-container .ast-grid-4 .ast-article-post:last-child,
            .ast-page-builder-template .ast-grid-2 .ast-article-post:last-child,
            .ast-page-builder-template .ast-grid-3 .ast-article-post:last-child,
            .ast-page-builder-template .ast-grid-4 .ast-article-post:last-child {
                margin-bottom: 1.5em;
            }

            .ast-separate-container .ast-grid-2>.site-main>.ast-row,
            .ast-separate-container .ast-grid-3>.site-main>.ast-row,
            .ast-separate-container .ast-grid-4>.site-main>.ast-row {
                margin-left: -1em;
                margin-right: -1em;
                display: flex;
                flex-flow: row wrap;
                align-items: stretch;
            }

            .single .ast-author-meta .ast-author-details {
                display: flex;
                align-items: center;
            }

            .post-author-bio .author-title {
                margin-bottom: 10px;
            }
        }

        @media (min-width:922px) {

            .single .post-author-avatar,
            .single .post-author-bio {
                float: left;
                clear: right;
            }

            .single .ast-author-meta .post-author-avatar {
                margin-right: 1.33333em;
            }

            .single .ast-author-meta .about-author-title-wrapper,
            .single .ast-author-meta .post-author-bio {
                text-align: left;
            }

            .blog-layout-2 .post-content {
                padding-right: 2em;
            }

            .blog-layout-2.ast-no-date-box.ast-no-thumb .post-content {
                padding-right: 0;
            }

            .blog-layout-3 .post-content {
                padding-left: 2em;
            }

            .blog-layout-3.ast-no-date-box.ast-no-thumb .post-content {
                padding-left: 0;
            }

            .ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts:nth-child(2n+0),
            .ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts:nth-child(2n+1),
            .ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts:nth-child(2n+0),
            .ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts:nth-child(2n+1),
            .ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts:nth-child(2n+0),
            .ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts:nth-child(2n+1) {
                padding: 0 1em 0;
            }
        }

        @media (max-width:544px) {
            .ast-separate-container .ast-grid-sm-1 .ast-article-post {
                width: 100%;
            }

            .ast-separate-container .ast-grid-sm-2 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-sm-3 .ast-article-post.ast-separate-posts,
            .ast-separate-container .ast-grid-sm-4 .ast-article-post.ast-separate-posts {
                padding: 0 .5em 0;
            }

            .ast-separate-container .ast-grid-sm-1 .ast-article-post.ast-separate-posts {
                padding: 0;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
                margin-top: 0.5em;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
            .ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
                margin-left: -1em;
                margin-right: -1em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
                margin-left: -0.5em;
                margin-right: -0.5em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
                margin-top: 0.5em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
                margin-top: -1.33333em;
            }

            .ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
            .ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
                margin-left: -1em;
                margin-right: -1em;
            }

            .ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-1,
            .ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-2,
            .ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-3 {
                padding: 1.33333em 1em;
            }

            .ast-separate-container .ast-grid-3 .ast-article-post .blog-layout-1,
            .ast-separate-container .ast-grid-4 .ast-article-post .blog-layout-1 {
                padding: 1.33333em 1em;
            }

            .single.ast-separate-container .ast-author-meta {
                padding: 1.5em 1em;
            }
        }

        @media (max-width:544px) {
            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
                margin-left: -1em;
            }

            .ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
                margin-left: -0.5em;
            }
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            margin-bottom: 20px;
        }

        @media (min-width:922px) {
            .ast-hide-display-device-desktop {
                display: none;
            }

            [class^="astra-advanced-hook-"] .wp-block-query .wp-block-post-template .wp-block-post {
                width: 100%;
            }
        }

        @media (min-width:545px) and (max-width:921px) {
            .ast-hide-display-device-tablet {
                display: none;
            }
        }

        @media (max-width:544px) {
            .ast-hide-display-device-mobile {
                display: none;
            }
        }

        .ast-article-post .ast-date-meta .posted-on,
        .ast-article-post .ast-date-meta .posted-on * {
            background: var(--ast-global-color-2);
            color: #ffffff;
        }

        .ast-article-post .ast-date-meta .posted-on .date-month,
        .ast-article-post .ast-date-meta .posted-on .date-year {
            color: #ffffff;
        }

        .ast-loader>div {
            background-color: var(--ast-global-color-2);
        }

        .ast-page-builder-template .ast-archive-description {
            margin-bottom: 2em;
        }

        .ast-load-more {
            cursor: pointer;
            display: none;
            border: 2px solid var(--ast-border-color);
            transition: all 0.2s linear;
            color: #000;
        }

        .ast-load-more.active {
            display: inline-block;
            padding: 0 1.5em;
            line-height: 3em;
        }

        .ast-load-more.no-more:hover {
            border-color: var(--ast-border-color);
            color: #000;
        }

        .ast-load-more.no-more:hover {
            background-color: inherit;
        }

        .ast-header-search .ast-search-menu-icon .search-field {
            border-radius: 2px;
        }

        .ast-header-search .ast-search-menu-icon .search-submit {
            border-radius: 2px;
        }

        .ast-header-search .ast-search-menu-icon .search-form {
            border-top-width: 1px;
            border-bottom-width: 1px;
            border-left-width: 1px;
            border-right-width: 1px;
            border-color: #ddd;
            border-radius: 2px;
        }

        .ast-separate-container .primary:not(.ast-grid-1) .ast-article-inner,
        .ast-narrow-container .primary:not(.ast-grid-1) .ast-article-inner {
            padding-top: 0px;
            padding-right: 0px;
            padding-bottom: 0px;
            padding-left: 0px;
        }

        @media (max-width:921px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .ast-comment-list li.depth-1,
            .ast-separate-container .comment-respond .ast-separate-container .ast-related-posts-wrap {
                padding-top: 1.5em;
                padding-bottom: 1.5em;
            }

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .comments-count-wrapper,
            .ast-separate-container .ast-comment-list li.depth-1,
            .ast-separate-container .comment-respond,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container .related-posts-title-wrapper .single.ast-separate-container .about-author-title-wrapper,
            .ast-separate-container .ast-related-posts-wrap {
                padding-right: 2.14em;
                padding-left: 2.14em;
            }

            .ast-narrow-container .ast-article-post,
            .ast-narrow-container .ast-article-single,
            .ast-narrow-container .ast-comment-list li.depth-1,
            .ast-narrow-container .comment-respond,
            .ast-narrow-container .ast-related-posts-wrap,
            .ast-narrow-container .ast-single-related-posts-container {
                padding-top: 1.5em;
                padding-bottom: 1.5em;
            }

            .ast-narrow-container .ast-article-post,
            .ast-narrow-container .ast-article-single,
            .ast-narrow-container .comments-count-wrapper,
            .ast-narrow-container .ast-comment-list li.depth-1,
            .ast-narrow-container .comment-respond,
            .ast-narrow-container .related-posts-title-wrapper,
            .ast-narrow-container .related-posts-title-wrapper,
            .single.ast-narrow-container .about-author-title-wrapper,
            .ast-narrow-container .ast-related-posts-wrap,
            .ast-narrow-container .ast-single-related-posts-container {
                padding-right: 2.14em;
                padding-left: 2.14em;
            }

            .ast-separate-container.ast-right-sidebar #primary,
            .ast-separate-container.ast-left-sidebar #primary,
            .ast-separate-container #primary,
            .ast-plain-container #primary,
            .ast-narrow-container #primary {
                margin-top: 1.5em;
                margin-bottom: 1.5em;
            }

            .ast-left-sidebar #primary,
            .ast-right-sidebar #primary,
            .ast-separate-container.ast-right-sidebar #primary,
            .ast-separate-container.ast-left-sidebar #primary,
            .ast-separate-container #primary,
            .ast-narrow-container #primary {
                padding-left: 0em;
                padding-right: 0em;
            }

            .ast-no-sidebar.ast-separate-container .entry-content .alignfull,
            .ast-no-sidebar.ast-narrow-container .entry-content .alignfull {
                margin-right: -2.14em;
                margin-left: -2.14em;
            }
        }

        @media (max-width:544px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .ast-comment-list li.depth-1,
            .ast-separate-container .comment-respond,
            .ast-separate-container .ast-related-posts-wrap {
                padding-top: 1.5em;
                padding-bottom: 1.5em;
            }

            .ast-narrow-container .ast-article-post,
            .ast-narrow-container .ast-article-single,
            .ast-narrow-container .ast-comment-list li.depth-1,
            .ast-narrow-container .comment-respond,
            .ast-narrow-container .ast-related-posts-wrap,
            .ast-narrow-container .ast-single-related-posts-container {
                padding-top: 1.5em;
                padding-bottom: 1.5em;
            }

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .comments-count-wrapper,
            .ast-separate-container .ast-comment-list li.depth-1,
            .ast-separate-container .comment-respond,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container .related-posts-title-wrapper,
            .single.ast-separate-container .about-author-title-wrapper,
            .ast-separate-container .ast-related-posts-wrap {
                padding-right: 1em;
                padding-left: 1em;
            }

            .ast-narrow-container .ast-article-post,
            .ast-narrow-container .ast-article-single,
            .ast-narrow-container .comments-count-wrapper,
            .ast-narrow-container .ast-comment-list li.depth-1,
            .ast-narrow-container .comment-respond,
            .ast-narrow-container .related-posts-title-wrapper,
            .ast-narrow-container .related-posts-title-wrapper,
            .single.ast-narrow-container .about-author-title-wrapper,
            .ast-narrow-container .ast-related-posts-wrap,
            .ast-narrow-container .ast-single-related-posts-container {
                padding-right: 1em;
                padding-left: 1em;
            }

            .ast-no-sidebar.ast-separate-container .entry-content .alignfull,
            .ast-no-sidebar.ast-narrow-container .entry-content .alignfull {
                margin-right: -1em;
                margin-left: -1em;
            }
        }

        @media (max-width:544px) {

            .ast-header-break-point .header-main-layout-2 .site-branding,
            .ast-header-break-point .ast-mobile-header-stack .ast-mobile-menu-buttons {
                padding-bottom: 0px;
            }
        }

        @media (max-width:921px) {

            .ast-separate-container.ast-two-container #secondary .widget,
            .ast-separate-container #secondary .widget {
                margin-bottom: 1.5em;
            }
        }

        @media (max-width:921px) {

            .ast-separate-container #primary,
            .ast-narrow-container #primary {
                padding-top: 0px;
            }
        }

        @media (max-width:921px) {

            .ast-separate-container #primary,
            .ast-narrow-container #primary {
                padding-bottom: 0px;
            }
        }

        .ast-builder-menu-1 .main-header-menu.submenu-with-border .astra-megamenu,
        .ast-builder-menu-1 .main-header-menu.submenu-with-border .astra-full-megamenu-wrapper {
            border-top-width: 2px;
            border-bottom-width: 0px;
            border-right-width: 0px;
            border-left-width: 0px;
            border-color: #ffffff;
            border-style: solid;
        }

        @media (max-width:921px) {
            .ast-header-break-point .ast-builder-menu-1 .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }
        }

        @media (max-width:544px) {
            .ast-header-break-point .ast-builder-menu-1 .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }
        }

        @media (max-width:921px) {
            .ast-hfb-header .ast-builder-menu-mobile .ast-nav-menu .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0px;
                right: calc(0px - 0.907em);
            }
        }

        .site-title,
        .site-title a {
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            line-height: 1.23em;
        }

        .ast-blog-meta-container {
            font-weight: 600;
        }

        .ast-read-more-container a {
            font-size: 14px;
            font-size: 0.875rem;
        }

        .ast-excerpt-container {
            font-size: 16px;
            font-size: 1rem;
        }

        .ast-pagination .page-numbers,
        .ast-pagination .page-navigation {
            font-size: 16px;
            font-size: 1rem;
        }

        #secondary .widget-title {
            font-size: 26px;
            font-size: 1.625rem;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            line-height: 1.23em;
        }

        .secondary .widget>*:not(.widget-title) {
            font-size: 16px;
            font-size: 1rem;
        }

        .blog .entry-title,
        .blog .entry-title a,
        .archive .entry-title,
        .archive .entry-title a,
        .search .entry-title,
        .search .entry-title a {
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            line-height: 1.23em;
        }

        button,
        .ast-button,
        input#submit,
        input[type="button"],
        input[type="submit"],
        input[type="reset"] {
            font-size: 16px;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        h4.widget-title {
            font-weight: 700;
        }

        h5.widget-title {
            font-weight: 700;
        }

        h6.widget-title {
            font-weight: 700;
        }

        .elementor-widget-heading h4.elementor-heading-title {
            line-height: 1.2em;
        }

        .elementor-widget-heading h5.elementor-heading-title {
            line-height: 1.2em;
        }

        .elementor-widget-heading h6.elementor-heading-title {
            line-height: 1.25em;
        }
    </style>
    <style id='wpforms-modern-full-inline-css'>
:root {
				--wpforms-field-border-radius: 3px;
--wpforms-field-border-style: solid;
--wpforms-field-border-size: 1px;
--wpforms-field-background-color: #ffffff;
--wpforms-field-border-color: rgba( 0, 0, 0, 0.25 );
--wpforms-field-border-color-spare: rgba( 0, 0, 0, 0.25 );
--wpforms-field-text-color: rgba( 0, 0, 0, 0.7 );
--wpforms-field-menu-color: #ffffff;
--wpforms-label-color: rgba( 0, 0, 0, 0.85 );
--wpforms-label-sublabel-color: rgba( 0, 0, 0, 0.55 );
--wpforms-label-error-color: #d63637;
--wpforms-button-border-radius: 3px;
--wpforms-button-border-style: none;
--wpforms-button-border-size: 1px;
--wpforms-button-background-color: #066aab;
--wpforms-button-border-color: #066aab;
--wpforms-button-text-color: #ffffff;
--wpforms-page-break-color: #066aab;
--wpforms-background-image: none;
--wpforms-background-position: center center;
--wpforms-background-repeat: no-repeat;
--wpforms-background-size: cover;
--wpforms-background-width: 100px;
--wpforms-background-height: 100px;
--wpforms-background-color: rgba( 0, 0, 0, 0 );
--wpforms-background-url: none;
--wpforms-container-padding: 0px;
--wpforms-container-border-style: none;
--wpforms-container-border-width: 1px;
--wpforms-container-border-color: #000000;
--wpforms-container-border-radius: 3px;
--wpforms-field-size-input-height: 43px;
--wpforms-field-size-input-spacing: 15px;
--wpforms-field-size-font-size: 16px;
--wpforms-field-size-line-height: 19px;
--wpforms-field-size-padding-h: 14px;
--wpforms-field-size-checkbox-size: 16px;
--wpforms-field-size-sublabel-spacing: 5px;
--wpforms-field-size-icon-size: 1;
--wpforms-label-size-font-size: 16px;
--wpforms-label-size-line-height: 19px;
--wpforms-label-size-sublabel-font-size: 14px;
--wpforms-label-size-sublabel-line-height: 17px;
--wpforms-button-size-font-size: 17px;
--wpforms-button-size-height: 41px;
--wpforms-button-size-padding-h: 15px;
--wpforms-button-size-margin-top: 10px;
--wpforms-container-shadow-size-box-shadow: none;

			}
</style>
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
    <style id='astra-theme-css-inline-css'>
:root{--ast-post-nav-space:0;--ast-container-default-xlg-padding:2.5em;--ast-container-default-lg-padding:2.5em;--ast-container-default-slg-padding:2em;--ast-container-default-md-padding:2.5em;--ast-container-default-sm-padding:2.5em;--ast-container-default-xs-padding:2.4em;--ast-container-default-xxs-padding:1.8em;--ast-code-block-background:#ECEFF3;--ast-comment-inputs-background:#F9FAFB;--ast-normal-container-width:1200px;--ast-narrow-container-width:750px;--ast-blog-title-font-weight:600;--ast-blog-meta-weight:600;--ast-global-color-primary:var(--ast-global-color-4);--ast-global-color-secondary:var(--ast-global-color-5);--ast-global-color-alternate-background:var(--ast-global-color-6);--ast-global-color-subtle-background:var(--ast-global-color-7);--ast-bg-style-guide:#F8FAFC;--ast-shadow-style-guide:0px 0px 4px 0 #00000057;--ast-global-dark-bg-style:#fff;--ast-global-dark-lfs:#fbfbfb;--ast-widget-bg-color:#fafafa;--ast-wc-container-head-bg-color:#fbfbfb;--ast-title-layout-bg:#eeeeee;--ast-search-border-color:#e7e7e7;--ast-lifter-hover-bg:#e6e6e6;--ast-gallery-block-color:#000;--srfm-color-input-label:var(--ast-global-color-2);}html{font-size:100%;}a{color:var(--ast-global-color-2);}a:hover,a:focus{color:var(--ast-global-color-3);}body,button,input,select,textarea,.ast-button,.ast-custom-button{font-family:'Roboto',sans-serif;font-weight:400;font-size:16px;font-size:1rem;line-height:var(--ast-body-line-height,1.65);}blockquote{color:var(--ast-global-color-3);}h1,h2,h3,h4,h5,h6,.entry-content :where(h1,h2,h3,h4,h5,h6),.site-title,.site-title a{font-family:'Inter',sans-serif;font-weight:700;letter-spacing:-2px;}.ast-site-identity .site-title a{color:var(--ast-global-color-2);}.site-title{font-size:26px;font-size:1.625rem;display:none;}.site-header .site-description{font-size:15px;font-size:0.9375rem;display:none;}.entry-title{font-size:24px;font-size:1.5rem;}.ast-blog-single-element.ast-taxonomy-container a{font-size:12px;font-size:0.75rem;}.ast-blog-meta-container{font-size:14px;font-size:0.875rem;}.archive .ast-article-post .ast-article-inner,.blog .ast-article-post .ast-article-inner,.archive .ast-article-post .ast-article-inner:hover,.blog .ast-article-post .ast-article-inner:hover{border-top-left-radius:18px;border-top-right-radius:18px;border-bottom-right-radius:18px;border-bottom-left-radius:18px;overflow:hidden;}h1,.entry-content :where(h1){font-size:80px;font-size:5rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.1em;}h2,.entry-content :where(h2){font-size:54px;font-size:3.375rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.3em;}h3,.entry-content :where(h3){font-size:42px;font-size:2.625rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.3em;}h4,.entry-content :where(h4){font-size:32px;font-size:2rem;line-height:1.2em;font-weight:700;font-family:'Inter',sans-serif;letter-spacing:-1px;}h5,.entry-content :where(h5){font-size:24px;font-size:1.5rem;line-height:1.2em;font-weight:700;font-family:'Inter',sans-serif;letter-spacing:-1px;}h6,.entry-content :where(h6){font-size:20px;font-size:1.25rem;line-height:1.25em;font-weight:700;font-family:'Inter',sans-serif;letter-spacing:-1px;}::selection{background-color:var(--ast-global-color-0);color:#000000;}body,h1,h2,h3,h4,h5,h6,.entry-title a,.entry-content :where(h1,h2,h3,h4,h5,h6){color:var(--ast-global-color-3);}.tagcloud a:hover,.tagcloud a:focus,.tagcloud a.current-item{color:#ffffff;border-color:var(--ast-global-color-2);background-color:var(--ast-global-color-2);}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,textarea:focus{border-color:var(--ast-global-color-2);}input[type="radio"]:checked,input[type=reset],input[type="checkbox"]:checked,input[type="checkbox"]:hover:checked,input[type="checkbox"]:focus:checked,input[type=range]::-webkit-slider-thumb{border-color:var(--ast-global-color-2);background-color:var(--ast-global-color-2);box-shadow:none;}.site-footer a:hover + .post-count,.site-footer a:focus + .post-count{background:var(--ast-global-color-2);border-color:var(--ast-global-color-2);}.single .nav-links .nav-previous,.single .nav-links .nav-next{color:var(--ast-global-color-2);}.entry-meta,.entry-meta *{line-height:1.45;color:var(--ast-global-color-2);}.entry-meta a:not(.ast-button):hover,.entry-meta a:not(.ast-button):hover *,.entry-meta a:not(.ast-button):focus,.entry-meta a:not(.ast-button):focus *,.page-links > .page-link,.page-links .page-link:hover,.post-navigation a:hover{color:var(--ast-global-color-3);}#cat option,.secondary .calendar_wrap thead a,.secondary .calendar_wrap thead a:visited{color:var(--ast-global-color-2);}.secondary .calendar_wrap #today,.ast-progress-val span{background:var(--ast-global-color-2);}.secondary a:hover + .post-count,.secondary a:focus + .post-count{background:var(--ast-global-color-2);border-color:var(--ast-global-color-2);}.calendar_wrap #today > a{color:#ffffff;}.page-links .page-link,.single .post-navigation a{color:var(--ast-global-color-3);}.ast-search-menu-icon .search-form button.search-submit{padding:0 4px;}.ast-search-menu-icon form.search-form{padding-right:0;}.ast-search-menu-icon.slide-search input.search-field{width:0;}.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-form,.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-field:focus{transition:all 0.2s;}.search-form input.search-field:focus{outline:none;}.ast-search-menu-icon .search-form button.search-submit:focus,.ast-theme-transparent-header .ast-header-search .ast-dropdown-active .ast-icon,.ast-theme-transparent-header .ast-inline-search .search-field:focus .ast-icon{color:var(--ast-global-color-1);}.ast-header-search .slide-search .search-form{border:2px solid var(--ast-global-color-0);}.ast-header-search .slide-search .search-field{background-color:(--ast-global-dark-bg-style);}.ast-archive-title{color:var(--ast-global-color-2);}.widget-title{font-size:22px;font-size:1.375rem;color:var(--ast-global-color-2);}.single .ast-author-details .author-title{color:var(--ast-global-color-3);}.ast-single-post .entry-content a,.ast-comment-content a:not(.ast-comment-edit-reply-wrap a){text-decoration:underline;}.ast-single-post .elementor-widget-button .elementor-button,.ast-single-post .entry-content .uagb-tab a,.ast-single-post .entry-content .uagb-ifb-cta a,.ast-single-post .entry-content .uabb-module-content a,.ast-single-post .entry-content .uagb-post-grid a,.ast-single-post .entry-content .uagb-timeline a,.ast-single-post .entry-content .uagb-toc__wrap a,.ast-single-post .entry-content .uagb-taxomony-box a,.entry-content .wp-block-latest-posts > li > a,.ast-single-post .entry-content .wp-block-file__button,a.ast-post-filter-single,.ast-single-post .ast-comment-content .comment-reply-link,.ast-single-post .ast-comment-content .comment-edit-link{text-decoration:none;}.ast-search-menu-icon.slide-search a:focus-visible:focus-visible,.astra-search-icon:focus-visible,#close:focus-visible,a:focus-visible,.ast-menu-toggle:focus-visible,.site .skip-link:focus-visible,.wp-block-loginout input:focus-visible,.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper,.ast-header-navigation-arrow:focus-visible,.ast-orders-table__row .ast-orders-table__cell:focus-visible,a#ast-apply-coupon:focus-visible,#ast-apply-coupon:focus-visible,#close:focus-visible,.button.search-submit:focus-visible,#search_submit:focus,.normal-search:focus-visible,.ast-header-account-wrap:focus-visible,.astra-cart-drawer-close:focus,.ast-single-variation:focus,.ast-button:focus{outline-style:dotted;outline-color:inherit;outline-width:thin;}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,input[type="number"]:focus,textarea:focus,.wp-block-search__input:focus,[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal:focus,.ast-mobile-popup-drawer.active .menu-toggle-close:focus,#ast-scroll-top:focus,#coupon_code:focus,#ast-coupon-code:focus{border-style:dotted;border-color:inherit;border-width:thin;}input{outline:none;}.ast-logo-title-inline .site-logo-img{padding-right:1em;}.site-logo-img img{ transition:all 0.2s linear;}body .ast-oembed-container *{position:absolute;top:0;width:100%;height:100%;left:0;}body .wp-block-embed-pocket-casts .ast-oembed-container *{position:unset;}.ast-single-post-featured-section + article {margin-top: 2em;}.site-content .ast-single-post-featured-section img {width: 100%;overflow: hidden;object-fit: cover;}.ast-separate-container .site-content .ast-single-post-featured-section + article {margin-top: -80px;z-index: 9;position: relative;border-radius: 4px;}@media (min-width: 922px) {.ast-no-sidebar .site-content .ast-article-image-container--wide {margin-left: -120px;margin-right: -120px;max-width: unset;width: unset;}.ast-left-sidebar .site-content .ast-article-image-container--wide,.ast-right-sidebar .site-content .ast-article-image-container--wide {margin-left: -10px;margin-right: -10px;}.site-content .ast-article-image-container--full {margin-left: calc( -50vw + 50%);margin-right: calc( -50vw + 50%);max-width: 100vw;width: 100vw;}.ast-left-sidebar .site-content .ast-article-image-container--full,.ast-right-sidebar .site-content .ast-article-image-container--full {margin-left: -10px;margin-right: -10px;max-width: inherit;width: auto;}}.site > .ast-single-related-posts-container {margin-top: 0;}@media (min-width: 922px) {.ast-desktop .ast-container--narrow {max-width: var(--ast-narrow-container-width);margin: 0 auto;}}.ast-page-builder-template .hentry {margin: 0;}.ast-page-builder-template .site-content > .ast-container {max-width: 100%;padding: 0;}.ast-page-builder-template .site .site-content #primary {padding: 0;margin: 0;}.ast-page-builder-template .no-results {text-align: center;margin: 4em auto;}.ast-page-builder-template .ast-pagination {padding: 2em;}.ast-page-builder-template .entry-header.ast-no-title.ast-no-thumbnail {margin-top: 0;}.ast-page-builder-template .entry-header.ast-header-without-markup {margin-top: 0;margin-bottom: 0;}.ast-page-builder-template .entry-header.ast-no-title.ast-no-meta {margin-bottom: 0;}.ast-page-builder-template.single .post-navigation {padding-bottom: 2em;}.ast-page-builder-template.single-post .site-content > .ast-container {max-width: 100%;}.ast-page-builder-template .entry-header {margin-top: 2em;margin-left: auto;margin-right: auto;}.ast-page-builder-template .ast-archive-description {margin: 2em auto 0;padding-left: 20px;padding-right: 20px;}.ast-page-builder-template .ast-row {margin-left: 0;margin-right: 0;}.single.ast-page-builder-template .entry-header + .entry-content,.single.ast-page-builder-template .ast-single-entry-banner + .site-content article .entry-content {margin-bottom: 2em;}@media(min-width: 921px) {.ast-page-builder-template.archive.ast-right-sidebar .ast-row article,.ast-page-builder-template.archive.ast-left-sidebar .ast-row article {padding-left: 0;padding-right: 0;}}input[type="text"],input[type="number"],input[type="email"],input[type="url"],input[type="password"],input[type="search"],input[type=reset],input[type=tel],input[type=date],select,textarea{font-size:16px;font-style:normal;font-weight:400;line-height:24px;width:100%;padding:12px 16px;border-radius:4px;box-shadow:0px 1px 2px 0px rgba(0,0,0,0.05);color:var(--ast-form-input-text,#475569);}input[type="text"],input[type="number"],input[type="email"],input[type="url"],input[type="password"],input[type="search"],input[type=reset],input[type=tel],input[type=date],select{height:40px;}input[type="date"]{border-width:1px;border-style:solid;border-color:var(--ast-border-color);background:var( --ast-global-color-secondary,--ast-global-color-5 );}input[type="text"]:focus,input[type="number"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="search"]:focus,input[type=reset]:focus,input[type="tel"]:focus,input[type="date"]:focus,select:focus,textarea:focus{border-color:#046BD2;box-shadow:none;outline:none;color:var(--ast-form-input-focus-text,#475569);}label,legend{color:#111827;font-size:14px;font-style:normal;font-weight:500;line-height:20px;}select{padding:6px 10px;}fieldset{padding:30px;border-radius:4px;}button,.ast-button,.button,input[type="button"],input[type="reset"],input[type="submit"]{border-radius:4px;box-shadow:0px 1px 2px 0px rgba(0,0,0,0.05);}:root{--ast-comment-inputs-background:#FFF;}::placeholder{color:var(--ast-form-field-color,#9CA3AF);}::-ms-input-placeholder{color:var(--ast-form-field-color,#9CA3AF);}@media (max-width:921.9px){#ast-desktop-header{display:none;}}@media (min-width:922px){#ast-mobile-header{display:none;}}.wp-block-buttons.aligncenter{justify-content:center;}@media (max-width:921px){.ast-theme-transparent-header #primary,.ast-theme-transparent-header #secondary{padding:0;}}@media (max-width:921px){.ast-plain-container.ast-no-sidebar #primary{padding:0;}}.ast-plain-container.ast-no-sidebar #primary{margin-top:0;margin-bottom:0;}.wp-block-button.is-style-outline .wp-block-button__link{border-color:var(--ast-global-color-0);}div.wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color),div.wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color){color:var(--ast-global-color-0);}.wp-block-button.is-style-outline .wp-block-button__link:hover,.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color):hover,.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.post-page-numbers.current .page-link,.ast-pagination .page-numbers.current{color:#000000;border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);}.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,.ast-outline-button,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button{border-color:var(--ast-global-color-0);border-top-width:2px;border-right-width:2px;border-bottom-width:2px;border-left-width:2px;font-family:inherit;font-weight:500;font-size:16px;font-size:1rem;line-height:1em;padding-top:13px;padding-right:30px;padding-bottom:13px;padding-left:30px;}.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color),.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color),.ast-outline-button{color:var(--ast-global-color-0);}.wp-block-button.is-style-outline .wp-block-button__link:hover,.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color):hover,.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover,.ast-outline-button:hover,.ast-outline-button:focus,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:hover,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.ast-single-post .entry-content a.ast-outline-button,.ast-single-post .entry-content .is-style-outline>.wp-block-button__link{text-decoration:none;}.wp-block-button .wp-block-button__link.wp-element-button.is-style-outline:not(.has-background),.wp-block-button.is-style-outline>.wp-block-button__link.wp-element-button:not(.has-background),.ast-outline-button{background-color:transparent;}.uagb-buttons-repeater.ast-outline-button{border-radius:9999px;}@media (max-width:921px){.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,.ast-outline-button,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button{padding-top:12px;padding-right:28px;padding-bottom:12px;padding-left:28px;}}@media (max-width:544px){.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,.ast-outline-button,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button{padding-top:10px;padding-right:24px;padding-bottom:10px;padding-left:24px;}}.entry-content[data-ast-blocks-layout] > figure{margin-bottom:1em;}h1.widget-title{font-weight:700;}h2.widget-title{font-weight:700;}h3.widget-title{font-weight:700;}#page{display:flex;flex-direction:column;min-height:100vh;}.ast-404-layout-1 h1.page-title{color:var(--ast-global-color-2);}.single .post-navigation a{line-height:1em;height:inherit;}.error-404 .page-sub-title{font-size:1.5rem;font-weight:inherit;}.search .site-content .content-area .search-form{margin-bottom:0;}#page .site-content{flex-grow:1;}.widget{margin-bottom:1.25em;}#secondary li{line-height:1.5em;}#secondary .wp-block-group h2{margin-bottom:0.7em;}#secondary h2{font-size:1.7rem;}.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single,.ast-separate-container .comment-respond{padding:3em;}.ast-separate-container .ast-article-single .ast-article-single{padding:0;}.ast-article-single .wp-block-post-template-is-layout-grid{padding-left:0;}.ast-separate-container .comments-title,.ast-narrow-container .comments-title{padding:1.5em 2em;}.ast-page-builder-template .comment-form-textarea,.ast-comment-formwrap .ast-grid-common-col{padding:0;}.ast-comment-formwrap{padding:0;display:inline-flex;column-gap:20px;width:100%;margin-left:0;margin-right:0;}.comments-area textarea#comment:focus,.comments-area textarea#comment:active,.comments-area .ast-comment-formwrap input[type="text"]:focus,.comments-area .ast-comment-formwrap input[type="text"]:active {box-shadow:none;outline:none;}.archive.ast-page-builder-template .entry-header{margin-top:2em;}.ast-page-builder-template .ast-comment-formwrap{width:100%;}.entry-title{margin-bottom:0.6em;}.ast-archive-description p{font-size:inherit;font-weight:inherit;line-height:inherit;}.ast-separate-container .ast-comment-list li.depth-1,.hentry{margin-bottom:1.5em;}.site-content section.ast-archive-description{margin-bottom:2em;}@media (min-width:921px){.ast-left-sidebar.ast-page-builder-template #secondary,.archive.ast-right-sidebar.ast-page-builder-template .site-main{padding-left:20px;padding-right:20px;}}@media (max-width:544px){.ast-comment-formwrap.ast-row{column-gap:10px;display:inline-block;}#ast-commentform .ast-grid-common-col{position:relative;width:100%;}}@media (min-width:1201px){.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single,.ast-separate-container .ast-author-box,.ast-separate-container .ast-404-layout-1,.ast-separate-container .no-results{padding:3em;}}@media (max-width:921px){.ast-separate-container #primary,.ast-separate-container #secondary{padding:1.5em 0;}#primary,#secondary{padding:1.5em 0;margin:0;}.ast-left-sidebar #content > .ast-container{display:flex;flex-direction:column-reverse;width:100%;}}@media (min-width:922px){.ast-separate-container.ast-right-sidebar #primary,.ast-separate-container.ast-left-sidebar #primary{border:0;}.search-no-results.ast-separate-container #primary{margin-bottom:4em;}}.elementor-widget-button .elementor-button{border-style:solid;text-decoration:none;border-top-width:0;border-right-width:0;border-left-width:0;border-bottom-width:0;}.elementor-button.elementor-size-sm,.elementor-button.elementor-size-xs,.elementor-button.elementor-size-md,.elementor-button.elementor-size-lg,.elementor-button.elementor-size-xl,.elementor-button{padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px;}@media (max-width:921px){.elementor-widget-button .elementor-button.elementor-size-sm,.elementor-widget-button .elementor-button.elementor-size-xs,.elementor-widget-button .elementor-button.elementor-size-md,.elementor-widget-button .elementor-button.elementor-size-lg,.elementor-widget-button .elementor-button.elementor-size-xl,.elementor-widget-button .elementor-button{padding-top:14px;padding-right:28px;padding-bottom:14px;padding-left:28px;}}@media (max-width:544px){.elementor-widget-button .elementor-button.elementor-size-sm,.elementor-widget-button .elementor-button.elementor-size-xs,.elementor-widget-button .elementor-button.elementor-size-md,.elementor-widget-button .elementor-button.elementor-size-lg,.elementor-widget-button .elementor-button.elementor-size-xl,.elementor-widget-button .elementor-button{padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px;}}.elementor-widget-button .elementor-button{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);}.elementor-widget-button .elementor-button:hover,.elementor-widget-button .elementor-button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.wp-block-button .wp-block-button__link ,.elementor-widget-button .elementor-button,.elementor-widget-button .elementor-button:visited{color:var(--ast-global-color-2);}.elementor-widget-button .elementor-button{font-weight:600;font-size:16px;font-size:1rem;line-height:1em;text-transform:uppercase;letter-spacing:2px;}body .elementor-button.elementor-size-sm,body .elementor-button.elementor-size-xs,body .elementor-button.elementor-size-md,body .elementor-button.elementor-size-lg,body .elementor-button.elementor-size-xl,body .elementor-button{font-size:16px;font-size:1rem;}.wp-block-button .wp-block-button__link:hover,.wp-block-button .wp-block-button__link:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.elementor-widget-heading h1.elementor-heading-title{line-height:1.1em;}.elementor-widget-heading h2.elementor-heading-title{line-height:1.3em;}.elementor-widget-heading h3.elementor-heading-title{line-height:1.3em;}.elementor-widget-heading h4.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h5.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h6.elementor-heading-title{line-height:1.25em;}.wp-block-button .wp-block-button__link,.wp-block-search .wp-block-search__button,body .wp-block-file .wp-block-file__button{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);color:var(--ast-global-color-2);font-family:inherit;font-weight:600;line-height:1em;text-transform:uppercase;letter-spacing:2px;font-size:16px;font-size:1rem;padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px;}.ast-single-post .entry-content .wp-block-button .wp-block-button__link,.ast-single-post .entry-content .wp-block-search .wp-block-search__button,body .entry-content .wp-block-file .wp-block-file__button{text-decoration:none;}@media (max-width:921px){.wp-block-button .wp-block-button__link,.wp-block-search .wp-block-search__button,body .wp-block-file .wp-block-file__button{padding-top:14px;padding-right:28px;padding-bottom:14px;padding-left:28px;}}@media (max-width:544px){.wp-block-button .wp-block-button__link,.wp-block-search .wp-block-search__button,body .wp-block-file .wp-block-file__button{padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px;}}.menu-toggle,button,.ast-button,.ast-custom-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"],#comments .submit,.search .search-submit,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,body .wp-block-file .wp-block-file__button,.search .search-submit{border-style:solid;border-top-width:0;border-right-width:0;border-left-width:0;border-bottom-width:0;color:var(--ast-global-color-2);border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px;font-family:inherit;font-weight:600;font-size:16px;font-size:1rem;line-height:1em;text-transform:uppercase;letter-spacing:2px;}button:focus,.menu-toggle:hover,button:hover,.ast-button:hover,.ast-custom-button:hover .button:hover,.ast-custom-button:hover ,input[type=reset]:hover,input[type=reset]:focus,input#submit:hover,input#submit:focus,input[type="button"]:hover,input[type="button"]:focus,input[type="submit"]:hover,input[type="submit"]:focus,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:hover,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:focus,body .wp-block-file .wp-block-file__button:hover,body .wp-block-file .wp-block-file__button:focus{color:var(--ast-global-color-2);background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button.has-icon{padding-top:calc(15px - 3px);padding-right:calc(30px - 3px);padding-bottom:calc(15px - 3px);padding-left:calc(30px - 3px);}@media (max-width:921px){.menu-toggle,button,.ast-button,.ast-custom-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"],#comments .submit,.search .search-submit,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,body .wp-block-file .wp-block-file__button,.search .search-submit{padding-top:14px;padding-right:28px;padding-bottom:14px;padding-left:28px;}}@media (max-width:544px){.menu-toggle,button,.ast-button,.ast-custom-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"],#comments .submit,.search .search-submit,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,body .wp-block-file .wp-block-file__button,.search .search-submit{padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px;}}@media (max-width:921px){.ast-mobile-header-stack .main-header-bar .ast-search-menu-icon{display:inline-block;}.ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon{margin:0;}.ast-comment-avatar-wrap img{max-width:2.5em;}.ast-comment-meta{padding:0 1.8888em 1.3333em;}}@media (min-width:544px){.ast-container{max-width:100%;}}@media (max-width:544px){.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single,.ast-separate-container .comments-title,.ast-separate-container .ast-archive-description{padding:1.5em 1em;}.ast-separate-container #content .ast-container{padding-left:0.54em;padding-right:0.54em;}.ast-separate-container .ast-comment-list .bypostauthor{padding:.5em;}.ast-search-menu-icon.ast-dropdown-active .search-field{width:170px;}} #ast-mobile-header .ast-site-header-cart-li a{pointer-events:none;}.ast-separate-container{background-color:var(--ast-global-color-5);background-image:none;}@media (max-width:921px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content :where(h1){font-size:44px;font-size:2.75rem;}h2,.entry-content :where(h2){font-size:32px;font-size:2rem;}h3,.entry-content :where(h3){font-size:26px;font-size:1.625rem;}h4,.entry-content :where(h4){font-size:22px;font-size:1.375rem;}h5,.entry-content :where(h5){font-size:20px;font-size:1.25rem;}h6,.entry-content :where(h6){font-size:18px;font-size:1.125rem;}}@media (max-width:544px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content :where(h1){font-size:36px;font-size:2.25rem;}h2,.entry-content :where(h2){font-size:30px;font-size:1.875rem;}h3,.entry-content :where(h3){font-size:26px;font-size:1.625rem;}h4,.entry-content :where(h4){font-size:24px;font-size:1.5rem;}h5,.entry-content :where(h5){font-size:20px;font-size:1.25rem;}h6,.entry-content :where(h6){font-size:18px;font-size:1.125rem;}header .custom-logo-link img,.ast-header-break-point .site-branding img,.ast-header-break-point .custom-logo-link img{max-width:80px;width:80px;}.astra-logo-svg{width:80px;}.astra-logo-svg:not(.sticky-custom-logo .astra-logo-svg,.transparent-custom-logo .astra-logo-svg,.advanced-header-logo .astra-logo-svg){height:19px;}.ast-header-break-point .site-logo-img .custom-mobile-logo-link img{max-width:80px;}}@media (max-width:921px){html{font-size:91.2%;}}@media (max-width:544px){html{font-size:91.2%;}}@media (min-width:922px){.ast-container{max-width:1240px;}}@media (min-width:922px){.site-content .ast-container{display:flex;}}@media (max-width:921px){.site-content .ast-container{flex-direction:column;}}.entry-content :where(h1,h2,h3,h4,h5,h6){clear:none;}@media (min-width:922px){.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover > .sub-menu,.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus > .sub-menu{margin-left:-0px;}}.ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal{background:transparent;}.entry-content li > p{margin-bottom:0;}.site .comments-area{padding-bottom:2em;margin-top:0em;}.wp-block-file {display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;}.wp-block-pullquote {border: none;}.wp-block-pullquote blockquote::before {content: "\201D";font-family: "Helvetica",sans-serif;display: flex;transform: rotate( 180deg );font-size: 6rem;font-style: normal;line-height: 1;font-weight: bold;align-items: center;justify-content: center;}.has-text-align-right > blockquote::before {justify-content: flex-start;}.has-text-align-left > blockquote::before {justify-content: flex-end;}figure.wp-block-pullquote.is-style-solid-color blockquote {max-width: 100%;text-align: inherit;}:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 3em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 3em;--wp--custom--ast-container-width: 1200px;--wp--custom--ast-content-width-size: 1200px;--wp--custom--ast-wide-width-size: calc(1200px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));}.ast-narrow-container {--wp--custom--ast-content-width-size: 750px;--wp--custom--ast-wide-width-size: 750px;}@media(max-width: 921px) {:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 2em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 2em;}}@media(max-width: 544px) {:root {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 1.5em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 1.5em;}}.entry-content > .wp-block-group,.entry-content > .wp-block-cover,.entry-content > .wp-block-columns {padding-top: var(--wp--custom--ast-default-block-top-padding);padding-right: var(--wp--custom--ast-default-block-right-padding);padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);padding-left: var(--wp--custom--ast-default-block-left-padding);}.ast-plain-container.ast-no-sidebar .entry-content > .alignfull,.ast-page-builder-template .ast-no-sidebar .entry-content > .alignfull {margin-left: calc( -50vw + 50%);margin-right: calc( -50vw + 50%);max-width: 100vw;width: 100vw;}.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {margin-left: auto;margin-right: auto;width: 100%;}[data-ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {height: 0;}[data-ast-blocks-layout] .wp-block-separator {margin: 20px auto;}[data-ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {max-width: 100px;}[data-ast-blocks-layout] .wp-block-separator.has-background {padding: 0;}.entry-content[data-ast-blocks-layout] > * {max-width: var(--wp--custom--ast-content-width-size);margin-left: auto;margin-right: auto;}.entry-content[data-ast-blocks-layout] > .alignwide {max-width: var(--wp--custom--ast-wide-width-size);}.entry-content[data-ast-blocks-layout] .alignfull {max-width: none;}.entry-content .wp-block-columns {margin-bottom: 0;}blockquote {margin: 1.5em;border-color: rgba(0,0,0,0.05);}.wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {border-left: 5px solid rgba(0,0,0,0.05);}.has-text-align-right > blockquote,blockquote.has-text-align-right {border-right: 5px solid rgba(0,0,0,0.05);}.has-text-align-left > blockquote,blockquote.has-text-align-left {border-left: 5px solid rgba(0,0,0,0.05);}.wp-block-site-tagline,.wp-block-latest-posts .read-more {margin-top: 15px;}.wp-block-loginout p label {display: block;}.wp-block-loginout p:not(.login-remember):not(.login-submit) input {width: 100%;}.wp-block-loginout input:focus {border-color: transparent;}.wp-block-loginout input:focus {outline: thin dotted;}.entry-content .wp-block-media-text .wp-block-media-text__content {padding: 0 0 0 8%;}.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 0 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}.entry-content .wp-block-cover:not([class*="background-color"]):not(.has-text-color.has-link-color) .wp-block-cover__inner-container,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover__inner-container,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-text {color: var(--ast-global-color-primary,var(--ast-global-color-5));}.wp-block-loginout .login-remember input {width: 1.1rem;height: 1.1rem;margin: 0 5px 4px 0;vertical-align: middle;}.wp-block-latest-posts > li > *:first-child,.wp-block-latest-posts:not(.is-grid) > li:first-child {margin-top: 0;}.entry-content > .wp-block-buttons,.entry-content > .wp-block-uagb-buttons {margin-bottom: 1.5em;}.wp-block-search__inside-wrapper .wp-block-search__input {padding: 0 10px;color: var(--ast-global-color-3);background: var(--ast-global-color-primary,var(--ast-global-color-5));border-color: var(--ast-border-color);}.wp-block-latest-posts .read-more {margin-bottom: 1.5em;}.wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {padding-top: 5px;padding-bottom: 5px;}.wp-block-latest-posts .wp-block-latest-posts__post-date,.wp-block-latest-posts .wp-block-latest-posts__post-author {font-size: 1rem;}.wp-block-latest-posts > li > *,.wp-block-latest-posts:not(.is-grid) > li {margin-top: 12px;margin-bottom: 12px;}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > *,.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .alignfull:not(.wp-block-group):not(.uagb-is-root-container) > * {max-width: none;}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .alignwide:not(.uagb-is-root-container) > * {max-width: var(--wp--custom--ast-wide-width-size);}.ast-page-builder-template .entry-content[data-ast-blocks-layout] > .inherit-container-width > *,.ast-page-builder-template .entry-content[data-ast-blocks-layout] > *:not(.wp-block-group):not(.uagb-is-root-container) > *,.entry-content[data-ast-blocks-layout] > .wp-block-cover .wp-block-cover__inner-container {max-width: none ;margin-left: auto;margin-right: auto;}.entry-content[data-ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {width: auto;}@media(max-width: 1200px) {.ast-separate-container .entry-content > .alignfull,.ast-separate-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content .alignfull {margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding),20px)) ;margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding),20px));}}@media(min-width: 1201px) {.ast-separate-container .entry-content > .alignfull {margin-left: calc(-1 * var(--ast-container-default-xlg-padding) );margin-right: calc(-1 * var(--ast-container-default-xlg-padding) );}.ast-separate-container .entry-content[data-ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[data-ast-blocks-layout] > .alignwide {margin-left: auto;margin-right: auto;}}@media(min-width: 921px) {.ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)),.ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)) {max-width: calc( var(--wp--custom--ast-content-width-size) + 80px );}.ast-plain-container.ast-right-sidebar .entry-content[data-ast-blocks-layout] .alignfull,.ast-plain-container.ast-left-sidebar .entry-content[data-ast-blocks-layout] .alignfull {margin-left: -60px;margin-right: -60px;}}@media(min-width: 544px) {.entry-content > .alignleft {margin-right: 20px;}.entry-content > .alignright {margin-left: 20px;}}@media (max-width:544px){.wp-block-columns .wp-block-column:not(:last-child){margin-bottom:20px;}.wp-block-latest-posts{margin:0;}}@media( max-width: 600px ) {.entry-content .wp-block-media-text .wp-block-media-text__content,.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}}.ast-page-builder-template .entry-header {padding-left: 0;}.ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {max-width: 100%;margin-left: auto;margin-right: auto;}.entry-content ul,.entry-content ol {padding: revert;margin: revert;padding-left: 20px;}:root .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root{--ast-global-color-0:#cbff54;--ast-global-color-1:#b4f625;--ast-global-color-2:#063231;--ast-global-color-3:#495b55;--ast-global-color-4:#f6f7f7;--ast-global-color-5:#ffffff;--ast-global-color-6:#e0e7e3;--ast-global-color-7:#D1D5DB;--ast-global-color-8:#033231;}:root {--ast-border-color : var(--ast-global-color-7);}.ast-single-entry-banner {-js-display: flex;display: flex;flex-direction: column;justify-content: center;text-align: center;position: relative;background: var(--ast-title-layout-bg);}.ast-single-entry-banner[data-banner-layout="layout-1"] {max-width: 1200px;background: inherit;padding: 20px 0;}.ast-single-entry-banner[data-banner-width-type="custom"] {margin: 0 auto;width: 100%;}.ast-single-entry-banner + .site-content .entry-header {margin-bottom: 0;}.site .ast-author-avatar {--ast-author-avatar-size: ;}a.ast-underline-text {text-decoration: underline;}.ast-container > .ast-terms-link {position: relative;display: block;}a.ast-button.ast-badge-tax {padding: 4px 8px;border-radius: 3px;font-size: inherit;}header.entry-header:not(.related-entry-header) .entry-title{font-weight:600;font-size:32px;font-size:2rem;}header.entry-header:not(.related-entry-header) > *:not(:last-child){margin-bottom:10px;}header.entry-header:not(.related-entry-header) .post-thumb-img-content{text-align:center;}header.entry-header:not(.related-entry-header) .post-thumb img,.ast-single-post-featured-section.post-thumb img{aspect-ratio:16/9;width:100%;height:100%;}.ast-archive-entry-banner {-js-display: flex;display: flex;flex-direction: column;justify-content: center;text-align: center;position: relative;background: var(--ast-title-layout-bg);}.ast-archive-entry-banner[data-banner-width-type="custom"] {margin: 0 auto;width: 100%;}.ast-archive-entry-banner[data-banner-layout="layout-1"] {background: inherit;padding: 20px 0;text-align: left;}body.archive .ast-archive-description{max-width:1200px;width:100%;text-align:left;padding-top:3em;padding-right:3em;padding-bottom:3em;padding-left:3em;}body.archive .ast-archive-description .ast-archive-title,body.archive .ast-archive-description .ast-archive-title *{font-weight:600;font-size:32px;font-size:2rem;}body.archive .ast-archive-description > *:not(:last-child){margin-bottom:10px;}@media (max-width:921px){body.archive .ast-archive-description{text-align:left;}}@media (max-width:544px){body.archive .ast-archive-description{text-align:left;}}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg{width:150px;}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img{ max-width:150px; width:150px;}@media (max-width:921px){.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg{width:120px;}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img{ max-width:120px; width:120px;}}@media (max-width:543px){.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg{width:100px;}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img{ max-width:100px; width:100px;}}@media (min-width:921px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar,.ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead,.fl-builder-edit .ast-theme-transparent-header #masthead,body.vc_editor.ast-theme-transparent-header #masthead,body.brz-ed.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header,.ast-theme-transparent-header .ast-above-header.ast-above-header-bar{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header,.ast-theme-transparent-header .ast-below-header.ast-below-header-bar{background-image:none;background-color:transparent;}}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu .menu-link,.ast-theme-transparent-header .main-header-menu .menu-item .sub-menu .menu-link{background-color:transparent;}@media (max-width:921px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar,.ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead,.fl-builder-edit .ast-theme-transparent-header #masthead,body.vc_editor.ast-theme-transparent-header #masthead,body.brz-ed.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header,.ast-theme-transparent-header .ast-above-header.ast-above-header-bar{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header,.ast-theme-transparent-header .ast-below-header.ast-below-header-bar{background-image:none;background-color:transparent;}}.ast-theme-transparent-header #ast-desktop-header > .ast-main-header-wrap > .main-header-bar,.ast-theme-transparent-header.ast-header-break-point #ast-mobile-header > .ast-main-header-wrap > .main-header-bar{border-bottom-width:0px;border-bottom-style:solid;}.ast-breadcrumbs .trail-browse,.ast-breadcrumbs .trail-items,.ast-breadcrumbs .trail-items li{display:inline-block;margin:0;padding:0;border:none;background:inherit;text-indent:0;text-decoration:none;}.ast-breadcrumbs .trail-browse{font-size:inherit;font-style:inherit;font-weight:inherit;color:inherit;}.ast-breadcrumbs .trail-items{list-style:none;}.trail-items li::after{padding:0 0.3em;content:"\00bb";}.trail-items li:last-of-type::after{display:none;}h1,h2,h3,h4,h5,h6,.entry-content :where(h1,h2,h3,h4,h5,h6){color:var(--ast-global-color-2);}.entry-title a{color:var(--ast-global-color-2);}@media (max-width:921px){.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}@media (max-width:544px){.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}@media (max-width:544px){.ast-builder-layout-element .ast-site-identity{margin-top:24px;margin-bottom:24px;margin-left:24px;margin-right:24px;}}.ast-builder-layout-element[data-section="title_tagline"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}[data-section*="section-hb-button-"] .menu-link{display:none;}.ast-header-button-1 .ast-custom-button{border-top-left-radius:40px;border-top-right-radius:40px;border-bottom-right-radius:40px;border-bottom-left-radius:40px;}.ast-header-button-1[data-section*="section-hb-button-"] .ast-builder-button-wrap .ast-custom-button{padding-top:15px;padding-bottom:15px;padding-left:30px;padding-right:30px;}.ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"]{display:flex;}}.ast-builder-menu-1{font-family:inherit;font-weight:inherit;}.ast-builder-menu-1 .menu-item > .menu-link{color:#ffffff;}.ast-builder-menu-1 .menu-item > .ast-menu-toggle{color:#ffffff;}.ast-builder-menu-1 .menu-item:hover > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item.current-menu-item > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-1 .current-menu-ancestor > .menu-link{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item.current-menu-item > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .sub-menu,.ast-builder-menu-1 .inline-on-mobile .sub-menu{border-top-width:2px;border-bottom-width:0px;border-right-width:0px;border-left-width:0px;border-color:#ffffff;border-style:solid;}.ast-builder-menu-1 .sub-menu .sub-menu{top:-2px;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0px;}.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu:before,.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper:before{height:calc( 0px + 2px + 5px );}.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link{border-style:none;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-1 .inline-on-mobile .menu-item.menu-item-has-children > .ast-menu-toggle{right:-15px;}.ast-builder-menu-1 .menu-item-has-children > .menu-link:after{content:unset;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}}.ast-builder-menu-1{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}.ast-desktop .ast-menu-hover-style-underline > .menu-item > .menu-link:before,.ast-desktop .ast-menu-hover-style-overline > .menu-item > .menu-link:before {content: "";position: absolute;width: 100%;right: 50%;height: 1px;background-color: transparent;transform: scale(0,0) translate(-50%,0);transition: transform .3s ease-in-out,color .0s ease-in-out;}.ast-desktop .ast-menu-hover-style-underline > .menu-item:hover > .menu-link:before,.ast-desktop .ast-menu-hover-style-overline > .menu-item:hover > .menu-link:before {width: calc(100% - 1.2em);background-color: currentColor;transform: scale(1,1) translate(50%,0);}.ast-desktop .ast-menu-hover-style-underline > .menu-item > .menu-link:before {bottom: 0;}.ast-desktop .ast-menu-hover-style-overline > .menu-item > .menu-link:before {top: 0;}.ast-desktop .ast-menu-hover-style-zoom > .menu-item > .menu-link:hover {transition: all .3s ease;transform: scale(1.2);}.footer-widget-area.widget-area.site-footer-focus-item{width:auto;}.ast-footer-row-inline .footer-widget-area.widget-area.site-footer-focus-item{width:100%;}.elementor-widget-heading .elementor-heading-title{margin:0;}.elementor-page .ast-menu-toggle{color:unset !important;background:unset !important;}.elementor-post.elementor-grid-item.hentry{margin-bottom:0;}.woocommerce div.product .elementor-element.elementor-products-grid .related.products ul.products li.product,.elementor-element .elementor-wc-products .woocommerce[class*='columns-'] ul.products li.product{width:auto;margin:0;float:none;}.elementor-toc__list-wrapper{margin:0;}body .elementor hr{background-color:#ccc;margin:0;}.ast-left-sidebar .elementor-section.elementor-section-stretched,.ast-right-sidebar .elementor-section.elementor-section-stretched{max-width:100%;left:0 !important;}.elementor-posts-container [CLASS*="ast-width-"]{width:100%;}.elementor-template-full-width .ast-container{display:block;}.elementor-screen-only,.screen-reader-text,.screen-reader-text span,.ui-helper-hidden-accessible{top:0 !important;}@media (max-width:544px){.elementor-element .elementor-wc-products .woocommerce[class*="columns-"] ul.products li.product{width:auto;margin:0;}.elementor-element .woocommerce .woocommerce-result-count{float:none;}}.ast-header-button-1 .ast-custom-button{box-shadow:0px 0px 0px 0px rgba(0,0,0,0.1);}.ast-desktop .ast-mega-menu-enabled .ast-builder-menu-1 div:not( .astra-full-megamenu-wrapper) .sub-menu,.ast-builder-menu-1 .inline-on-mobile .sub-menu,.ast-desktop .ast-builder-menu-1 .astra-full-megamenu-wrapper,.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu{box-shadow:0px 4px 10px -2px rgba(0,0,0,0.1);}.ast-desktop .ast-mobile-popup-drawer.active .ast-mobile-popup-inner{max-width:35%;}@media (max-width:921px){.ast-mobile-popup-drawer.active .ast-mobile-popup-inner{max-width:90%;}}@media (max-width:544px){.ast-mobile-popup-drawer.active .ast-mobile-popup-inner{max-width:90%;}}.ast-header-break-point .main-header-bar{border-bottom-width:1px;}@media (min-width:922px){.main-header-bar{border-bottom-width:1px;}}.main-header-menu .menu-item,#astra-footer-menu .menu-item,.main-header-bar .ast-masthead-custom-menu-items{-js-display:flex;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;}.main-header-menu > .menu-item > .menu-link,#astra-footer-menu > .menu-item > .menu-link{height:100%;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-js-display:flex;display:flex;}.ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg{top:.2em;margin-top:0px;margin-left:0px;width:.65em;transform:translate(0,-2px) rotateZ(270deg);}.ast-mobile-popup-content .ast-submenu-expanded > .ast-menu-toggle{transform:rotateX(180deg);overflow-y:auto;}@media (min-width:922px){.ast-builder-menu .main-navigation > ul > li:last-child a{margin-right:0;}}.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-4);background-image:none;}@media (max-width:921px){.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-4);background-image:none;}}@media (max-width:544px){.ast-separate-container .ast-article-inner{background-color:var(--ast-global-color-4);background-image:none;}}.ast-separate-container .ast-article-single:not(.ast-related-post),.ast-separate-container .error-404,.ast-separate-container .no-results,.single.ast-separate-container .site-main .ast-author-meta,.ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper,.ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content,.ast-separate-container .ast-archive-description,.ast-separate-container .comments-area{background-color:var(--ast-global-color-4);background-image:none;}@media (max-width:921px){.ast-separate-container .ast-article-single:not(.ast-related-post),.ast-separate-container .error-404,.ast-separate-container .no-results,.single.ast-separate-container .site-main .ast-author-meta,.ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper,.ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content,.ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-4);background-image:none;}}@media (max-width:544px){.ast-separate-container .ast-article-single:not(.ast-related-post),.ast-separate-container .error-404,.ast-separate-container .no-results,.single.ast-separate-container .site-main .ast-author-meta,.ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper,.ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content,.ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-4);background-image:none;}}.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-4);background-image:none;}@media (max-width:921px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-4);background-image:none;}}@media (max-width:544px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-4);background-image:none;}}.ast-plain-container,.ast-page-builder-template{background-color:var(--ast-global-color-4);background-image:none;}@media (max-width:921px){.ast-plain-container,.ast-page-builder-template{background-color:var(--ast-global-color-4);background-image:none;}}@media (max-width:544px){.ast-plain-container,.ast-page-builder-template{background-color:var(--ast-global-color-4);background-image:none;}}#ast-scroll-top {display: none;position: fixed;text-align: center;cursor: pointer;z-index: 99;width: 2.1em;height: 2.1em;line-height: 2.1;color: #ffffff;border-radius: 2px;content: "";outline: inherit;}@media (min-width: 769px) {#ast-scroll-top {content: "769";}}#ast-scroll-top .ast-icon.icon-arrow svg {margin-left: 0px;vertical-align: middle;transform: translate(0,-20%) rotate(180deg);width: 1.6em;}.ast-scroll-to-top-right {right: 30px;bottom: 30px;}.ast-scroll-to-top-left {left: 30px;bottom: 30px;}#ast-scroll-top{background-color:var(--ast-global-color-2);font-size:15px;}@media (max-width:921px){#ast-scroll-top .ast-icon.icon-arrow svg{width:1em;}}.ast-mobile-header-content > *,.ast-desktop-header-content > * {padding: 10px 0;height: auto;}.ast-mobile-header-content > *:first-child,.ast-desktop-header-content > *:first-child {padding-top: 10px;}.ast-mobile-header-content > .ast-builder-menu,.ast-desktop-header-content > .ast-builder-menu {padding-top: 0;}.ast-mobile-header-content > *:last-child,.ast-desktop-header-content > *:last-child {padding-bottom: 0;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {width: 100%;}.ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded > .ast-menu-toggle::before {transform: rotateX(180deg);}#ast-desktop-header .ast-desktop-header-content,.ast-mobile-header-content .ast-search-icon,.ast-desktop-header-content .ast-search-icon,.ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {display: none;}.ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,.ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {display: block;}.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item .menu-item > .sub-menu {opacity: 1;visibility: visible;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {width: unset;margin: unset;}.ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle,.ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle {left: calc( 20px - 0.907em);right: auto;}.ast-mobile-header-content .ast-search-menu-icon,.ast-mobile-header-content .ast-search-menu-icon.slide-search,.ast-desktop-header-content .ast-search-menu-icon,.ast-desktop-header-content .ast-search-menu-icon.slide-search {width: 100%;position: relative;display: block;right: auto;transform: none;}.ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,.ast-mobile-header-content .ast-search-menu-icon .search-form,.ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,.ast-desktop-header-content .ast-search-menu-icon .search-form {right: 0;visibility: visible;opacity: 1;position: relative;top: auto;transform: none;padding: 0;display: block;overflow: hidden;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-mobile-header-content .ast-search-menu-icon .search-field,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-desktop-header-content .ast-search-menu-icon .search-field {width: 100%;padding-right: 5.5em;}.ast-mobile-header-content .ast-search-menu-icon .search-submit,.ast-desktop-header-content .ast-search-menu-icon .search-submit {display: block;position: absolute;height: 100%;top: 0;right: 0;padding: 0 1em;border-radius: 0;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {padding-left: 30px;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {padding-left: 40px;}.ast-mobile-popup-drawer.active .ast-mobile-popup-inner{background-color:#ffffff;;}.ast-mobile-header-wrap .ast-mobile-header-content,.ast-desktop-header-content{background-color:#ffffff;;}.ast-mobile-popup-content > *,.ast-mobile-header-content > *,.ast-desktop-popup-content > *,.ast-desktop-header-content > *{padding-top:0px;padding-bottom:0px;}.content-align-flex-start .ast-builder-layout-element{justify-content:flex-start;}.content-align-flex-start .main-header-menu{text-align:left;}.ast-desktop-header-content,.ast-mobile-header-content{position:absolute;width:100%;}.ast-mobile-popup-drawer.active .menu-toggle-close{color:#3a3a3a;}.ast-mobile-header-wrap .ast-primary-header-bar,.ast-primary-header-bar .site-primary-header-wrap{min-height:80px;}.ast-desktop .ast-primary-header-bar .main-header-menu > .menu-item{line-height:80px;}.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-primary-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-below-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-above-header-bar{padding-left:20px;padding-right:20px;}.ast-header-break-point .ast-primary-header-bar{border-bottom-width:1px;border-bottom-color:var( --ast-global-color-subtle-background,--ast-global-color-7 );border-bottom-style:solid;}@media (min-width:922px){.ast-primary-header-bar{border-bottom-width:1px;border-bottom-color:var( --ast-global-color-subtle-background,--ast-global-color-7 );border-bottom-style:solid;}}.ast-primary-header-bar{background-color:var( --ast-global-color-primary,--ast-global-color-4 );background-image:none;}@media (max-width:921px){.ast-mobile-header-wrap .ast-primary-header-bar,.ast-primary-header-bar .site-primary-header-wrap{min-height:70px;}}@media (max-width:544px){.ast-mobile-header-wrap .ast-primary-header-bar ,.ast-primary-header-bar .site-primary-header-wrap{min-height:70px;}}@media (max-width:921px){.ast-desktop .ast-primary-header-bar.main-header-bar,.ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar{padding-top:0px;padding-left:32px;padding-right:32px;}}@media (max-width:544px){.ast-desktop .ast-primary-header-bar.main-header-bar,.ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar{padding-top:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;}}.ast-primary-header-bar{display:block;}@media (max-width:921px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}@media (max-width:544px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal{color:var(--ast-global-color-0);border:none;background:transparent;}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg{width:24px;height:24px;fill:var(--ast-global-color-0);}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu{color:var(--ast-global-color-0);}@media (max-width:544px){[data-section="section-header-mobile-trigger"] .ast-button-wrap .menu-toggle{margin-top:24px;margin-bottom:24px;margin-left:24px;margin-right:24px;}}.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item > .menu-link{color:var(--ast-global-color-3);}.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item > .ast-menu-toggle{color:var(--ast-global-color-3);}.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover > .menu-link,.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .menu-item:hover > .menu-link,.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item > .menu-link,.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor > .menu-link,.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-mobile .main-navigation .menu-item-has-children > .menu-link:after{content:unset;}.ast-hfb-header .ast-builder-menu-mobile .main-header-menu,.ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,.ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link{border-style:none;}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}@media (max-width:921px){.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item > .menu-link{color:#ffffff;padding-top:0px;padding-left:32px;padding-right:32px;}.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item > .ast-menu-toggle{color:#ffffff;}.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover > .menu-link,.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item > .menu-link,.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor > .menu-link,.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor > .ast-menu-toggle{color:var(--ast-global-color-1);background:rgba(255,255,255,0.31);}.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:0px;right:calc( 32px - 0.907em );}.ast-builder-menu-mobile .main-navigation .menu-item-has-children > .menu-link:after{content:unset;}.ast-builder-menu-mobile .main-navigation .main-header-menu ,.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-link,.ast-builder-menu-mobile .main-navigation .main-header-menu .sub-menu{background-color:var(--ast-global-color-2);background-image:none;}}@media (max-width:544px){.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item > .menu-link{padding-top:1px;padding-bottom:1px;padding-left:24px;padding-right:24px;}.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children > .ast-menu-toggle{top:1px;right:calc( 24px - 0.907em );}}.ast-builder-menu-mobile .main-navigation{display:block;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-mobile .main-navigation{display:block;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-mobile .main-navigation{display:block;}}:root{--e-global-color-astglobalcolor0:#cbff54;--e-global-color-astglobalcolor1:#b4f625;--e-global-color-astglobalcolor2:#063231;--e-global-color-astglobalcolor3:#495b55;--e-global-color-astglobalcolor4:#f6f7f7;--e-global-color-astglobalcolor5:#ffffff;--e-global-color-astglobalcolor6:#e0e7e3;--e-global-color-astglobalcolor7:#D1D5DB;--e-global-color-astglobalcolor8:#033231;}.ast-desktop .astra-menu-animation-slide-up>.menu-item>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu,.ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu .sub-menu{opacity:0;visibility:hidden;transform:translateY(.5em);transition:visibility .2s ease,transform .2s ease}.ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item:hover>.sub-menu,.ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.sub-menu{opacity:1;visibility:visible;transform:translateY(0);transition:opacity .2s ease,visibility .2s ease,transform .2s ease}.ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper{-js-display:flex;display:flex}.ast-desktop .astra-menu-animation-slide-down>.menu-item>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu,.ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu .sub-menu{opacity:0;visibility:hidden;transform:translateY(-.5em);transition:visibility .2s ease,transform .2s ease}.ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item:hover>.sub-menu,.ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.sub-menu{opacity:1;visibility:visible;transform:translateY(0);transition:opacity .2s ease,visibility .2s ease,transform .2s ease}.ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper{-js-display:flex;display:flex}.ast-desktop .astra-menu-animation-fade>.menu-item>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu,.ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu .sub-menu{opacity:0;visibility:hidden;transition:opacity ease-in-out .3s}.ast-desktop .astra-menu-animation-fade>.menu-item .menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-fade>.menu-item .menu-item:hover>.sub-menu,.ast-desktop .astra-menu-animation-fade>.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-fade>.menu-item.focus>.sub-menu,.ast-desktop .astra-menu-animation-fade>.menu-item:hover>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-fade>.menu-item:hover>.sub-menu{opacity:1;visibility:visible;transition:opacity ease-in-out .3s}.ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,.ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper{-js-display:flex;display:flex}.ast-desktop .menu-item.ast-menu-hover>.sub-menu.toggled-on{opacity:1;visibility:visible}
</style>

    <link rel='stylesheet' id='hfe-elementor-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
    <link rel='stylesheet' id='hfe-icons-list-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
    <link rel='stylesheet' id='hfe-social-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
    <link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
    <link rel='stylesheet' id='elementor-gf-local-roboto-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/google-fonts/css/roboto.css?ver=1752129083' media='all' />
    <link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/google-fonts/css/robotoslab.css?ver=1752129091' media='all' />
  

    <link rel="https://api.w.org/" href="https://websitedemos.net/brikly-construction-company-04/wp-json/" />
    <link rel="alternate" title="JSON" type="application/json" href="https://websitedemos.net/brikly-construction-company-04/wp-json/wp/v2/pages/6" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://websitedemos.net/brikly-construction-company-04/xmlrpc.php?rsd" />
    <meta name="generator" content="WordPress 6.8.2" />
    <!-- <link rel='shortlink' href='https://websitedemos.net/brikly-construction-company-04/' /> -->
    <link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://websitedemos.net/brikly-construction-company-04/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Fbrikly-construction-company-04%2F" />
    <link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://websitedemos.net/brikly-construction-company-04/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Fbrikly-construction-company-04%2F&#038;format=xml" />

    <!-- End Google Tag Manager -->
    <meta name="generator" content="Elementor 3.31.1; features: e_font_icon_svg, additional_custom_breakpoints, e_element_cache; settings: css_print_method-external, google_font-enabled, font_display-swap">
    <style>
        .e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
        .e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
            background-image: none !important;
        }

        @media screen and (max-height: 1024px) {

            .e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
            .e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
                background-image: none !important;
            }
        }

        @media screen and (max-height: 640px) {

            .e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
            .e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
                background-image: none !important;
            }
        }
    </style>
    <link rel="icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-32x32.png" sizes="32x32" />
    <link rel="icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-192x192.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-180x180.png" />
    <meta name="msapplication-TileImage" content="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-270x270.png" />
</head>

<?php echo $__env->make('website.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div id="ast-mobile-header" class="ast-mobile-header-wrap " data-type="dropdown">
                <div class="ast-main-header-wrap main-header-bar-wrap">
                    <div class="ast-primary-header-bar ast-primary-header main-header-bar site-primary-header-wrap site-header-focus-item ast-builder-grid-row-layout-default ast-builder-grid-row-tablet-layout-default ast-builder-grid-row-mobile-layout-default" data-section="section-primary-header-builder">
                        <div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
                            <div class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
                                <div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="title_tagline">
                                     <div
                                            class="site-branding ast-site-identity" itemtype="https://schema.org/Organization" itemscope="itemscope" style="background-color: var(--ast-global-color-0); border-radius: 50%;">
                                            <span class="site-logo-img"><a href="<?php echo e(route('index')); ?>" class="custom-logo-link" rel="home" aria-current="page"><img style="height: 40px; width: 40px; margin-left: 12px;" src="<?php echo e(url('images/logo.png')); ?>" class="custom-logo astra-logo-svg" alt="Vishu Real Estate" decoding="async" /></a></span>
                                        </div>
                                    <!-- .site-branding -->
                                </div>
                            </div>
                            <div class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
                                <div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="section-header-mobile-trigger">
                                    <div class="ast-button-wrap">
                                        <button type="button" class="menu-toggle main-header-menu-toggle ast-mobile-menu-trigger-minimal" aria-expanded="false" aria-label="Main menu toggle">
                                            <span class="screen-reader-text">Main Menu</span>
                                            <span class="mobile-menu-toggle-icon">
                                                <span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class='ast-mobile-svg ast-menu-svg' fill='currentColor' version='1.1' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>
                                                        <path d='M3 13h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 7h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 19h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1z'></path>
                                                    </svg></span><span aria-hidden="true" class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class='ast-mobile-svg ast-close-svg' fill='currentColor' version='1.1' xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>
                                                        <path d='M5.293 6.707l5.293 5.293-5.293 5.293c-0.391 0.391-0.391 1.024 0 1.414s1.024 0.391 1.414 0l5.293-5.293 5.293 5.293c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414l-5.293-5.293 5.293-5.293c0.391-0.391 0.391-1.024 0-1.414s-1.024-0.391-1.414 0l-5.293 5.293-5.293-5.293c-0.391-0.391-1.024-0.391-1.414 0s-0.391 1.024 0 1.414z'></path>
                                                    </svg></span> </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ast-mobile-header-content content-align-flex-start ">
                    <div class="ast-builder-menu-mobile ast-builder-menu ast-builder-menu-mobile-focus-item ast-builder-layout-element site-header-focus-item" data-section="section-header-mobile-menu">
                        <div class="ast-main-header-bar-alignment">
                            <div class="main-header-bar-navigation">
                                <nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="ast-mobile-site-navigation" aria-label="Site Navigation: Main Menu" itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope">
                                    <div class="main-navigation">
                                        <ul id="ast-hf-mobile-menu" class="main-header-menu ast-nav-menu ast-flex  submenu-with-border astra-menu-animation-fade  stack-on-mobile">
                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-6 current_page_item menu-item-41"><a href="<?php echo e(route('index')); ?>" aria-current="page" class="menu-link">Home</a></li>
                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="<?php echo e(route('about')); ?>" class="menu-link">About</a></li>
                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href="<?php echo e(route('services')); ?>" class="menu-link">Services</a></li>
                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a href="<?php echo e(route('projects')); ?>" class="menu-link">Projects</a></li>
                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-32"><a href="#" class="menu-link">Contact</a></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header><!-- #masthead -->
        <div id="content" class="site-content">
            <div class="ast-container">


                <div id="primary" class="content-area primary">


                    <main id="main" class="site-main">
                        <article
                            class="post-6 page type-page status-publish ast-article-single" id="post-6" itemtype="https://schema.org/CreativeWork" itemscope="itemscope">

                            <header class="entry-header ast-no-thumbnail ast-no-title ast-header-without-markup">
                            </header> <!-- .entry-header -->

                            <div class="entry-content clear"
                                itemprop="text">


                                <div data-elementor-type="wp-page" data-elementor-id="6" class="elementor elementor-6">
                                    <div class="elementor-element elementor-element-9e88b79 e-flex e-con-boxed e-con e-parent" data-id="9e88b79" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-shape elementor-shape-bottom" aria-hidden="true" data-negative="true">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                                                    <path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" />
                                                </svg>
                                            </div>
                                            <div class="elementor-element elementor-element-ab8e243 e-con-full e-flex e-con e-child" data-id="ab8e243" data-element_type="container">
                                                <div class="elementor-element elementor-element-3f6348a e-con-full e-flex e-con e-child" data-id="3f6348a" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    <div class="elementor-element elementor-element-0ee9e74 elementor-widget elementor-widget-text-editor" data-id="0ee9e74" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <p>25+ Years of Excellence</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-c319295 elementor-widget elementor-widget-uael-infobox" data-id="c319295" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-normal  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'>
                                                                        <h1 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Building Your Dreams to Reality</h1>
                                                                    </div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                           From dream homes to prime properties, Vishu Real Estate delivers trusted real estate solutions across Ahmedabad — with integrity, value, and a vision for your future.</div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-6dfa650 e-con-full e-flex e-con e-child" data-id="6dfa650" data-element_type="container">
                                                <div class="elementor-element elementor-element-53bed2f elementor-mobile-align-justify elementor-widget-mobile__width-initial elementor-widget elementor-widget-button" data-id="53bed2f" data-element_type="widget" data-widget_type="button.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-button-wrapper">
                                                            <a class="elementor-button elementor-button-link elementor-size-sm" href="#">
                                                                <span class="elementor-button-content-wrapper">
                                                                    <span class="elementor-button-text">Enquire Now</span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-9eec399 elementor-mobile-align-justify elementor-widget-mobile__width-initial elementor-widget elementor-widget-button" data-id="9eec399" data-element_type="widget" data-widget_type="button.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-button-wrapper">
                                                            <a class="elementor-button elementor-button-link elementor-size-sm" href="#">
                                                                <span class="elementor-button-content-wrapper">
                                                                    <span class="elementor-button-text">View Our Work</span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-f4ddd80 e-flex e-con-boxed e-con e-parent" data-id="f4ddd80" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-a6862a6 e-con-full e-flex e-con e-child" data-id="a6862a6" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                <div class="elementor-element elementor-element-ac586ce elementor-widget elementor-widget-uael-infobox" data-id="ac586ce" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                        <div class="uael-icon-wrap elementor-animation-">
                                                                            <span class="uael-icon">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" id="Capa_1" height="512" viewBox="0 0 512 512" width="512">
                                                                                    <g>
                                                                                        <path d="m303.801 127.598c-70.801 0-128.403 57.601-128.403 128.402s57.602 128.402 128.403 128.402 128.402-57.601 128.402-128.402-57.601-128.402-128.402-128.402zm60.548 143.402h-75.548v-105.291h30v75.291h45.548z"></path>
                                                                                        <path d="m304.374 47.802c-45.679-.123-87.937 14.475-122.319 39.302h-113.531c-17.899 0-32.408 14.51-32.408 32.408 0 17.899 14.51 32.408 32.408 32.408h54.925c-10.465 18.096-18.276 37.915-22.923 58.924h-68.118c-17.898.001-32.408 14.51-32.408 32.409 0 17.899 14.51 32.408 32.408 32.408h64.124c1.936 20.669 6.894 40.457 14.428 58.924h-23.148c-17.899 0-32.408 14.51-32.408 32.408 0 17.899 14.51 32.408 32.408 32.408h65.054c37.932 39.912 91.526 64.797 150.935 64.797 114.985.001 208.199-93.212 208.199-208.197 0-115.033-92.594-207.889-207.626-208.199zm-.573 366.6c-87.343 0-158.402-71.059-158.402-158.402s71.059-158.402 158.402-158.402 158.402 71.059 158.402 158.402-71.059 158.402-158.402 158.402z"></path>
                                                                                    </g>
                                                                                </svg> </span>
                                                                        </div>

                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'>
                                                                        <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">On Time​</h5>
                                                                    </div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            From site visits to final paperwork, we respect your time with fast and reliable services​ </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-edb9b48 elementor-widget elementor-widget-uael-infobox" data-id="edb9b48" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                        <div class="uael-icon-wrap elementor-animation-">
                                                                            <span class="uael-icon">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="512" height="512">
                                                                                    <g id="Quality">
                                                                                        <path d="M19.5439,38.8789a6.5344,6.5344,0,0,1-3.25-2.124c-.1514-.1572-.3652-.3789-.49-.4873-.1631-.0342-.4717-.0674-.6865-.0908a6.4526,6.4526,0,0,1-3.6152-1.26A5.2253,5.2253,0,0,1,10.17,33.2446L6.2705,40a1.9992,1.9992,0,0,0,2.0332,2.9766l3.4814-.5293,1.2832,3.2822A1.9846,1.9846,0,0,0,14.78,46.9941q.0776.0059.1553.0059a1.9838,1.9838,0,0,0,1.7275-1l4.0454-7.0075c-.03.0005-.0579.0065-.0884.0065A4.8026,4.8026,0,0,1,19.5439,38.8789Z"></path>
                                                                                        <path d="M37.8292,33.2438A5.2315,5.2315,0,0,1,36.498,34.918a6.4573,6.4573,0,0,1-3.6152,1.26c-.2168.0234-.5264.0566-.6885.0908-.125.1084-.3408.332-.49.4883a6.5357,6.5357,0,0,1-3.2412,2.12A4.8166,4.8166,0,0,1,27.376,39c-.0289,0-.0551-.0057-.0837-.0062L31.3369,46a1.9838,1.9838,0,0,0,1.7275,1q.0776,0,.1553-.0059a1.9865,1.9865,0,0,0,1.7129-1.2656l1.2822-3.2812,3.48.5293A1.9993,1.9993,0,0,0,41.7295,40Z"></path>
                                                                                        <path d="M24,9A10,10,0,1,0,34,19,10.0118,10.0118,0,0,0,24,9Zm4.832,7.5547-4,6a1,1,0,0,1-.7334.44C24.0654,22.998,24.0322,23,24,23a1,1,0,0,1-.707-.293l-3-3A1,1,0,0,1,21.707,18.293l2.1377,2.1377,3.3232-4.9854a1,1,0,0,1,1.6641,1.1094Z"></path>
                                                                                        <path d="M28.01,36.9287A4.7494,4.7494,0,0,0,30.2627,35.37a4.5189,4.5189,0,0,1,1.0391-.9033,4.4639,4.4639,0,0,1,1.3633-.2773,4.6656,4.6656,0,0,0,2.5674-.82,4.8616,4.8616,0,0,0,1.3457-2.37,4.7331,4.7331,0,0,1,.5684-1.3037,4.5382,4.5382,0,0,1,1.1045-.8447,4.7791,4.7791,0,0,0,1.9727-1.877,4.8865,4.8865,0,0,0,.2051-2.7031,4.8209,4.8209,0,0,1-.0381-1.4541,4.5971,4.5971,0,0,1,.626-1.2334A4.9213,4.9213,0,0,0,42,19a4.9284,4.9284,0,0,0-.9824-2.582,4.5929,4.5929,0,0,1-.627-1.2344,4.8141,4.8141,0,0,1,.0381-1.4531,4.895,4.895,0,0,0-.2041-2.7031,4.786,4.786,0,0,0-1.9717-1.876,4.5422,4.5422,0,0,1-1.1055-.8467,4.7454,4.7454,0,0,1-.5693-1.3037,4.8525,4.8525,0,0,0-1.3447-2.3691,4.6656,4.6656,0,0,0-2.5674-.82,4.4639,4.4639,0,0,1-1.3633-.2773,4.5672,4.5672,0,0,1-1.0391-.9033A4.7557,4.7557,0,0,0,28.01,1.07a4.6334,4.6334,0,0,0-2.6348.4014A4.5614,4.5614,0,0,1,24,1.833a4.549,4.549,0,0,1-1.374-.3613,4.617,4.617,0,0,0-2.6357-.4A4.7494,4.7494,0,0,0,17.7373,2.63a4.5189,4.5189,0,0,1-1.0391.9033,4.4639,4.4639,0,0,1-1.3633.2773,4.6656,4.6656,0,0,0-2.5674.82,4.8616,4.8616,0,0,0-1.3457,2.37,4.7331,4.7331,0,0,1-.5684,1.3037,4.5382,4.5382,0,0,1-1.1045.8447,4.7791,4.7791,0,0,0-1.9727,1.877,4.8865,4.8865,0,0,0-.2051,2.7031,4.8209,4.8209,0,0,1,.0381,1.4541,4.5971,4.5971,0,0,1-.626,1.2334A4.9213,4.9213,0,0,0,6,19a4.9284,4.9284,0,0,0,.9824,2.582,4.5929,4.5929,0,0,1,.627,1.2344A4.8141,4.8141,0,0,1,7.5713,24.27a4.895,4.895,0,0,0,.2041,2.7031,4.786,4.786,0,0,0,1.9717,1.876,4.5422,4.5422,0,0,1,1.1055.8467,4.7454,4.7454,0,0,1,.5693,1.3037,4.8525,4.8525,0,0,0,1.3447,2.3691,4.6656,4.6656,0,0,0,2.5674.82,4.4639,4.4639,0,0,1,1.3633.2773,4.5672,4.5672,0,0,1,1.0391.9033A4.7557,4.7557,0,0,0,19.99,36.93a4.64,4.64,0,0,0,2.6348-.4014A4.5614,4.5614,0,0,1,24,36.167a4.549,4.549,0,0,1,1.374.3613A5.9052,5.9052,0,0,0,27.376,37,2.7729,2.7729,0,0,0,28.01,36.9287ZM24,31A12,12,0,1,1,36,19,12.0131,12.0131,0,0,1,24,31Z"></path>
                                                                                    </g>
                                                                                </svg> </span>
                                                                        </div>

                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'>
                                                                        <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic"> ISO Certified​</h5>
                                                                    </div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            Our certification reflects our commitment to quality, trust, and customer satisfaction in every deal​ </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-10309e3 elementor-widget elementor-widget-uael-infobox" data-id="10309e3" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                        <div class="uael-icon-wrap elementor-animation-">
                                                                            <span class="uael-icon">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect y="329.2" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect x="361.33" y="329.2" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect x="180.67" y="329.2" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect x="90.33" y="212.8" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect x="271" y="212.8" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g>
                                                                                        <g>
                                                                                            <rect x="180.67" y="96.4" width="150.67" height="86.4"></rect>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                    <g></g>
                                                                                </svg> </span>
                                                                        </div>

                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'>
                                                                        <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Quality Materials​</h5>
                                                                    </div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            We deal only in verified projects and trusted builders to ensure long-term value</div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-5b2283d e-flex e-con-boxed e-con e-parent" data-id="5b2283d" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-4490e99 e-con-full e-flex e-con e-child" data-id="4490e99" data-element_type="container">
                                                <div class="elementor-element elementor-element-3ed0240 elementor-widget elementor-widget-image" data-id="3ed0240" data-element_type="widget" data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img fetchpriority="high" decoding="async" width="546" height="467" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/About-Img-1.png" class="attachment-large size-large wp-image-156" alt="" srcset="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/About-Img-1.png 546w, https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/About-Img-1-300x257.png 300w, https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/About-Img-1-400x342.png 400w" sizes="(max-width: 546px) 100vw, 546px" />
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-d8b8059 elementor-widget elementor-widget-image" data-id="d8b8059" data-element_type="widget" data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/thumbs/About-Img-2-r8ju3n64ryxscq5glhrg9r0fv1hhjddu8ldtuerxfg.png" title="About Img 2" alt="About Img 2" loading="lazy" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-9de498b e-con-full e-flex e-con e-child" data-id="9de498b" data-element_type="container">
                                                <div class="elementor-element elementor-element-7a82b54 elementor-widget elementor-widget-text-editor" data-id="7a82b54" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>About us</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-e2dbe28 elementor-widget elementor-widget-heading" data-id="e2dbe28" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">Trusted Local Construction Partner in Austin.</h2>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-f4e1697 elementor-widget elementor-widget-text-editor" data-id="f4e1697" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>At Brikly, we’re proud to serve Austin with reliable, high-quality construction services. From custom homes to commercial builds, our local expertise ensures every project is done right. We build with integrity, craftsmanship, and a commitment to your vision.</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-31587a4 e-con-full e-flex e-con e-child" data-id="31587a4" data-element_type="container">
                                                    <div class="elementor-element elementor-element-8097d0d elementor-position-left elementor-mobile-position-left elementor-view-default elementor-widget elementor-widget-icon-box" data-id="8097d0d" data-element_type="widget" data-widget_type="icon-box.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-icon-box-wrapper">

                                                                <div class="elementor-icon-box-icon">
                                                                    <span class="elementor-icon">
                                                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                                                        </svg> </span>
                                                                </div>

                                                                <div class="elementor-icon-box-content">


                                                                    <p class="elementor-icon-box-description">
                                                                        150+ Projects </p>

                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-e46ec55 elementor-position-left elementor-mobile-position-left elementor-view-default elementor-widget elementor-widget-icon-box" data-id="e46ec55" data-element_type="widget" data-widget_type="icon-box.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-icon-box-wrapper">

                                                                <div class="elementor-icon-box-icon">
                                                                    <span class="elementor-icon">
                                                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                                                        </svg> </span>
                                                                </div>

                                                                <div class="elementor-icon-box-content">


                                                                    <p class="elementor-icon-box-description">
                                                                        Licensed &amp; ISO Certified </p>

                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-5271658 elementor-position-left elementor-mobile-position-left elementor-view-default elementor-widget elementor-widget-icon-box" data-id="5271658" data-element_type="widget" data-widget_type="icon-box.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-icon-box-wrapper">

                                                                <div class="elementor-icon-box-icon">
                                                                    <span class="elementor-icon">
                                                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                                                        </svg> </span>
                                                                </div>

                                                                <div class="elementor-icon-box-content">


                                                                    <p class="elementor-icon-box-description">
                                                                        Experienced Team </p>

                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-c3f7757 e-flex e-con-boxed e-con e-parent" data-id="c3f7757" data-element_type="container">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-27938cf e-con-full e-flex e-con e-child" data-id="27938cf" data-element_type="container">
                                                <div class="elementor-element elementor-element-25fb7bc elementor-widget elementor-widget-text-editor" data-id="25fb7bc" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>What We Do</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-7533f8e elementor-widget elementor-widget-heading" data-id="7533f8e" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">Our Full-Spectrum Construction Services</h2>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-39f305b e-con-full e-flex e-con e-child" data-id="39f305b" data-element_type="container">
                                                <div class="elementor-element elementor-element-28fef4e e-con-full e-flex e-con e-child" data-id="28fef4e" data-element_type="container">
                                                    <div class="elementor-element elementor-element-4d617fa e-con-full e-flex e-con e-child" data-id="4d617fa" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
                                                        <div class="elementor-shape elementor-shape-bottom" aria-hidden="true" data-negative="true">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                                                                <path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-e290259 e-con-full e-flex e-con e-child" data-id="e290259" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-b85a7e8 elementor-widget elementor-widget-uael-infobox" data-id="b85a7e8" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-normal  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-link">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Capa_1" x="0px" y="0px" viewBox="0 0 511.999 511.999" style="enable-background:new 0 0 511.999 511.999;" xml:space="preserve">
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M511.964,444.408l-0.344-7.869c-0.176-4.021-3.601-7.132-7.598-6.96c-4.02,0.176-7.136,3.577-6.96,7.598l0.347,7.932    c0.003,0.048,0.005,0.096,0.008,0.144c0.094,1.466-0.408,2.863-1.412,3.933c-0.998,1.064-2.35,1.65-3.806,1.65h-42.628V316.337    l10.99,3.884c18.939,6.693,32.008,23.978,33.313,44.051l1.208,27.635c0.176,4.02,3.572,7.144,7.597,6.96    c4.021-0.176,7.137-3.577,6.961-7.597l-1.211-27.708c-0.003-0.048-0.005-0.096-0.008-0.144    c-1.651-25.938-18.531-48.287-43.005-56.935l-20.35-7.192c-0.12-0.05-0.231-0.114-0.354-0.157l-60.776-21.48    c-0.01-0.004-0.021-0.008-0.031-0.011c-0.226-0.078-0.45-0.144-0.678-0.203c-0.115-0.031-0.231-0.051-0.346-0.076    c-4.022-1.041-8.38,0.116-11.344,3.085l-1.879,1.882l-16.037-8.05l-0.002-14.058c4.846-3.336,9.41-7.315,13.554-11.755    c0.049-0.053,0.098-0.105,0.147-0.158c10.465-11.27,18.189-25.458,20.817-39.554c0.07-0.372,0.139-0.745,0.202-1.117    c0.065-0.386,0.126-0.771,0.183-1.156c0.096-0.644,0.18-1.287,0.254-1.929c0.018-0.154,0.041-0.309,0.057-0.463    c0.074-0.698,0.137-1.395,0.184-2.089h3.024c9.392,0,17.033-7.641,17.033-17.033v-19.091c0-0.903-0.079-1.798-0.22-2.682    c1.074-1.951,1.692-4.193,1.692-6.582v-8.14c0-6.189-4.113-11.422-9.715-13.04v-1.149c0-0.695-0.009-1.389-0.026-2.079    c-0.493-19.429-8.122-37.834-21.479-51.823c-12.185-12.761-28.124-20.839-45.29-23.044c-0.262-0.47-0.546-0.924-0.841-1.37    c-0.076-0.114-0.156-0.224-0.234-0.337c-0.298-0.432-0.612-0.851-0.94-1.257c-0.058-0.071-0.113-0.144-0.171-0.214    c-0.406-0.489-0.832-0.959-1.28-1.408c-0.015-0.015-0.031-0.029-0.047-0.045c-0.436-0.434-0.892-0.846-1.364-1.24    c-0.053-0.044-0.105-0.089-0.158-0.133c-0.972-0.796-2.015-1.501-3.116-2.112c-0.099-0.055-0.197-0.11-0.297-0.164    c-0.547-0.292-1.104-0.566-1.677-0.809c-0.029-0.012-0.06-0.022-0.09-0.035c-0.529-0.222-1.071-0.416-1.62-0.594    c-0.149-0.049-0.299-0.096-0.449-0.141c-0.583-0.174-1.171-0.333-1.772-0.457c-0.034-0.007-0.068-0.011-0.102-0.017    c-0.575-0.116-1.159-0.2-1.749-0.268c-0.162-0.019-0.324-0.035-0.487-0.05c-0.628-0.057-1.26-0.096-1.9-0.096h-6.877    c-0.64,0-1.272,0.039-1.9,0.096c-0.164,0.015-0.326,0.032-0.488,0.05c-0.588,0.067-1.171,0.152-1.745,0.267    c-0.035,0.007-0.07,0.011-0.105,0.018c-0.6,0.124-1.189,0.282-1.771,0.456c-0.151,0.045-0.301,0.093-0.451,0.142    c-0.548,0.178-1.089,0.372-1.618,0.593c-0.03,0.013-0.062,0.023-0.092,0.036c-0.573,0.243-1.129,0.517-1.676,0.808    c-0.101,0.054-0.201,0.11-0.301,0.165c-0.534,0.296-1.058,0.61-1.564,0.951c-0.001,0.001-0.003,0.002-0.004,0.003    c-0.534,0.36-1.047,0.749-1.546,1.157c-0.054,0.044-0.107,0.09-0.16,0.135c-0.471,0.393-0.926,0.804-1.361,1.237    c-0.016,0.016-0.033,0.031-0.049,0.047c-0.447,0.448-0.873,0.918-1.278,1.406c-0.059,0.071-0.115,0.144-0.173,0.216    c-0.328,0.405-0.641,0.824-0.939,1.255c-0.078,0.113-0.159,0.223-0.235,0.338c-0.295,0.445-0.579,0.9-0.841,1.37    c-17.165,2.205-33.105,10.284-45.289,23.043c-6.509,6.817-11.645,14.687-15.271,23.208l-42.203-39.535    c-8.662-8.114-22.215-8.096-30.853,0.043l-45.78,43.126l-0.008-5.042c-0.004-2.89-1.133-5.605-3.18-7.645    c-2.043-2.037-4.754-3.158-7.638-3.158c-0.005,0-0.011,0-0.016,0l-34.32,0.048c-5.964,0.009-10.811,4.868-10.804,10.835    l0.094,57.595L7.081,205.28c-4.381,4.127-6.892,9.712-7.071,15.728s1.995,11.741,6.121,16.12    c4.126,4.381,9.711,6.892,15.727,7.072c0.231,0.007,0.46,0.01,0.689,0.01c5.763,0,11.22-2.163,15.432-6.132l16.329-15.383    l0.071,51.081c0.006,4.02,3.266,7.275,7.286,7.275c0.003,0,0.007,0,0.01,0c4.024-0.006,7.282-3.272,7.276-7.296l-0.091-64.768    l103.582-97.579l41.614,38.984v6.221c0,0.422,0.025,0.84,0.063,1.255c0.007,0.077,0.013,0.154,0.022,0.231    c0.194,1.821,0.738,3.557,1.603,5.121c-0.138,0.875-0.215,1.762-0.215,2.657v19.091c0,9.392,7.641,17.033,17.034,17.033h3.014    c0.047,0.72,0.111,1.442,0.187,2.167c0.021,0.204,0.05,0.409,0.074,0.613c0.07,0.601,0.148,1.203,0.237,1.807    c0.053,0.362,0.109,0.725,0.169,1.087c0.072,0.431,0.153,0.864,0.234,1.296c0.168,0.895,0.357,1.791,0.566,2.686    c0.038,0.164,0.073,0.328,0.113,0.492c0.145,0.601,0.302,1.201,0.465,1.801c0.033,0.12,0.066,0.241,0.1,0.361    c1.297,4.68,3.123,9.327,5.395,13.834c0.024,0.048,0.048,0.096,0.073,0.144c0.908,1.794,1.886,3.563,2.93,5.304    c0.138,0.23,0.274,0.46,0.414,0.689c0.282,0.461,0.568,0.92,0.859,1.376c0.22,0.345,0.444,0.688,0.669,1.03    c0.253,0.385,0.503,0.772,0.762,1.154c0.462,0.681,0.936,1.355,1.418,2.025c0.206,0.286,0.417,0.567,0.626,0.851    c0.359,0.487,0.723,0.971,1.093,1.451c0.202,0.262,0.403,0.524,0.607,0.783c0.503,0.639,1.015,1.273,1.536,1.899    c0.075,0.09,0.147,0.181,0.222,0.27c0.573,0.683,1.159,1.354,1.753,2.02c0.209,0.235,0.421,0.466,0.632,0.698    c0.418,0.459,0.841,0.914,1.269,1.364c0.237,0.249,0.472,0.499,0.711,0.745c0.514,0.528,1.035,1.049,1.561,1.564    c0.379,0.371,0.764,0.734,1.15,1.097c0.323,0.304,0.646,0.609,0.974,0.908c0.397,0.363,0.798,0.719,1.201,1.073    c0.214,0.188,0.43,0.374,0.646,0.559c2.179,1.877,4.436,3.624,6.759,5.224l-0.002,13.905l-16.032,8.052l-1.882-1.885    c-1.802-1.805-4.119-2.941-6.562-3.322c-0.271-0.042-0.544-0.075-0.818-0.099c-0.274-0.023-0.549-0.038-0.825-0.042    c-0.275-0.004-0.552,0.001-0.827,0.016c-0.756,0.041-1.511,0.16-2.256,0.349c-0.142,0.03-0.285,0.058-0.427,0.096    c-0.222,0.058-0.488,0.137-0.684,0.207l-27.357,9.669l-0.072-51.824c-0.009-6.682-5.448-12.11-12.127-12.11    c-0.006,0-0.011,0-0.017,0l-56.99,0.08c-3.239,0.005-6.283,1.27-8.57,3.564c-2.287,2.293-3.545,5.341-3.54,8.58l0.125,89.181    c-0.01,0.012-0.02,0.024-0.031,0.036c-0.197,0.224-0.384,0.456-0.578,0.683c-0.31,0.363-0.622,0.724-0.924,1.095    c-0.19,0.233-0.371,0.473-0.557,0.709c-0.295,0.372-0.592,0.742-0.878,1.121c-0.183,0.242-0.357,0.491-0.537,0.736    c-0.279,0.38-0.562,0.758-0.833,1.145c-0.175,0.249-0.34,0.505-0.511,0.756c-0.265,0.389-0.533,0.777-0.79,1.172    c-0.167,0.257-0.325,0.521-0.488,0.781c-0.25,0.397-0.503,0.793-0.744,1.196c-0.157,0.262-0.304,0.53-0.458,0.794    c-0.236,0.408-0.476,0.814-0.704,1.227c-0.15,0.273-0.291,0.551-0.437,0.827c-0.218,0.411-0.44,0.819-0.65,1.235    c-0.147,0.291-0.283,0.587-0.426,0.88c-0.198,0.407-0.399,0.812-0.589,1.224c-0.139,0.301-0.267,0.607-0.401,0.911    c-0.181,0.411-0.366,0.819-0.539,1.234c-0.13,0.312-0.25,0.63-0.375,0.945c-0.164,0.411-0.332,0.82-0.487,1.235    c-0.122,0.326-0.233,0.656-0.35,0.984c-0.146,0.411-0.297,0.82-0.436,1.234c-0.112,0.335-0.213,0.675-0.319,1.012    c-0.13,0.412-0.265,0.822-0.387,1.238c-0.101,0.345-0.191,0.694-0.287,1.041c-0.114,0.414-0.233,0.826-0.339,1.243    c-0.089,0.35-0.167,0.705-0.25,1.058c-0.099,0.418-0.203,0.835-0.294,1.256c-0.078,0.362-0.144,0.728-0.216,1.092    c-0.082,0.416-0.169,0.83-0.244,1.248c-0.067,0.378-0.122,0.759-0.182,1.138c-0.065,0.409-0.136,0.817-0.193,1.228    c-0.055,0.39-0.097,0.783-0.144,1.174c-0.049,0.406-0.104,0.81-0.146,1.218c-0.041,0.397-0.069,0.797-0.102,1.196    c-0.031,0.372-0.07,0.743-0.095,1.116l-46.824,0.065c-0.164,0-0.297-0.133-0.297-0.297l-0.061-43.95    c-0.006-4.021-3.266-7.276-7.286-7.276c-0.003,0-0.007,0-0.01,0c-4.024,0.006-7.282,3.272-7.276,7.296l0.061,43.951    c0.012,8.192,6.68,14.848,14.869,14.848c0.007,0,0.014,0,0.02,0l46.161-0.064l-2.914,66.627    c-0.323,5.419,1.619,10.791,5.333,14.749c3.727,3.972,8.988,6.25,14.432,6.25h359.793c5.444,0,10.704-2.278,14.431-6.25    C510.345,455.199,512.287,449.827,511.964,444.408z M394.502,184.968c0,1.357-1.104,2.461-2.461,2.461h-2.91v-17.26h5.371V184.968    z M302.659,66.046c0.007-0.026,0.019-0.05,0.026-0.076c0.268-1.046,0.787-1.974,1.479-2.73c0.017-0.019,0.034-0.038,0.051-0.056    c0.219-0.234,0.456-0.45,0.707-0.648c0.029-0.023,0.06-0.045,0.09-0.067c0.508-0.386,1.073-0.694,1.679-0.915    c0.046-0.017,0.091-0.035,0.137-0.05c0.291-0.098,0.591-0.175,0.898-0.231c0.055-0.01,0.111-0.017,0.166-0.025    c0.319-0.049,0.642-0.082,0.972-0.082h6.877c0.33,0,0.654,0.033,0.972,0.082c0.055,0.008,0.111,0.015,0.166,0.025    c0.306,0.056,0.606,0.132,0.897,0.231c0.047,0.016,0.093,0.034,0.14,0.051c0.604,0.22,1.168,0.528,1.675,0.913    c0.031,0.023,0.063,0.046,0.093,0.069c0.25,0.197,0.485,0.412,0.704,0.645c0.019,0.02,0.036,0.04,0.054,0.06    c0.691,0.756,1.209,1.682,1.477,2.727c0.007,0.026,0.019,0.049,0.026,0.075c0.119,0.486,0.189,0.992,0.189,1.514v24.585    c0,3.525-2.868,6.393-6.392,6.393h-6.877c-3.525,0-6.393-2.868-6.393-6.393V67.558h-0.001    C302.471,67.036,302.541,66.532,302.659,66.046z M96.598,105.954l0.024,14.974L69.849,146.15l-0.065-40.158L96.598,105.954z     M225.119,119.819c-0.139,0.748-0.275,1.496-0.393,2.25c-0.066,0.422-0.12,0.844-0.179,1.267    c-0.096,0.687-0.194,1.373-0.272,2.064c-0.066,0.579-0.112,1.159-0.165,1.739c-0.049,0.545-0.108,1.087-0.146,1.634    c-0.08,1.144-0.137,2.288-0.166,3.433c-0.018,0.691-0.027,1.385-0.027,2.08v1.148c-0.015,0.004-0.028,0.011-0.043,0.015    c-0.443,0.13-0.873,0.289-1.296,0.462c-0.137,0.056-0.272,0.114-0.407,0.174c-0.373,0.168-0.739,0.349-1.093,0.55    c-0.052,0.03-0.109,0.051-0.161,0.081l-43.362-40.621c-2.808-2.629-7.177-2.625-9.977,0.014L27.987,227.473    c-1.547,1.458-3.558,2.234-5.695,2.163c-2.125-0.064-4.097-0.951-5.555-2.498c-1.458-1.547-2.226-3.569-2.163-5.694    c0.064-2.125,0.951-4.098,2.498-5.555L166.943,74.703c1.529-1.44,3.493-2.161,5.457-2.161c1.957,0,3.915,0.715,5.442,2.146    l47.404,44.406C225.198,119.336,225.164,119.578,225.119,119.819z M232.563,187.43c-1.358,0-2.462-1.104-2.462-2.461V170.17h5.37    v17.26H232.563z M228.629,153.331v-3.842h2.429c4.024,0,7.286-3.262,7.286-7.286v-7.919c0-0.571,0.007-1.14,0.022-1.709    c0.028-1.11,0.092-2.221,0.179-3.331c0.022-0.283,0.054-0.564,0.08-0.847c0.078-0.855,0.169-1.709,0.282-2.562    c0.037-0.278,0.077-0.555,0.118-0.833c0.132-0.902,0.281-1.801,0.451-2.697c0.038-0.201,0.074-0.402,0.113-0.603    c0.219-1.098,0.462-2.192,0.738-3.279c0.001-0.006,0.002-0.012,0.003-0.018c2.664-10.439,7.95-20.069,15.486-27.962    c8.783-9.198,19.958-15.385,32.082-17.891v19.587c0,11.56,9.405,20.964,20.965,20.964h6.877c11.56,0,20.964-9.405,20.964-20.964    V72.554c12.123,2.506,23.3,8.693,32.083,17.891c10.852,11.365,17.05,26.327,17.451,42.131c0.014,0.568,0.021,1.137,0.021,1.708    v7.919c0,4.024,3.262,7.286,7.286,7.286h2.43v3.842H228.629z M250.319,203.206c-0.013-0.112-0.025-0.224-0.038-0.337    c-0.066-0.611-0.118-1.219-0.157-1.825c-0.006-0.097-0.014-0.194-0.02-0.291c-0.039-0.699-0.061-1.395-0.061-2.086V170.17h124.516    v28.345c0,0.698-0.022,1.402-0.062,2.108c-0.005,0.081-0.012,0.162-0.017,0.243c-0.039,0.62-0.092,1.243-0.16,1.868    c-0.012,0.11-0.024,0.22-0.037,0.33c-0.08,0.685-0.174,1.372-0.288,2.062c-0.001,0.004-0.001,0.007-0.002,0.011    c-2.583,15.585-13.735,32.221-27.403,42.192c-0.098,0.071-0.196,0.144-0.294,0.214c-0.433,0.312-0.871,0.611-1.309,0.909    c-0.241,0.163-0.479,0.332-0.721,0.491c-0.128,0.084-0.257,0.162-0.386,0.245c-0.444,0.287-0.889,0.573-1.339,0.847    c-0.023,0.014-0.043,0.032-0.066,0.046c-4.062,2.47-8.283,4.325-12.519,5.379l-0.762,0.19c-15.542,3.865-19.11,3.856-34.709-0.077    c-4.196-1.058-8.377-2.905-12.402-5.359c-0.009-0.006-0.017-0.013-0.026-0.018c-0.161-0.098-0.318-0.203-0.479-0.303    c-0.476-0.297-0.951-0.596-1.422-0.909c-0.117-0.077-0.232-0.159-0.348-0.237C264.721,238.545,252.286,220.032,250.319,203.206z     M278.132,286.995c4.468-1.696,7.421-5.934,7.421-10.769l0.001-8.187c1.776,0.652,3.568,1.209,5.37,1.664    c8.95,2.256,14.98,3.382,21.019,3.382c5.97,0,11.95-1.1,20.77-3.293l0.762-0.19c1.871-0.465,3.73-1.044,5.574-1.721l0.001,8.345    c0,4.836,2.952,9.075,7.421,10.77l11.675,5.861c-0.14,0.107-0.277,0.22-0.417,0.326c-0.321,0.241-0.647,0.474-0.972,0.71    c-0.613,0.445-1.23,0.882-1.855,1.307c-0.349,0.238-0.699,0.472-1.052,0.704c-0.637,0.418-1.281,0.824-1.93,1.222    c-0.331,0.203-0.66,0.41-0.993,0.608c-0.793,0.47-1.597,0.922-2.406,1.362c-0.191,0.104-0.378,0.215-0.57,0.317    c-1.003,0.534-2.019,1.043-3.046,1.531c-0.275,0.131-0.555,0.25-0.832,0.378c-0.758,0.349-1.521,0.69-2.29,1.013    c-0.37,0.156-0.744,0.303-1.117,0.453c-0.697,0.279-1.397,0.549-2.102,0.808c-0.389,0.143-0.779,0.284-1.171,0.42    c-0.732,0.254-1.469,0.494-2.209,0.726c-0.354,0.111-0.707,0.227-1.063,0.333c-0.975,0.29-1.957,0.56-2.945,0.81    c-0.119,0.03-0.236,0.066-0.355,0.095c-1.112,0.276-2.233,0.523-3.36,0.749c-0.323,0.065-0.649,0.118-0.974,0.179    c-0.809,0.151-1.62,0.294-2.437,0.419c-0.403,0.062-0.807,0.117-1.211,0.172c-0.759,0.104-1.52,0.197-2.284,0.279    c-0.411,0.044-0.823,0.087-1.236,0.125c-0.809,0.073-1.622,0.13-2.437,0.178c-0.354,0.021-0.707,0.048-1.063,0.064    c-1.169,0.053-2.341,0.085-3.519,0.085c-1.178,0-2.35-0.033-3.519-0.085c-0.355-0.016-0.707-0.043-1.06-0.064    c-0.816-0.048-1.63-0.105-2.441-0.178c-0.412-0.037-0.823-0.081-1.233-0.124c-0.765-0.082-1.527-0.175-2.287-0.279    c-0.403-0.055-0.807-0.11-1.209-0.172c-0.817-0.125-1.63-0.268-2.44-0.42c-0.324-0.061-0.65-0.114-0.972-0.178    c-1.128-0.226-2.249-0.473-3.361-0.75c-0.116-0.029-0.23-0.064-0.346-0.093c-0.991-0.251-1.976-0.522-2.954-0.813    c-0.354-0.105-0.704-0.221-1.056-0.331c-0.743-0.233-1.483-0.474-2.218-0.729c-0.388-0.135-0.775-0.275-1.161-0.416    c-0.709-0.26-1.414-0.532-2.115-0.813c-0.369-0.148-0.738-0.294-1.104-0.448c-0.779-0.327-1.549-0.671-2.316-1.024    c-0.268-0.123-0.539-0.239-0.805-0.366c-1.03-0.489-2.049-1-3.057-1.536c-0.18-0.096-0.355-0.2-0.534-0.297    c-0.822-0.446-1.637-0.905-2.442-1.382c-0.327-0.194-0.649-0.396-0.973-0.595c-0.657-0.403-1.31-0.814-1.955-1.238    c-0.345-0.226-0.687-0.456-1.028-0.688c-0.634-0.431-1.261-0.875-1.883-1.327c-0.317-0.23-0.635-0.457-0.948-0.692    c-0.143-0.107-0.282-0.223-0.424-0.331L278.132,286.995z M132.406,450.835c-1.456,0-2.808-0.586-3.807-1.65    c-1.004-1.07-1.506-2.467-1.412-3.933c0.003-0.048,0.006-0.096,0.008-0.144l3.535-80.834c0.78-12.001,5.769-23.005,13.7-31.346    c0.076-0.072,0.156-0.139,0.229-0.215c4.665-4.848,10.325-8.735,16.505-11.366c0.129-0.055,0.259-0.109,0.389-0.162    c0.822-0.342,1.651-0.667,2.489-0.964l10.991-3.884v134.498H132.406z M179.539,299.29l-20.351,7.193    c-0.764,0.27-1.52,0.553-2.268,0.849c-0.238,0.094-0.47,0.198-0.706,0.294c-0.185,0.076-0.369,0.153-0.553,0.231    c-0.321,0.135-0.646,0.263-0.964,0.403c-0.351,0.154-0.694,0.321-1.042,0.481c-0.378,0.174-0.76,0.342-1.133,0.523    c-0.352,0.171-0.697,0.353-1.045,0.529c-0.361,0.183-0.727,0.36-1.084,0.55c-0.328,0.174-0.649,0.36-0.974,0.539    c-0.368,0.204-0.74,0.402-1.104,0.612c-0.32,0.185-0.632,0.382-0.949,0.572c-0.231,0.139-0.463,0.276-0.692,0.417l-0.104-74.447    l52.101-0.073l0.076,54.507l-18.855,6.663C179.769,299.176,179.658,299.24,179.539,299.29z M189.605,450.835V311.187l48.2-17.035    l5.577,27.372c2.086,10.238,8.355,19.301,17.198,24.865l44.435,27.96v76.486H189.605z M268.341,334.056    c-5.492-3.455-9.384-9.084-10.68-15.441l-3.443-16.901c0.272,0.229,0.534,0.473,0.808,0.698    c16.068,13.206,36.094,20.388,57.277,20.388c5.869,0,11.646-0.563,17.278-1.641c15.042-2.879,29.017-9.521,40.806-19.445    l-3.444,16.901c-1.294,6.357-5.186,11.985-10.678,15.44l-43.962,27.662L268.341,334.056z M434.999,450.835H319.588V374.35    l44.436-27.96c8.845-5.565,15.113-14.628,17.197-24.865l5.578-27.373l48.2,17.035V450.835z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h4 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Residential Construction</h4>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Custom-built homes designed with care, quality, and Austin’s unique character in mind. </div>

                                                                                <div class="uael-infobox-cta-link-style">
                                                                                    <a href="#" class="uael-infobox-cta-link ">
                                                                                        <span class="elementor-inline-editing" data-elementor-setting-key="infobox_link_text" data-elementor-inline-editing-toolbar="basic">Enquire Now</span>
                                                                                        <span class="uael-infobox-link-icon uael-infobox-link-icon-after">
                                                                                        </span>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-46d8043 e-con-full e-flex e-con e-child" data-id="46d8043" data-element_type="container">
                                                    <div class="elementor-element elementor-element-e859c03 e-con-full e-flex e-con e-child" data-id="e859c03" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
                                                        <div class="elementor-shape elementor-shape-bottom" aria-hidden="true" data-negative="true">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                                                                <path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-732f53b e-con-full e-flex e-con e-child" data-id="732f53b" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-8afa7e2 elementor-widget elementor-widget-uael-infobox" data-id="8afa7e2" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-normal  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-link">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M108.242,338.019H71.494c-5.522,0-10,4.478-10,10v36.748c0,5.522,4.478,10,10,10h36.748c5.522,0,10-4.478,10-10v-36.748    C118.242,342.496,113.765,338.019,108.242,338.019z M98.242,374.767H81.494v-16.748h16.748V374.767z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M189.7,338.019h-36.748c-5.522,0-10,4.478-10,10v36.748c0,5.522,4.478,10,10,10H189.7c5.522,0,10-4.478,10-10v-36.748    C199.7,342.496,195.223,338.019,189.7,338.019z M179.7,374.767h-16.748v-16.748H179.7V374.767z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M108.242,415.19H71.494c-5.522,0-10,4.478-10,10v36.748c0,5.522,4.478,10,10,10h36.748c5.522,0,10-4.478,10-10V425.19    C118.242,419.667,113.765,415.19,108.242,415.19z M98.242,451.938H81.494V435.19h16.748V451.938z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M189.7,415.19h-36.748c-5.522,0-10,4.478-10,10v36.748c0,5.522,4.478,10,10,10H189.7c5.522,0,10-4.478,10-10V425.19    C199.7,419.667,195.223,415.19,189.7,415.19z M179.7,451.938h-16.748V435.19H179.7V451.938z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M152,258.43c-1.87-1.86-4.44-2.93-7.07-2.93c-2.64,0-5.21,1.069-7.07,2.93c-1.869,1.86-2.93,4.44-2.93,7.07    s1.061,5.21,2.93,7.069c1.86,1.86,4.44,2.931,7.07,2.931s5.2-1.07,7.07-2.931c1.859-1.859,2.93-4.439,2.93-7.069    S153.86,260.29,152,258.43z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M502,492h-10V237.938c0-5.522-4.478-10-10-10h-47.873V99.114c0-3.701-2.044-7.1-5.314-8.834l-168-89.114    c-3.1-1.644-6.834-1.545-9.84,0.265c-3.007,1.809-4.846,5.061-4.846,8.569v102h-101.2c-5.522,0-10,4.478-10,10v103.722    c0,5.522,4.478,10,10,10c5.522,0,10-4.478,10-10V132h136v39.938h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8v36    h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8v36h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8v36    h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8v36h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8v36    h-34.8c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h34.8V492H240V308c0-5.522-4.478-10-10-10H30c-5.522,0-10,4.478-10,10v184    H10c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h492c5.522,0,10-4.478,10-10C512,496.478,507.523,492,502,492z M220,492H40    V318h180V492z M344,237.938V492h-33.073V122c0-5.522-4.478-10-10-10h-34.8V26.624l148,78.506v122.808H354    C348.478,227.938,344,232.416,344,237.938z M472,283.938h-54c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h54v36h-54    c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h54v36h-54c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10h54v36h-30.333    c-5.522,0-10,4.478-10,10c0,5.522,4.478,10,10,10H472V492H364V247.938h108V283.938z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M403.399,454.871c-1.859-1.861-4.429-2.931-7.069-2.931c-2.63,0-5.21,1.07-7.07,2.931c-1.86,1.859-2.93,4.439-2.93,7.069    s1.069,5.21,2.93,7.07c1.861,1.86,4.44,2.93,7.07,2.93c2.64,0,5.21-1.069,7.069-2.93c1.87-1.86,2.931-4.44,2.931-7.07    C406.33,459.3,405.269,456.73,403.399,454.871z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M344,113c-5.522,0-10,4.478-10,10v18.667c0,5.523,4.478,10,10,10c5.522,0,10-4.478,10-10V123    C354,117.478,349.522,113,344,113z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M344,171.937c-5.522,0-10,4.478-10,10v20.592c0,5.523,4.478,10,10,10c5.522,0,10-4.478,10-10v-20.592    C354,176.415,349.522,171.937,344,171.937z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M384,113c-5.522,0-10,4.478-10,10v18.667c0,5.523,4.478,10,10,10c5.522,0,10-4.478,10-10V123    C394,117.478,389.522,113,384,113z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M384,171.937c-5.522,0-10,4.478-10,10v20.592c0,5.523,4.478,10,10,10c5.522,0,10-4.478,10-10v-20.592    C394,176.415,389.522,171.937,384,171.937z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h4 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Commercial Buildings</h4>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Smart, scalable commercial spaces that support growth and reflect your business values. </div>

                                                                                <div class="uael-infobox-cta-link-style">
                                                                                    <a href="#" class="uael-infobox-cta-link ">
                                                                                        <span class="elementor-inline-editing" data-elementor-setting-key="infobox_link_text" data-elementor-inline-editing-toolbar="basic">Enquire Now</span>
                                                                                        <span class="uael-infobox-link-icon uael-infobox-link-icon-after">
                                                                                        </span>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-79bd1c5 e-con-full e-flex e-con e-child" data-id="79bd1c5" data-element_type="container">
                                                    <div class="elementor-element elementor-element-5260f7e e-con-full e-flex e-con e-child" data-id="5260f7e" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
                                                        <div class="elementor-shape elementor-shape-bottom" aria-hidden="true" data-negative="true">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                                                                <path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-3b1d022 e-con-full e-flex e-con e-child" data-id="3b1d022" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-9f8791e elementor-widget elementor-widget-uael-infobox" data-id="9f8791e" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-normal  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-link">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" id="Layer_3" height="512" viewBox="0 0 64 64" width="512">
                                                                                            <g>
                                                                                                <path d="m56 22.255v-16.255c0-.553-.447-1-1-1h-10c-.553 0-1 .447-1 1v5.454l-11.33-10.197c-.184-.165-.422-.257-.669-.257-.385 0-.385 0-15.67 13.757l-15 13.5c-.204.183-.323.442-.331.717-.007.274.099.539.293.733l3 3c.374.374.978.393 1.371.04l2.336-2.076v31.329c0 .553.447 1 1 1h46c.553 0 1-.447 1-1v-31.329l2.336 2.076c.189.169.427.253.664.253.257 0 .513-.099.707-.293l3-3c.194-.194.3-.459.293-.733-.008-.274-.127-.533-.331-.717zm-10-15.255h8v13.455l-8-7.2zm-36 45.489 7.917-6.158 3.73 3.73-9.117 10.939h-2.53zm17.618-22.285c-1.369-1.369-3.078-2.375-4.941-2.908l-3.345-.956c-.195-.056-.332-.236-.332-.44 0-.174.097-.33.253-.408.643-.322 1.363-.492 2.082-.492h.005c2.98.003 5.905.535 8.7 1.583 2.259.847 4.271 2.142 5.979 3.85l2.981 2.981v2.172c0 1.179.459 2.287 1.293 3.121.653.653 1.476 1.066 2.367 1.219l-3.733 3.733c-.153-.891-.567-1.714-1.219-2.367-.835-.833-1.943-1.292-3.122-1.292-1.935 0-3.753.753-5.121 2.121l-.465.465-3.586-3.586 2.247-2.247c.864-.864 1.339-2.012 1.338-3.277 0-1.219-.475-2.366-1.381-3.272zm17.382 10.21 2.586 2.586-5.586 5.586-2.586-2.586zm-18.414 2.586-4.586 4.586-1.586-1.586 4.586-4.586zm27.414 18h-38.865l8.634-10.359c.331-.397.305-.982-.062-1.348l-.293-.293 4.586-4.586.293.293c.391.391 1.023.391 1.414 0l1.172-1.172c.99-.99 2.307-1.535 3.707-1.535.645 0 1.251.251 1.707.707s.707 1.063.707 1.707v1.586c0 .266.105.52.293.707l4 4c.195.195.451.293.707.293s.512-.098.707-.293l7-7c.391-.391.391-1.023 0-1.414l-4-4c-.187-.188-.441-.293-.707-.293h-1.586c-.645 0-1.251-.251-1.707-.707s-.707-1.063-.707-1.707v-2.586c0-.266-.105-.52-.293-.707l-3.274-3.274c-1.911-1.911-4.162-3.36-6.695-4.311-3.015-1.13-6.175-1.705-9.396-1.708-.002 0-.005 0-.007 0-1.027 0-2.057.243-2.975.702-.839.418-1.36 1.261-1.36 2.198 0 1.091.732 2.062 1.782 2.363l3.345.956c1.537.439 2.947 1.269 4.12 2.441.485.485.752 1.13.752 1.861.001.686-.267 1.331-.752 1.816l-2.954 2.954c-.391.391-.391 1.023 0 1.414l.293.295-4.586 4.586-.293-.293c-.357-.357-.924-.393-1.321-.082l-7.386 5.744v-21.062l22-19.555 22 19.555zm4.96-30.374-26.296-23.373c-.189-.169-.427-.253-.664-.253s-.475.084-.664.253l-26.296 23.373-1.588-1.588c4.26-3.833 24.595-22.135 28.549-25.692l28.547 25.692z"></path>
                                                                                            </g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h4 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Renovation &amp; Remodeling</h4>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Transform existing spaces with modern upgrades, improved function, and fresh appeal. </div>

                                                                                <div class="uael-infobox-cta-link-style">
                                                                                    <a href="#" class="uael-infobox-cta-link ">
                                                                                        <span class="elementor-inline-editing" data-elementor-setting-key="infobox_link_text" data-elementor-inline-editing-toolbar="basic">Enquire Now</span>
                                                                                        <span class="uael-infobox-link-icon uael-infobox-link-icon-after">
                                                                                        </span>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-ed6e96c e-flex e-con-boxed e-con e-parent" data-id="ed6e96c" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-e504e1f e-con-full e-flex e-con e-child" data-id="e504e1f" data-element_type="container">
                                                <div class="elementor-element elementor-element-9f477a4 e-con-full e-flex e-con e-child" data-id="9f477a4" data-element_type="container">
                                                    <div class="elementor-element elementor-element-8a29e7b elementor-widget elementor-widget-text-editor" data-id="8a29e7b" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <p>Our Projects</p>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-cd8cc1b elementor-widget__width-initial elementor-widget elementor-widget-heading" data-id="cd8cc1b" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h2 class="elementor-heading-title elementor-size-default">Built to Last. Designed to Inspire.</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-ff8afa7 elementor-widget elementor-widget-uael-infobox" data-id="ff8afa7" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-button">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'></div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            From high-end homes to modern office spaces, each Brikly project is a reflection of quality, detail, and dedication. </div>

                                                                        <div class="uael-button-wrapper elementor-widget-button">
                                                                            <a href="#" class="elementor-button-link  elementor-button elementor-size-sm">
                                                                                <span class="elementor-button-content-wrapper">
                                                                                    <span class="elementor-align-icon-right elementor-button-icon">
                                                                                    </span>

                                                                                    <span class="elementor-button-text elementor-inline-editing" data-elementor-setting-key="infobox_button_text" data-elementor-inline-editing-toolbar="none">View All Projects</span>
                                                                                </span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-75c5400 e-con-full e-flex e-con e-child" data-id="75c5400" data-element_type="container">
                                                <div class="elementor-element elementor-element-d20cea5 e-con-full e-flex e-con e-child" data-id="d20cea5" data-element_type="container">
                                                    <div class="elementor-element elementor-element-f815de3 e-con-full e-flex e-con e-child" data-id="f815de3" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    </div>
                                                    <div class="elementor-element elementor-element-8cecff4 e-con-full e-flex e-con e-child" data-id="8cecff4" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-774c0d4 e-con-full e-flex e-con e-child" data-id="774c0d4" data-element_type="container">
                                                    <div class="elementor-element elementor-element-3208ef6 e-con-full e-flex e-con e-child" data-id="3208ef6" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    </div>
                                                    <div class="elementor-element elementor-element-7883223 e-con-full e-flex e-con e-child" data-id="7883223" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-9e0ed3f e-flex e-con-boxed e-con e-parent" data-id="9e0ed3f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-3353d65 e-con-full e-flex e-con e-child" data-id="3353d65" data-element_type="container">
                                                <div class="elementor-element elementor-element-98880d0 elementor-widget__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-uael-infobox" data-id="98880d0" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                            <div class="uael-infobox-left-right-wrap">
                                                                <div class="uael-infobox-content">
                                                                    <div class="uael-module-content uael-imgicon-wrap ">
                                                                    </div>
                                                                    <div class='uael-infobox-title-wrap'>
                                                                        <h3 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Let’s Build Your Dream Home.</h3>
                                                                    </div>
                                                                    <div class="uael-infobox-text-wrap">
                                                                        <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            Whether it’s a new build, a remodel, or just an idea — we’re here to help bring it to life. Let’s talk and explore how Brikly can make it happen. </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-9e9ee81 elementor-widget elementor-widget-button" data-id="9e9ee81" data-element_type="widget" data-widget_type="button.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-button-wrapper">
                                                            <a class="elementor-button elementor-button-link elementor-size-sm" href="#">
                                                                <span class="elementor-button-content-wrapper">
                                                                    <span class="elementor-button-text">Enquire Now</span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-c5f9b38 e-flex e-con-boxed e-con e-parent" data-id="c5f9b38" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-f88f446 e-con-full e-flex e-con e-child" data-id="f88f446" data-element_type="container">
                                                <div class="elementor-element elementor-element-55a7a42 elementor-widget elementor-widget-text-editor" data-id="55a7a42" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>Testimonials</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-ea197a8 elementor-widget elementor-widget-heading" data-id="ea197a8" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">What Our Clients Say</h2>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-8c8c159 e-con-full e-flex e-con e-child" data-id="8c8c159" data-element_type="container">
                                                <div class="elementor-element elementor-element-576afb6 e-con-full e-flex e-con e-child" data-id="576afb6" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    <div class="elementor-element elementor-element-e69361e e-con-full e-flex e-con e-child" data-id="e69361e" data-element_type="container">
                                                        <div class="elementor-element elementor-element-acc53e3 elementor-widget elementor-widget-rating" data-id="acc53e3" data-element_type="widget" data-widget_type="rating.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="e-rating" itemtype="https://schema.org/Rating" itemscope="" itemprop="reviewRating">
                                                                    <meta itemprop="worstRating" content="0">
                                                                    <meta itemprop="bestRating" content="5">
                                                                    <div class="e-rating-wrapper" itemprop="ratingValue" content="5" role="img" aria-label="Rated 5 out of 5">
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-3fe36ae elementor-view-default elementor-widget elementor-widget-icon" data-id="3fe36ae" data-element_type="widget" data-widget_type="icon.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-icon-wrapper">
                                                                    <div class="elementor-icon">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 64 64" xml:space="preserve">
                                                                            <g id="Quotemarks-left">
                                                                                <path d="M50.6292648,26.225668c-0.1288986-1.3934994-0.0303001-5.1816006,3.5985985-10.4492006   c0.2745018-0.3975,0.2247009-0.9335995-0.1161957-1.2743998c-1.4795036-1.4794998-2.395504-2.4131002-3.0379982-3.0663996   c-0.8448029-0.8614006-1.2305031-1.2539005-1.795002-1.7657003c-0.3769035-0.3388004-0.9472008-0.3446999-1.3281021-0.0125999   c-6.3251991,5.5038996-13.3505974,16.8768997-12.3339958,30.8105011   c0.5956955,8.1815987,6.5634956,14.1200981,14.1894951,14.1200981c7.8260994,0,14.1932983-6.3661995,14.1932983-14.1923981   C63.9993629,32.845768,58.0736694,26.6543674,50.6292648,26.225668z M49.8060646,52.5879669   c-6.5489006,0-11.6767998-5.1581993-12.1953011-12.2645988c0,0,0,0,0-0.0009995   c-1.1435966-15.6709003,8.1718025-25.8496017,10.9863014-28.5449009c0.2743988,0.2705002,0.5878983,0.5887995,1.0498009,1.0594997   c0.5565987,0.5664005,1.3183975,1.3417997,2.4706993,2.4981003c-4.4053001,6.7870998-3.5741997,11.6229992-3.2099991,12.3164005   c0.1728973,0.3290997,0.5273972,0.5508003,0.8984985,0.5508003c6.7236023,0,12.1932983,5.469698,12.1932983,12.1933002   C61.9993629,47.1182671,56.5296669,52.5879669,49.8060646,52.5879669z"></path>
                                                                                <path d="M15.1136675,26.225668c-0.1299-1.3896008-0.0341997-5.1748009,3.5985994-10.4492006   c0.2735004-0.3975,0.2245998-0.9335995-0.1161995-1.2743998c-1.4766006-1.4765997-2.3915997-2.4091997-3.0332003-3.0625   c-0.8476-0.8633003-1.2343998-1.2568998-1.7987995-1.7695999c-0.3769999-0.3388004-0.9473-0.3437004-1.3281002-0.0136003   c-6.3251996,5.5039005-13.3515997,16.875-12.3369999,30.8115005v0.0009995   c0.5977,8.1805992,6.5664001,14.1190987,14.1924,14.1190987c7.8261995,0,14.1934004-6.3661995,14.1934004-14.1923981   C28.4847679,32.8448677,22.5589676,26.6524677,15.1136675,26.225668z M14.2913675,52.5879669   c-6.5478001,0-11.6786995-5.1581993-12.1982002-12.2655983v0.0009995   c-1.1406-15.6748009,8.1747999-25.8516006,10.9892006-28.5459003c0.2754002,0.2705002,0.5899,0.5908003,1.0528002,1.0625   c0.5555992,0.5663996,1.3163996,1.3408003,2.4667988,2.4951c-4.4052992,6.7880993-3.5741997,11.6229992-3.2099991,12.3153992   c0.1729002,0.3291016,0.5283003,0.5518017,0.8993998,0.5518017c6.7237005,0,12.1934004,5.469698,12.1934004,12.1933002   C26.4847679,47.1182671,21.0150681,52.5879669,14.2913675,52.5879669z"></path>
                                                                            </g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-db6136a elementor-widget elementor-widget-heading" data-id="db6136a" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h6 class="elementor-heading-title elementor-size-default">Residential Construction</h6>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-04bccf2 elementor-widget elementor-widget-text-editor" data-id="04bccf2" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <p>It turned our dream home into reality. The attention to detail and craftsmanship were truly outstanding.</p>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-8192397 elementor-widget elementor-widget-uael-infobox" data-id="8192397" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                        <div class="elementor-widget-container">

                                                            <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-photo uael-infobox-photo-left-title  uael-infobox-image-valign-middle  uael-infobox-link-type-none">
                                                                <div class="uael-infobox-left-right-wrap">
                                                                    <div class="uael-infobox-content">
                                                                        <div class="left-title-image">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-image" itemscope itemtype="http://schema.org/ImageObject">
                                                                                    <div class="uael-image-content elementor-animation- ">
                                                                                        <img decoding="async" width="70" height="70" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Customer-1.png" class="attachment-full size-full wp-image-232" alt="" />
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h6 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Martin Roberts</h6>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uael-infobox-text-wrap">
                                                                            <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-12e4c81 e-con-full e-flex e-con e-child" data-id="12e4c81" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    <div class="elementor-element elementor-element-15a6356 e-con-full e-flex e-con e-child" data-id="15a6356" data-element_type="container">
                                                        <div class="elementor-element elementor-element-a4ec414 elementor-widget elementor-widget-rating" data-id="a4ec414" data-element_type="widget" data-widget_type="rating.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="e-rating" itemtype="https://schema.org/Rating" itemscope="" itemprop="reviewRating">
                                                                    <meta itemprop="worstRating" content="0">
                                                                    <meta itemprop="bestRating" content="5">
                                                                    <div class="e-rating-wrapper" itemprop="ratingValue" content="5" role="img" aria-label="Rated 5 out of 5">
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-0e7eb17 elementor-view-default elementor-widget elementor-widget-icon" data-id="0e7eb17" data-element_type="widget" data-widget_type="icon.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-icon-wrapper">
                                                                    <div class="elementor-icon">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 64 64" xml:space="preserve">
                                                                            <g id="Quotemarks-left">
                                                                                <path d="M50.6292648,26.225668c-0.1288986-1.3934994-0.0303001-5.1816006,3.5985985-10.4492006   c0.2745018-0.3975,0.2247009-0.9335995-0.1161957-1.2743998c-1.4795036-1.4794998-2.395504-2.4131002-3.0379982-3.0663996   c-0.8448029-0.8614006-1.2305031-1.2539005-1.795002-1.7657003c-0.3769035-0.3388004-0.9472008-0.3446999-1.3281021-0.0125999   c-6.3251991,5.5038996-13.3505974,16.8768997-12.3339958,30.8105011   c0.5956955,8.1815987,6.5634956,14.1200981,14.1894951,14.1200981c7.8260994,0,14.1932983-6.3661995,14.1932983-14.1923981   C63.9993629,32.845768,58.0736694,26.6543674,50.6292648,26.225668z M49.8060646,52.5879669   c-6.5489006,0-11.6767998-5.1581993-12.1953011-12.2645988c0,0,0,0,0-0.0009995   c-1.1435966-15.6709003,8.1718025-25.8496017,10.9863014-28.5449009c0.2743988,0.2705002,0.5878983,0.5887995,1.0498009,1.0594997   c0.5565987,0.5664005,1.3183975,1.3417997,2.4706993,2.4981003c-4.4053001,6.7870998-3.5741997,11.6229992-3.2099991,12.3164005   c0.1728973,0.3290997,0.5273972,0.5508003,0.8984985,0.5508003c6.7236023,0,12.1932983,5.469698,12.1932983,12.1933002   C61.9993629,47.1182671,56.5296669,52.5879669,49.8060646,52.5879669z"></path>
                                                                                <path d="M15.1136675,26.225668c-0.1299-1.3896008-0.0341997-5.1748009,3.5985994-10.4492006   c0.2735004-0.3975,0.2245998-0.9335995-0.1161995-1.2743998c-1.4766006-1.4765997-2.3915997-2.4091997-3.0332003-3.0625   c-0.8476-0.8633003-1.2343998-1.2568998-1.7987995-1.7695999c-0.3769999-0.3388004-0.9473-0.3437004-1.3281002-0.0136003   c-6.3251996,5.5039005-13.3515997,16.875-12.3369999,30.8115005v0.0009995   c0.5977,8.1805992,6.5664001,14.1190987,14.1924,14.1190987c7.8261995,0,14.1934004-6.3661995,14.1934004-14.1923981   C28.4847679,32.8448677,22.5589676,26.6524677,15.1136675,26.225668z M14.2913675,52.5879669   c-6.5478001,0-11.6786995-5.1581993-12.1982002-12.2655983v0.0009995   c-1.1406-15.6748009,8.1747999-25.8516006,10.9892006-28.5459003c0.2754002,0.2705002,0.5899,0.5908003,1.0528002,1.0625   c0.5555992,0.5663996,1.3163996,1.3408003,2.4667988,2.4951c-4.4052992,6.7880993-3.5741997,11.6229992-3.2099991,12.3153992   c0.1729002,0.3291016,0.5283003,0.5518017,0.8993998,0.5518017c6.7237005,0,12.1934004,5.469698,12.1934004,12.1933002   C26.4847679,47.1182671,21.0150681,52.5879669,14.2913675,52.5879669z"></path>
                                                                            </g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-c734cca elementor-widget elementor-widget-heading" data-id="c734cca" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h6 class="elementor-heading-title elementor-size-default">Commercial Project</h6>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-5c474de elementor-widget elementor-widget-text-editor" data-id="5c474de" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <p>Professional, punctual, and reliable — Brikly delivered our office space on time and beyond expectations.</p>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-0872761 elementor-widget elementor-widget-uael-infobox" data-id="0872761" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                        <div class="elementor-widget-container">

                                                            <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-photo uael-infobox-photo-left-title  uael-infobox-image-valign-middle  uael-infobox-link-type-none">
                                                                <div class="uael-infobox-left-right-wrap">
                                                                    <div class="uael-infobox-content">
                                                                        <div class="left-title-image">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-image" itemscope itemtype="http://schema.org/ImageObject">
                                                                                    <div class="uael-image-content elementor-animation- ">
                                                                                        <img decoding="async" width="70" height="70" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Customer-2.png" class="attachment-full size-full wp-image-239" alt="" />
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h6 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Emily Blunt</h6>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uael-infobox-text-wrap">
                                                                            <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-91edccf e-con-full e-flex e-con e-child" data-id="91edccf" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    <div class="elementor-element elementor-element-6695113 e-con-full e-flex e-con e-child" data-id="6695113" data-element_type="container">
                                                        <div class="elementor-element elementor-element-8b5d7ef elementor-widget elementor-widget-rating" data-id="8b5d7ef" data-element_type="widget" data-widget_type="rating.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="e-rating" itemtype="https://schema.org/Rating" itemscope="" itemprop="reviewRating">
                                                                    <meta itemprop="worstRating" content="0">
                                                                    <meta itemprop="bestRating" content="5">
                                                                    <div class="e-rating-wrapper" itemprop="ratingValue" content="5" role="img" aria-label="Rated 5 out of 5">
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="e-icon">
                                                                            <div class="e-icon-wrapper e-icon-marked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                            <div class="e-icon-wrapper e-icon-unmarked">
                                                                                <svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-a4f8549 elementor-view-default elementor-widget elementor-widget-icon" data-id="a4f8549" data-element_type="widget" data-widget_type="icon.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-icon-wrapper">
                                                                    <div class="elementor-icon">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 64 64" xml:space="preserve">
                                                                            <g id="Quotemarks-left">
                                                                                <path d="M50.6292648,26.225668c-0.1288986-1.3934994-0.0303001-5.1816006,3.5985985-10.4492006   c0.2745018-0.3975,0.2247009-0.9335995-0.1161957-1.2743998c-1.4795036-1.4794998-2.395504-2.4131002-3.0379982-3.0663996   c-0.8448029-0.8614006-1.2305031-1.2539005-1.795002-1.7657003c-0.3769035-0.3388004-0.9472008-0.3446999-1.3281021-0.0125999   c-6.3251991,5.5038996-13.3505974,16.8768997-12.3339958,30.8105011   c0.5956955,8.1815987,6.5634956,14.1200981,14.1894951,14.1200981c7.8260994,0,14.1932983-6.3661995,14.1932983-14.1923981   C63.9993629,32.845768,58.0736694,26.6543674,50.6292648,26.225668z M49.8060646,52.5879669   c-6.5489006,0-11.6767998-5.1581993-12.1953011-12.2645988c0,0,0,0,0-0.0009995   c-1.1435966-15.6709003,8.1718025-25.8496017,10.9863014-28.5449009c0.2743988,0.2705002,0.5878983,0.5887995,1.0498009,1.0594997   c0.5565987,0.5664005,1.3183975,1.3417997,2.4706993,2.4981003c-4.4053001,6.7870998-3.5741997,11.6229992-3.2099991,12.3164005   c0.1728973,0.3290997,0.5273972,0.5508003,0.8984985,0.5508003c6.7236023,0,12.1932983,5.469698,12.1932983,12.1933002   C61.9993629,47.1182671,56.5296669,52.5879669,49.8060646,52.5879669z"></path>
                                                                                <path d="M15.1136675,26.225668c-0.1299-1.3896008-0.0341997-5.1748009,3.5985994-10.4492006   c0.2735004-0.3975,0.2245998-0.9335995-0.1161995-1.2743998c-1.4766006-1.4765997-2.3915997-2.4091997-3.0332003-3.0625   c-0.8476-0.8633003-1.2343998-1.2568998-1.7987995-1.7695999c-0.3769999-0.3388004-0.9473-0.3437004-1.3281002-0.0136003   c-6.3251996,5.5039005-13.3515997,16.875-12.3369999,30.8115005v0.0009995   c0.5977,8.1805992,6.5664001,14.1190987,14.1924,14.1190987c7.8261995,0,14.1934004-6.3661995,14.1934004-14.1923981   C28.4847679,32.8448677,22.5589676,26.6524677,15.1136675,26.225668z M14.2913675,52.5879669   c-6.5478001,0-11.6786995-5.1581993-12.1982002-12.2655983v0.0009995   c-1.1406-15.6748009,8.1747999-25.8516006,10.9892006-28.5459003c0.2754002,0.2705002,0.5899,0.5908003,1.0528002,1.0625   c0.5555992,0.5663996,1.3163996,1.3408003,2.4667988,2.4951c-4.4052992,6.7880993-3.5741997,11.6229992-3.2099991,12.3153992   c0.1729002,0.3291016,0.5283003,0.5518017,0.8993998,0.5518017c6.7237005,0,12.1934004,5.469698,12.1934004,12.1933002   C26.4847679,47.1182671,21.0150681,52.5879669,14.2913675,52.5879669z"></path>
                                                                            </g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                            <g></g>
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-5cff9f3 elementor-widget elementor-widget-heading" data-id="5cff9f3" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h6 class="elementor-heading-title elementor-size-default">Renovation</h6>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-1fa6066 elementor-widget elementor-widget-text-editor" data-id="1fa6066" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <p>From the first consultation to the final handover, Brikly made the process smooth and stress-free.</p>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-10832f5 elementor-widget elementor-widget-uael-infobox" data-id="10832f5" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                        <div class="elementor-widget-container">

                                                            <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-photo uael-infobox-photo-left-title  uael-infobox-image-valign-middle  uael-infobox-link-type-none">
                                                                <div class="uael-infobox-left-right-wrap">
                                                                    <div class="uael-infobox-content">
                                                                        <div class="left-title-image">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-image" itemscope itemtype="http://schema.org/ImageObject">
                                                                                    <div class="uael-image-content elementor-animation- ">
                                                                                        <img loading="lazy" decoding="async" width="70" height="70" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Customer-3.png" class="attachment-full size-full wp-image-240" alt="" />
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h6 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Sarah Johnson</h6>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uael-infobox-text-wrap">
                                                                            <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-c86d108 e-flex e-con-boxed e-con e-parent" data-id="c86d108" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-9934750 e-con-full e-flex e-con e-child" data-id="9934750" data-element_type="container">
                                                <div class="elementor-element elementor-element-96bbc18 elementor-widget elementor-widget-image" data-id="96bbc18" data-element_type="widget" data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img loading="lazy" decoding="async" width="508" height="620" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Trust-Image.png" class="attachment-large size-large wp-image-251" alt="" srcset="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Trust-Image.png 508w, https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Trust-Image-246x300.png 246w, https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Trust-Image-400x488.png 400w" sizes="(max-width: 508px) 100vw, 508px" />
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-e4d21ba e-con-full e-flex e-con e-child" data-id="e4d21ba" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                    <div class="elementor-element elementor-element-b8d4501 elementor-widget elementor-widget-heading" data-id="b8d4501" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h5 class="elementor-heading-title elementor-size-default">Long-Term Reliability</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-f17e8b0 e-con-full e-flex e-con e-child" data-id="f17e8b0" data-element_type="container">
                                                <div class="elementor-element elementor-element-7697e6c elementor-widget elementor-widget-text-editor" data-id="7697e6c" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>Proven &amp; Trusted</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-832f0c0 elementor-widget-mobile__width-inherit elementor-widget elementor-widget-heading" data-id="832f0c0" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">Backed by Results, Built on Relationships</h2>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-2dbb4fb elementor-widget elementor-widget-text-editor" data-id="2dbb4fb" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>Brikly has become a name homeowners trust. Whether it&#8217;s new construction or custom renovation, you&#8217;re in good company when you build with Brikly. Our strong partnerships are a reflection of the confidence our clients place in us — project after project.</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-e3bbfe9 e-con-full e-flex e-con e-child" data-id="e3bbfe9" data-element_type="container">
                                                    <div class="elementor-element elementor-element-f6cac6a e-con-full e-flex e-con e-child" data-id="f6cac6a" data-element_type="container">
                                                        <div class="elementor-element elementor-element-0194e01 elementor-widget elementor-widget-heading" data-id="0194e01" data-element_type="widget" data-widget_type="heading.default">
                                                            <div class="elementor-widget-container">
                                                                <h3 class="elementor-heading-title elementor-size-default">100+</h3>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-5a1bcf9 elementor-widget elementor-widget-uael-infobox" data-id="5a1bcf9" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <div class="uael-separator-parent">
                                                                                    <div class="uael-separator"></div>
                                                                                </div>
                                                                                <h6 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Satisfied Clients</h6>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Over 100 projects built with trust and excellence. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-75517ad e-con-full e-flex e-con e-child" data-id="75517ad" data-element_type="container">
                                                        <div class="elementor-element elementor-element-edd5dd0 elementor-widget elementor-widget-heading" data-id="edd5dd0" data-element_type="widget" data-widget_type="heading.default">
                                                            <div class="elementor-widget-container">
                                                                <h3 class="elementor-heading-title elementor-size-default">10 Yrs.</h3>
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-ac3ebe6 elementor-widget elementor-widget-uael-infobox" data-id="ac3ebe6" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <div class="uael-separator-parent">
                                                                                    <div class="uael-separator"></div>
                                                                                </div>
                                                                                <h6 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Structural Warranty</h6>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Structural coverage &amp; quality you can count on. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-76b05d0 e-flex e-con-boxed e-con e-parent" data-id="76b05d0" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-5ee2abf uael-img-grid__column-5 uael-img-grid-tablet__column-5 uael-img-grid-mobile__column-3 uael-ins-normal elementor-widget elementor-widget-uael-image-gallery" data-id="5ee2abf" data-element_type="widget" data-settings="{&quot;gallery_columns&quot;:&quot;5&quot;,&quot;column_gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:80,&quot;sizes&quot;:[]},&quot;row_gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;images_valign&quot;:&quot;center&quot;,&quot;gallery_columns_tablet&quot;:&quot;5&quot;,&quot;column_gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:32,&quot;sizes&quot;:[]},&quot;row_gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:14,&quot;sizes&quot;:[]},&quot;gallery_columns_mobile&quot;:&quot;3&quot;,&quot;column_gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:16,&quot;sizes&quot;:[]},&quot;row_gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]}}" data-widget_type="uael-image-gallery.default">
                                                <div class="elementor-widget-container">
                                                    <div class="uael-gallery-parent uael-caption- uael-gallery-unjustified">
                                                        <div class="uael-img-gallery-wrap uael-img-grid-wrap uael-img-grid-masonry-wrap" data-filter-default="All">
                                                            <div class="uael-grid-item  uael-img-gallery-item-1">
                                                                <div class="uael-grid-item-content"><a class="uael-grid-img uael-grid-gallery-img uael-ins-hover elementor-clickable" target="_blank" rel="dofollow" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-1.svg" data-elementor-open-lightbox="no">
                                                                        <div class="uael-grid-img-thumbnail uael-ins-target"><img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-1.svg" title="Logo 1" alt="Logo 1" loading="lazy" /></div>
                                                                        <div class="uael-grid-img-overlay"></div>
                                                                    </a></div>
                                                            </div>
                                                            <div class="uael-grid-item  uael-img-gallery-item-2">
                                                                <div class="uael-grid-item-content"><a class="uael-grid-img uael-grid-gallery-img uael-ins-hover elementor-clickable" target="_blank" rel="dofollow" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-2.svg" data-elementor-open-lightbox="no">
                                                                        <div class="uael-grid-img-thumbnail uael-ins-target"><img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-2.svg" title="Logo 2" alt="Logo 2" loading="lazy" /></div>
                                                                        <div class="uael-grid-img-overlay"></div>
                                                                    </a></div>
                                                            </div>
                                                            <div class="uael-grid-item  uael-img-gallery-item-3">
                                                                <div class="uael-grid-item-content"><a class="uael-grid-img uael-grid-gallery-img uael-ins-hover elementor-clickable" target="_blank" rel="dofollow" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-3.svg" data-elementor-open-lightbox="no">
                                                                        <div class="uael-grid-img-thumbnail uael-ins-target"><img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-3.svg" title="Logo 3" alt="Logo 3" loading="lazy" /></div>
                                                                        <div class="uael-grid-img-overlay"></div>
                                                                    </a></div>
                                                            </div>
                                                            <div class="uael-grid-item  uael-img-gallery-item-4">
                                                                <div class="uael-grid-item-content"><a class="uael-grid-img uael-grid-gallery-img uael-ins-hover elementor-clickable" target="_blank" rel="dofollow" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-4.svg" data-elementor-open-lightbox="no">
                                                                        <div class="uael-grid-img-thumbnail uael-ins-target"><img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-4.svg" title="Logo 4" alt="Logo 4" loading="lazy" /></div>
                                                                        <div class="uael-grid-img-overlay"></div>
                                                                    </a></div>
                                                            </div>
                                                            <div class="uael-grid-item  uael-img-gallery-item-5">
                                                                <div class="uael-grid-item-content"><a class="uael-grid-img uael-grid-gallery-img uael-ins-hover elementor-clickable" target="_blank" rel="dofollow" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-5.svg" data-elementor-open-lightbox="no">
                                                                        <div class="uael-grid-img-thumbnail uael-ins-target"><img decoding="async" src="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/Logo-5.svg" title="Logo 5" alt="Logo 5" loading="lazy" /></div>
                                                                        <div class="uael-grid-img-overlay"></div>
                                                                    </a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-e9eac3d e-flex e-con-boxed e-con e-parent" data-id="e9eac3d" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="e-con-inner">
                                            <div class="elementor-element elementor-element-3ed3fee e-con-full e-flex e-con e-child" data-id="3ed3fee" data-element_type="container">
                                                <div class="elementor-element elementor-element-2c436f1 e-grid e-con-full e-con e-child" data-id="2c436f1" data-element_type="container">
                                                    <div class="elementor-element elementor-element-4cfcc6d e-con-full e-flex e-con e-child" data-id="4cfcc6d" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-df40c68 elementor-widget elementor-widget-uael-infobox" data-id="df40c68" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M233.785,349.972c-0.103-3.053-0.787-6.06-2.018-8.855l-6.025-13.699c-1.968-1.55-110.485-87.014-128.158-100.932    c-7.548,10.398-12.414,22.498-14.167,35.227l-11.175,81.113L3.25,461.617c-6.658,11.463-2.761,26.153,8.702,32.81    c11.457,6.655,26.151,2.766,32.811-8.701l71.374-122.892c1.572-2.707,2.6-5.695,3.025-8.797l11.574-84.492l22.818,12.964    l32.413,73.701l3.98,118.27c0.238,7.07,3.523,13.306,8.537,17.533c-2.039-10.298,1.652-21.123,9.869-27.986l28.473-23.781    L233.785,349.972z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <circle cx="268.187" cy="59.805" r="45.481"></circle>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M239.888,338.557l0.734,3.179c2.368,10.256,12.283,16.966,22.708,15.283L239.888,338.557z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M26.727,119.636c-4.97-3.915-12.173-3.059-16.09,1.912c-3.915,4.972-3.059,12.175,1.912,16.09l3.301,2.6L32.28,124.01    L26.727,119.636z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M266.113,165.161c8.382-14.753,3.217-33.508-11.537-41.89l-47.638-27.065c-10.534-5.984-23.105-5.059-32.487,1.328    l26.166,14.323l-83.401-23.101c-6.587-1.824-13.786-0.228-18.996,4.286l-62.213,53.917c-8.609,7.462-9.516,20.483-2.077,29.068    c7.401,8.54,20.47,9.527,29.067,2.077l53.865-46.682l75.526,20.919l-52.233-0.785l-13.95,24.554l84.585,66.617l6.148-16.24    l5.658,25.537l47.017,37.029c-14.272-61.815-9.36-40.784-21.52-92.174L266.113,165.161z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g>
                                                                                                <g>
                                                                                                    <path d="M509.04,476.967l-92.58-107.856c-15.252-17.769-41.949-19.986-59.92-4.976c-3.152,2.633-6.321,5.279-9.397,7.849    L96.897,174.9l-17.632,15.28l249.905,196.816c-4.003,3.343-105.136,87.813-109.069,91.097c-7.613,6.361-3.233,18.982,6.885,18.982    h272.813C510.207,497.076,515.819,484.864,509.04,476.967z"></path>
                                                                                                </g>
                                                                                            </g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                            <g></g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Local Knowledge</h5>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Deep understanding of Austin’s codes, climate, and construction standards. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-6aba1c0 e-con-full e-flex e-con e-child" data-id="6aba1c0" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-5390520 elementor-widget elementor-widget-uael-infobox" data-id="5390520" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" height="512" viewBox="0 0 32 32" width="512">
                                                                                            <g id="_x30_8_Engineer">
                                                                                                <g>
                                                                                                    <path d="m24.7515869 10.0253296c0-.0822144-.0100098-.164978-.0308838-.246521-.6530151-2.5646973-2.4027099-4.65979-4.7207031-5.8117065v2.0328979c0 .5522461-.4472656 1-1 1s-1-.4477539-1-1v-2.7192383-.2807617c0-.5523071-.4476929-1-1-1h-2c-.5523071 0-1 .4476929-1 1v.2806396 2.7193604c0 .5522461-.4477539 1-1 1s-1-.4477539-1-1v-2.0328979c-2.3184814 1.1518554-4.0681763 3.2470092-4.7211914 5.8117065-.020752.081604-.0281372.1641235-.024292.2459106-.7109375.1177369-1.2545166.7309571-1.2545166 1.4752808 0 .8284302.6715698 1.5 1.5 1.5h17c.8284302 0 1.5-.6715698 1.5-1.5 0-.7422485-.5404053-1.3544922-1.2484131-1.4746704z"></path>
                                                                                                    <path d="m23 15h-14v1c0 1.9090576.7699585 3.6403198 2.0134277 4.9044189-.0031738.0322266-.0134277.0627442-.0134277.0955811v1.6835327l4.9750977 2.2109985 5.0249023-2.5126342v-1.381897c0-.0328979-.0102539-.0634766-.0134277-.0957642 1.2434082-1.2640991 2.0134277-2.9953003 2.0134277-4.9042358z"></path>
                                                                                                    <g>
                                                                                                        <path d="m10 30h12v-5.8818359l-5.5527344 2.7763672c-.140625.0703125-.2939453.1054687-.4472656.1054687-.1381836 0-.2768555-.0288086-.40625-.0864258l-5.59375-2.486084z"></path>
                                                                                                        <path d="m8 24.1120605c-2.3813477.7294312-4.4486694 2.2577515-5.8320313 4.333252-.2045898.3066406-.2236328.7011719-.0498047 1.0263672.1743165.3251953.5131837.5283203.881836.5283203h5z"></path>
                                                                                                        <path d="m29.8320313 28.4453125c-1.3832398-2.0753784-3.4504395-3.6036377-5.8320313-4.3331299v5.8878174h5c.3691406 0 .7080078-.203125.8818359-.5283203s.1542969-.7197266-.0498046-1.0263672z"></path>
                                                                                                    </g>
                                                                                                </g>
                                                                                            </g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Pro Team</h5>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Skilled, certified builders and project managers committed to quality. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-feb8934 e-con-full e-flex e-con e-child" data-id="feb8934" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-b348a48 elementor-widget elementor-widget-uael-infobox" data-id="b348a48" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" clip-rule="evenodd" fill-rule="evenodd" height="512" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" width="512">
                                                                                            <g id="Icon">
                                                                                                <path d="m22 21.011h-20c-.414 0-.75.337-.75.75 0 .414.336.75.75.75h20c.414 0 .75-.336.75-.75 0-.413-.336-.75-.75-.75z"></path>
                                                                                                <path d="m14.75 21.761v-18.523c0-.58-.288-1.123-.769-1.449-.481-.325-1.092-.391-1.631-.175l-8 3.2c-.664.265-1.1.909-1.1 1.625v15.322c0 .415.336.75.75.75h10c.414 0 .75-.335.75-.75zm-7.75-2.25h4c.414 0 .75-.336.75-.75 0-.413-.336-.75-.75-.75h-4c-.414 0-.75.337-.75.75 0 .414.336.75.75.75zm0-3.5h4c.414 0 .75-.336.75-.75 0-.413-.336-.75-.75-.75h-4c-.414 0-.75.337-.75.75 0 .414.336.75.75.75zm0-3.5h4c.414 0 .75-.336.75-.75 0-.413-.336-.75-.75-.75h-4c-.414 0-.75.337-.75.75 0 .414.336.75.75.75zm0-3.5h4c.414 0 .75-.336.75-.75 0-.413-.336-.75-.75-.75h-4c-.414 0-.75.337-.75.75 0 .414.336.75.75.75z"></path>
                                                                                                <path d="m15.75 7.011v14.75c0 .269-.06.523-.168.75h4.418c.414 0 .75-.335.75-.75v-13c0-.966-.784-1.75-1.75-1.75z"></path>
                                                                                            </g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Smart Designs</h5>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Modern layouts and features built for comfort, function, and flow. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-7bdb05f e-con-full e-flex e-con e-child" data-id="7bdb05f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                        <div class="elementor-element elementor-element-2db974c elementor-widget elementor-widget-uael-infobox" data-id="2db974c" data-element_type="widget" data-widget_type="uael-infobox.default">
                                                            <div class="elementor-widget-container">

                                                                <div class="uael-module-content uael-infobox uael-imgicon-style-circle  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
                                                                    <div class="uael-infobox-left-right-wrap">
                                                                        <div class="uael-infobox-content">
                                                                            <div class="uael-module-content uael-imgicon-wrap ">
                                                                                <div class="uael-icon-wrap elementor-animation-">
                                                                                    <span class="uael-icon">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="512" viewBox="0 0 66 66" width="512">
                                                                                            <g>
                                                                                                <path d="m23.2 20.1c0 5.9 4.8 10.6 10.6 10.6 2.2 0 4.2-.6 5.8-1.8.1 0 .1-.1.2-.1 2.8-1.9 4.6-5.1 4.6-8.8 0-5.9-4.8-10.6-10.6-10.6s-10.6 4.8-10.6 10.7z"></path>
                                                                                                <path d="m53.2 49.1c0-8.2-5.1-15.5-12.8-18.2-4 2.4-9 2.5-13.1 0-7.7 2.8-12.8 10-12.8 18.2 0 4.8 10 7.4 19.4 7.4s19.3-2.6 19.3-7.4z"></path>
                                                                                                <path d="m8.6 35c0 3.3 2.9 5.6 5.8 5.3 1.1-2.5 2.7-4.7 4.7-6.6-.6-2.3-2.7-4-5.1-4-3 0-5.4 2.4-5.4 5.3z"></path>
                                                                                                <path d="m2.2 49.3c0 .5.3 1 .8 1.4 1.9 1.6 6.4 2.4 10.9 2.1-2.4-1.8-3-3.7-3-5.2 0-2.4.4-4.6 1.1-6.8-1.1-.1-2.2-.4-3.2-.9-4.1 1.5-6.6 5.2-6.6 9.4z"></path>
                                                                                                <path d="m63.8 50.8c0-4.2-2.6-7.9-6.5-9.4-1 .6-2.1.9-3.2.9.7 2.1 1.1 4.4 1.1 6.8 0 2.1-1.1 3.8-3 5.2 3.7.2 11.6-.6 11.6-3.5z"></path>
                                                                                                <path d="m53.8 29.7c-2.5 0-4.5 1.6-5.1 4 2 1.9 3.6 4.1 4.7 6.7 3 .3 5.7-2.1 5.7-5.3 0-3-2.4-5.4-5.3-5.4z"></path>
                                                                                            </g>
                                                                                        </svg> </span>
                                                                                </div>

                                                                            </div>
                                                                            <div class='uael-infobox-title-wrap'>
                                                                                <h5 class="uael-infobox-title elementor-inline-editing" data-elementor-setting-key="infobox_title" data-elementor-inline-editing-toolbar="basic">Client Focus</h5>
                                                                            </div>
                                                                            <div class="uael-infobox-text-wrap">
                                                                                <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                                    Responsive service and communication — your satisfaction is our priority. </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-19742e0 e-con-full e-flex e-con e-child" data-id="19742e0" data-element_type="container">
                                                <div class="elementor-element elementor-element-215f3f4 elementor-widget elementor-widget-text-editor" data-id="215f3f4" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>Why Brikly</p>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-26f6b03 elementor-widget__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-heading" data-id="26f6b03" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">What Sets Us Apart</h2>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-013b4a0 elementor-widget__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-text-editor" data-id="013b4a0" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <p>We’re more than just builders — we’re your trusted local partner. From smart design to solid delivery, every detail is handled with care, precision, and pride.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </div><!-- .entry-content .clear -->



                        </article><!-- #post-## -->

                    </main><!-- #main -->


                </div><!-- #primary -->


            </div> <!-- ast-container -->
        </div><!-- #content -->
<?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        <?php /**PATH C:\xampp\htdocs\vishu\resources\views/website/index.blade.php ENDPATH**/ ?>