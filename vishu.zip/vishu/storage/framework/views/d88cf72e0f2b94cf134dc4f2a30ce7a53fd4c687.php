<!DOCTYPE html>
<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<script type="text/javascript">
		var isInIFrame = (window.self !== window.top) ? true : false;

		if (!isInIFrame) {
			var jsData = ["showcase-cta", "https:\/\/websitedemos.net\/brikly-construction-company-04\/wp-content\/plugins\/astra-sites-server\/admin\/showcase-cta\/switcher\/dist\/style-main.css?ver=6aa7bff7ae92912fbd6e"];
			var style = document.createElement('link');
			style.setAttribute('id', jsData[0]);
			style.setAttribute('rel', 'stylesheet');
			style.setAttribute('type', 'text/css');
			style.setAttribute('media', 'all');
			style.setAttribute('href', jsData[1]);

			document.head.appendChild(style);
		}
	</script>
	<script type="text/javascript">
		var isInIFrame = (window.self !== window.top) ? true : false;

		if (!isInIFrame) {
			var jsData = ["showcase-cta-google-fonts", "\/\/fonts.googleapis.com\/css?family=DM%20Sans%3A400%2C500%2C700&subset=latin%2Clatin-ext"];
			var style = document.createElement('link');
			style.setAttribute('id', jsData[0]);
			style.setAttribute('rel', 'stylesheet');
			style.setAttribute('type', 'text/css');
			style.setAttribute('media', 'all');
			style.setAttribute('href', jsData[1]);

			document.head.appendChild(style);
		}
	</script>
	<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
	<style>
		img:is([sizes="auto" i], [sizes^="auto," i]) {
			contain-intrinsic-size: 3000px 1500px
		}
	</style>

	<!-- This site is optimized with the Yoast SEO plugin v25.8 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Vishu Real Estate | Contact</title>


	<link rel='dns-prefetch' href='//maps.googleapis.com' />
	<link rel='dns-prefetch' href='//unpkg.com' />
	<link rel='dns-prefetch' href='//fonts.googleapis.com' />
	<link rel="alternate" type="application/rss+xml" title="Construction Company &raquo; Feed" href="https://websitedemos.net/brikly-construction-company-04/feed/" />
	<link rel="alternate" type="application/rss+xml" title="Construction Company &raquo; Comments Feed" href="https://websitedemos.net/brikly-construction-company-04/comments/feed/" />
	<script>
		window._wpemojiSettings = {
			"baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/",
			"ext": ".png",
			"svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/",
			"svgExt": ".svg",
			"source": {
				"concatemoji": "https:\/\/websitedemos.net\/brikly-construction-company-04\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.2"
			}
		};
		/*! This file is auto-generated */
		! function(s, n) {
			var o, i, e;

			function c(e) {
				try {
					var t = {
						supportTests: e,
						timestamp: (new Date).valueOf()
					};
					sessionStorage.setItem(o, JSON.stringify(t))
				} catch (e) {}
			}

			function p(e, t, n) {
				e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0);
				var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data),
					a = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data));
				return t.every(function(e, t) {
					return e === a[t]
				})
			}

			function u(e, t) {
				e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0);
				for (var n = e.getImageData(16, 16, 1, 1), a = 0; a < n.data.length; a++)
					if (0 !== n.data[a]) return !1;
				return !0
			}

			function f(e, t, n, a) {
				switch (t) {
					case "flag":
						return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\udde8\ud83c\uddf6", "\ud83c\udde8\u200b\ud83c\uddf6") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");
					case "emoji":
						return !a(e, "\ud83e\udedf")
				}
				return !1
			}

			function g(e, t, n, a) {
				var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : s.createElement("canvas"),
					o = r.getContext("2d", {
						willReadFrequently: !0
					}),
					i = (o.textBaseline = "top", o.font = "600 32px Arial", {});
				return e.forEach(function(e) {
					i[e] = t(o, e, n, a)
				}), i
			}

			function t(e) {
				var t = s.createElement("script");
				t.src = e, t.defer = !0, s.head.appendChild(t)
			}
			"undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", i = ["flag", "emoji"], n.supports = {
				everything: !0,
				everythingExceptFlag: !0
			}, e = new Promise(function(e) {
				s.addEventListener("DOMContentLoaded", e, {
					once: !0
				})
			}), new Promise(function(t) {
				var n = function() {
					try {
						var e = JSON.parse(sessionStorage.getItem(o));
						if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests
					} catch (e) {}
					return null
				}();
				if (!n) {
					if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try {
						var e = "postMessage(" + g.toString() + "(" + [JSON.stringify(i), f.toString(), p.toString(), u.toString()].join(",") + "));",
							a = new Blob([e], {
								type: "text/javascript"
							}),
							r = new Worker(URL.createObjectURL(a), {
								name: "wpTestEmojiSupports"
							});
						return void(r.onmessage = function(e) {
							c(n = e.data), r.terminate(), t(n)
						})
					} catch (e) {}
					c(n = g(i, f, p, u))
				}
				t(n)
			}).then(function(e) {
				for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]);
				n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function() {
					n.DOMReady = !0
				}
			}).then(function() {
				return e
			}).then(function() {
				var e;
				n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji)))
			}))
		}((window, document), window._wpemojiSettings);
	</script>
	<link rel='stylesheet' id='astra-theme-css-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/themes/astra/assets/css/minified/main.min.css?ver=4.11.10' media='all' />
	<style id='astra-theme-css-inline-css'>
		:root {
			--ast-post-nav-space: 0;
			--ast-container-default-xlg-padding: 2.5em;
			--ast-container-default-lg-padding: 2.5em;
			--ast-container-default-slg-padding: 2em;
			--ast-container-default-md-padding: 2.5em;
			--ast-container-default-sm-padding: 2.5em;
			--ast-container-default-xs-padding: 2.4em;
			--ast-container-default-xxs-padding: 1.8em;
			--ast-code-block-background: #ECEFF3;
			--ast-comment-inputs-background: #F9FAFB;
			--ast-normal-container-width: 1200px;
			--ast-narrow-container-width: 750px;
			--ast-blog-title-font-weight: 600;
			--ast-blog-meta-weight: 600;
			--ast-global-color-primary: var(--ast-global-color-4);
			--ast-global-color-secondary: var(--ast-global-color-5);
			--ast-global-color-alternate-background: var(--ast-global-color-6);
			--ast-global-color-subtle-background: var(--ast-global-color-7);
			--ast-bg-style-guide: #F8FAFC;
			--ast-shadow-style-guide: 0px 0px 4px 0 #00000057;
			--ast-global-dark-bg-style: #fff;
			--ast-global-dark-lfs: #fbfbfb;
			--ast-widget-bg-color: #fafafa;
			--ast-wc-container-head-bg-color: #fbfbfb;
			--ast-title-layout-bg: #eeeeee;
			--ast-search-border-color: #e7e7e7;
			--ast-lifter-hover-bg: #e6e6e6;
			--ast-gallery-block-color: #000;
			--srfm-color-input-label: var(--ast-global-color-2);
		}

		html {
			font-size: 100%;
		}

		a {
			color: var(--ast-global-color-2);
		}

		a:hover,
		a:focus {
			color: var(--ast-global-color-3);
		}

		body,
		button,
		input,
		select,
		textarea,
		.ast-button,
		.ast-custom-button {
			font-family: 'Roboto', sans-serif;
			font-weight: 400;
			font-size: 16px;
			font-size: 1rem;
			line-height: var(--ast-body-line-height, 1.65);
		}

		blockquote {
			color: var(--ast-global-color-3);
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		.entry-content :where(h1, h2, h3, h4, h5, h6),
		.site-title,
		.site-title a {
			font-family: 'Inter', sans-serif;
			font-weight: 700;
			letter-spacing: -2px;
		}

		.ast-site-identity .site-title a {
			color: var(--ast-global-color-2);
		}

		.site-title {
			font-size: 26px;
			font-size: 1.625rem;
			display: none;
		}

		.site-header .site-description {
			font-size: 15px;
			font-size: 0.9375rem;
			display: none;
		}

		.entry-title {
			font-size: 24px;
			font-size: 1.5rem;
		}

		.ast-blog-single-element.ast-taxonomy-container a {
			font-size: 12px;
			font-size: 0.75rem;
		}

		.ast-blog-meta-container {
			font-size: 14px;
			font-size: 0.875rem;
		}

		.archive .ast-article-post .ast-article-inner,
		.blog .ast-article-post .ast-article-inner,
		.archive .ast-article-post .ast-article-inner:hover,
		.blog .ast-article-post .ast-article-inner:hover {
			border-top-left-radius: 18px;
			border-top-right-radius: 18px;
			border-bottom-right-radius: 18px;
			border-bottom-left-radius: 18px;
			overflow: hidden;
		}

		h1,
		.entry-content :where(h1) {
			font-size: 80px;
			font-size: 5rem;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			line-height: 1.1em;
		}

		h2,
		.entry-content :where(h2) {
			font-size: 54px;
			font-size: 3.375rem;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			line-height: 1.3em;
		}

		h3,
		.entry-content :where(h3) {
			font-size: 42px;
			font-size: 2.625rem;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			line-height: 1.3em;
		}

		h4,
		.entry-content :where(h4) {
			font-size: 32px;
			font-size: 2rem;
			line-height: 1.2em;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			letter-spacing: -1px;
		}

		h5,
		.entry-content :where(h5) {
			font-size: 24px;
			font-size: 1.5rem;
			line-height: 1.2em;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			letter-spacing: -1px;
		}

		h6,
		.entry-content :where(h6) {
			font-size: 20px;
			font-size: 1.25rem;
			line-height: 1.25em;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			letter-spacing: -1px;
		}

		::selection {
			background-color: var(--ast-global-color-0);
			color: #000000;
		}

		body,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		.entry-title a,
		.entry-content :where(h1, h2, h3, h4, h5, h6) {
			color: var(--ast-global-color-3);
		}

		.tagcloud a:hover,
		.tagcloud a:focus,
		.tagcloud a.current-item {
			color: #ffffff;
			border-color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-2);
		}

		input:focus,
		input[type="text"]:focus,
		input[type="email"]:focus,
		input[type="url"]:focus,
		input[type="password"]:focus,
		input[type="reset"]:focus,
		input[type="search"]:focus,
		textarea:focus {
			border-color: var(--ast-global-color-2);
		}

		input[type="radio"]:checked,
		input[type=reset],
		input[type="checkbox"]:checked,
		input[type="checkbox"]:hover:checked,
		input[type="checkbox"]:focus:checked,
		input[type=range]::-webkit-slider-thumb {
			border-color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-2);
			box-shadow: none;
		}

		.site-footer a:hover+.post-count,
		.site-footer a:focus+.post-count {
			background: var(--ast-global-color-2);
			border-color: var(--ast-global-color-2);
		}

		.single .nav-links .nav-previous,
		.single .nav-links .nav-next {
			color: var(--ast-global-color-2);
		}

		.entry-meta,
		.entry-meta * {
			line-height: 1.45;
			color: var(--ast-global-color-2);
		}

		.entry-meta a:not(.ast-button):hover,
		.entry-meta a:not(.ast-button):hover *,
		.entry-meta a:not(.ast-button):focus,
		.entry-meta a:not(.ast-button):focus *,
		.page-links>.page-link,
		.page-links .page-link:hover,
		.post-navigation a:hover {
			color: var(--ast-global-color-3);
		}

		#cat option,
		.secondary .calendar_wrap thead a,
		.secondary .calendar_wrap thead a:visited {
			color: var(--ast-global-color-2);
		}

		.secondary .calendar_wrap #today,
		.ast-progress-val span {
			background: var(--ast-global-color-2);
		}

		.secondary a:hover+.post-count,
		.secondary a:focus+.post-count {
			background: var(--ast-global-color-2);
			border-color: var(--ast-global-color-2);
		}

		.calendar_wrap #today>a {
			color: #ffffff;
		}

		.page-links .page-link,
		.single .post-navigation a {
			color: var(--ast-global-color-3);
		}

		.ast-search-menu-icon .search-form button.search-submit {
			padding: 0 4px;
		}

		.ast-search-menu-icon form.search-form {
			padding-right: 0;
		}

		.ast-search-menu-icon.slide-search input.search-field {
			width: 0;
		}

		.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-form,
		.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-field:focus {
			transition: all 0.2s;
		}

		.search-form input.search-field:focus {
			outline: none;
		}

		.ast-search-menu-icon .search-form button.search-submit:focus,
		.ast-theme-transparent-header .ast-header-search .ast-dropdown-active .ast-icon,
		.ast-theme-transparent-header .ast-inline-search .search-field:focus .ast-icon {
			color: var(--ast-global-color-1);
		}

		.ast-header-search .slide-search .search-form {
			border: 2px solid var(--ast-global-color-0);
		}

		.ast-header-search .slide-search .search-field {
			background-color: (--ast-global-dark-bg-style);
		}

		.ast-archive-title {
			color: var(--ast-global-color-2);
		}

		.widget-title {
			font-size: 22px;
			font-size: 1.375rem;
			color: var(--ast-global-color-2);
		}

		.single .ast-author-details .author-title {
			color: var(--ast-global-color-3);
		}

		.ast-single-post .entry-content a,
		.ast-comment-content a:not(.ast-comment-edit-reply-wrap a) {
			text-decoration: underline;
		}

		.ast-single-post .elementor-widget-button .elementor-button,
		.ast-single-post .entry-content .uagb-tab a,
		.ast-single-post .entry-content .uagb-ifb-cta a,
		.ast-single-post .entry-content .uabb-module-content a,
		.ast-single-post .entry-content .uagb-post-grid a,
		.ast-single-post .entry-content .uagb-timeline a,
		.ast-single-post .entry-content .uagb-toc__wrap a,
		.ast-single-post .entry-content .uagb-taxomony-box a,
		.entry-content .wp-block-latest-posts>li>a,
		.ast-single-post .entry-content .wp-block-file__button,
		a.ast-post-filter-single,
		.ast-single-post .ast-comment-content .comment-reply-link,
		.ast-single-post .ast-comment-content .comment-edit-link {
			text-decoration: none;
		}

		.ast-search-menu-icon.slide-search a:focus-visible:focus-visible,
		.astra-search-icon:focus-visible,
		#close:focus-visible,
		a:focus-visible,
		.ast-menu-toggle:focus-visible,
		.site .skip-link:focus-visible,
		.wp-block-loginout input:focus-visible,
		.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper,
		.ast-header-navigation-arrow:focus-visible,
		.ast-orders-table__row .ast-orders-table__cell:focus-visible,
		a#ast-apply-coupon:focus-visible,
		#ast-apply-coupon:focus-visible,
		#close:focus-visible,
		.button.search-submit:focus-visible,
		#search_submit:focus,
		.normal-search:focus-visible,
		.ast-header-account-wrap:focus-visible,
		.astra-cart-drawer-close:focus,
		.ast-single-variation:focus,
		.ast-button:focus {
			outline-style: dotted;
			outline-color: inherit;
			outline-width: thin;
		}

		input:focus,
		input[type="text"]:focus,
		input[type="email"]:focus,
		input[type="url"]:focus,
		input[type="password"]:focus,
		input[type="reset"]:focus,
		input[type="search"]:focus,
		input[type="number"]:focus,
		textarea:focus,
		.wp-block-search__input:focus,
		[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal:focus,
		.ast-mobile-popup-drawer.active .menu-toggle-close:focus,
		#ast-scroll-top:focus,
		#coupon_code:focus,
		#ast-coupon-code:focus {
			border-style: dotted;
			border-color: inherit;
			border-width: thin;
		}

		input {
			outline: none;
		}

		.ast-logo-title-inline .site-logo-img {
			padding-right: 1em;
		}

		.site-logo-img img {
			transition: all 0.2s linear;
		}

		body .ast-oembed-container * {
			position: absolute;
			top: 0;
			width: 100%;
			height: 100%;
			left: 0;
		}

		body .wp-block-embed-pocket-casts .ast-oembed-container * {
			position: unset;
		}

		.ast-single-post-featured-section+article {
			margin-top: 2em;
		}

		.site-content .ast-single-post-featured-section img {
			width: 100%;
			overflow: hidden;
			object-fit: cover;
		}

		.ast-separate-container .site-content .ast-single-post-featured-section+article {
			margin-top: -80px;
			z-index: 9;
			position: relative;
			border-radius: 4px;
		}

		@media (min-width: 922px) {
			.ast-no-sidebar .site-content .ast-article-image-container--wide {
				margin-left: -120px;
				margin-right: -120px;
				max-width: unset;
				width: unset;
			}

			.ast-left-sidebar .site-content .ast-article-image-container--wide,
			.ast-right-sidebar .site-content .ast-article-image-container--wide {
				margin-left: -10px;
				margin-right: -10px;
			}

			.site-content .ast-article-image-container--full {
				margin-left: calc(-50vw + 50%);
				margin-right: calc(-50vw + 50%);
				max-width: 100vw;
				width: 100vw;
			}

			.ast-left-sidebar .site-content .ast-article-image-container--full,
			.ast-right-sidebar .site-content .ast-article-image-container--full {
				margin-left: -10px;
				margin-right: -10px;
				max-width: inherit;
				width: auto;
			}
		}

		.site>.ast-single-related-posts-container {
			margin-top: 0;
		}

		@media (min-width: 922px) {
			.ast-desktop .ast-container--narrow {
				max-width: var(--ast-narrow-container-width);
				margin: 0 auto;
			}
		}

		.ast-page-builder-template .hentry {
			margin: 0;
		}

		.ast-page-builder-template .site-content>.ast-container {
			max-width: 100%;
			padding: 0;
		}

		.ast-page-builder-template .site .site-content #primary {
			padding: 0;
			margin: 0;
		}

		.ast-page-builder-template .no-results {
			text-align: center;
			margin: 4em auto;
		}

		.ast-page-builder-template .ast-pagination {
			padding: 2em;
		}

		.ast-page-builder-template .entry-header.ast-no-title.ast-no-thumbnail {
			margin-top: 0;
		}

		.ast-page-builder-template .entry-header.ast-header-without-markup {
			margin-top: 0;
			margin-bottom: 0;
		}

		.ast-page-builder-template .entry-header.ast-no-title.ast-no-meta {
			margin-bottom: 0;
		}

		.ast-page-builder-template.single .post-navigation {
			padding-bottom: 2em;
		}

		.ast-page-builder-template.single-post .site-content>.ast-container {
			max-width: 100%;
		}

		.ast-page-builder-template .entry-header {
			margin-top: 2em;
			margin-left: auto;
			margin-right: auto;
		}

		.ast-page-builder-template .ast-archive-description {
			margin: 2em auto 0;
			padding-left: 20px;
			padding-right: 20px;
		}

		.ast-page-builder-template .ast-row {
			margin-left: 0;
			margin-right: 0;
		}

		.single.ast-page-builder-template .entry-header+.entry-content,
		.single.ast-page-builder-template .ast-single-entry-banner+.site-content article .entry-content {
			margin-bottom: 2em;
		}

		@media(min-width: 921px) {

			.ast-page-builder-template.archive.ast-right-sidebar .ast-row article,
			.ast-page-builder-template.archive.ast-left-sidebar .ast-row article {
				padding-left: 0;
				padding-right: 0;
			}
		}

		input[type="text"],
		input[type="number"],
		input[type="email"],
		input[type="url"],
		input[type="password"],
		input[type="search"],
		input[type=reset],
		input[type=tel],
		input[type=date],
		select,
		textarea {
			font-size: 16px;
			font-style: normal;
			font-weight: 400;
			line-height: 24px;
			width: 100%;
			padding: 12px 16px;
			border-radius: 4px;
			box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
			color: var(--ast-form-input-text, #475569);
		}

		input[type="text"],
		input[type="number"],
		input[type="email"],
		input[type="url"],
		input[type="password"],
		input[type="search"],
		input[type=reset],
		input[type=tel],
		input[type=date],
		select {
			height: 40px;
		}

		input[type="date"] {
			border-width: 1px;
			border-style: solid;
			border-color: var(--ast-border-color);
			background: var(--ast-global-color-secondary, --ast-global-color-5);
		}

		input[type="text"]:focus,
		input[type="number"]:focus,
		input[type="email"]:focus,
		input[type="url"]:focus,
		input[type="password"]:focus,
		input[type="search"]:focus,
		input[type=reset]:focus,
		input[type="tel"]:focus,
		input[type="date"]:focus,
		select:focus,
		textarea:focus {
			border-color: #046BD2;
			box-shadow: none;
			outline: none;
			color: var(--ast-form-input-focus-text, #475569);
		}

		label,
		legend {
			color: #111827;
			font-size: 14px;
			font-style: normal;
			font-weight: 500;
			line-height: 20px;
		}

		select {
			padding: 6px 10px;
		}

		fieldset {
			padding: 30px;
			border-radius: 4px;
		}

		button,
		.ast-button,
		.button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"] {
			border-radius: 4px;
			box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
		}

		:root {
			--ast-comment-inputs-background: #FFF;
		}

		::placeholder {
			color: var(--ast-form-field-color, #9CA3AF);
		}

		::-ms-input-placeholder {
			color: var(--ast-form-field-color, #9CA3AF);
		}

		@media (max-width:921.9px) {
			#ast-desktop-header {
				display: none;
			}
		}

		@media (min-width:922px) {
			#ast-mobile-header {
				display: none;
			}
		}

		.wp-block-buttons.aligncenter {
			justify-content: center;
		}

		@media (max-width:921px) {

			.ast-theme-transparent-header #primary,
			.ast-theme-transparent-header #secondary {
				padding: 0;
			}
		}

		@media (max-width:921px) {
			.ast-plain-container.ast-no-sidebar #primary {
				padding: 0;
			}
		}

		.ast-plain-container.ast-no-sidebar #primary {
			margin-top: 0;
			margin-bottom: 0;
		}

		.wp-block-button.is-style-outline .wp-block-button__link {
			border-color: var(--ast-global-color-0);
		}

		div.wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
		div.wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color) {
			color: var(--ast-global-color-0);
		}

		.wp-block-button.is-style-outline .wp-block-button__link:hover,
		.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,
		.wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color):hover,
		.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover {
			color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-1);
			border-color: var(--ast-global-color-1);
		}

		.post-page-numbers.current .page-link,
		.ast-pagination .page-numbers.current {
			color: #000000;
			border-color: var(--ast-global-color-0);
			background-color: var(--ast-global-color-0);
		}

		.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
		.ast-outline-button,
		.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
			border-color: var(--ast-global-color-0);
			border-top-width: 2px;
			border-right-width: 2px;
			border-bottom-width: 2px;
			border-left-width: 2px;
			font-family: inherit;
			font-weight: 500;
			font-size: 16px;
			font-size: 1rem;
			line-height: 1em;
			padding-top: 13px;
			padding-right: 30px;
			padding-bottom: 13px;
			padding-left: 30px;
		}

		.wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
		.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color),
		.ast-outline-button {
			color: var(--ast-global-color-0);
		}

		.wp-block-button.is-style-outline .wp-block-button__link:hover,
		.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,
		.wp-block-buttons .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color):hover,
		.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover,
		.ast-outline-button:hover,
		.ast-outline-button:focus,
		.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:hover,
		.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:focus {
			color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-1);
			border-color: var(--ast-global-color-1);
		}

		.ast-single-post .entry-content a.ast-outline-button,
		.ast-single-post .entry-content .is-style-outline>.wp-block-button__link {
			text-decoration: none;
		}

		.wp-block-button .wp-block-button__link.wp-element-button.is-style-outline:not(.has-background),
		.wp-block-button.is-style-outline>.wp-block-button__link.wp-element-button:not(.has-background),
		.ast-outline-button {
			background-color: transparent;
		}

		.uagb-buttons-repeater.ast-outline-button {
			border-radius: 9999px;
		}

		@media (max-width:921px) {

			.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
			.ast-outline-button,
			.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
				padding-top: 12px;
				padding-right: 28px;
				padding-bottom: 12px;
				padding-left: 28px;
			}
		}

		@media (max-width:544px) {

			.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,
			.ast-outline-button,
			.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button {
				padding-top: 10px;
				padding-right: 24px;
				padding-bottom: 10px;
				padding-left: 24px;
			}
		}

		.entry-content[data-ast-blocks-layout]>figure {
			margin-bottom: 1em;
		}

		h1.widget-title {
			font-weight: 700;
		}

		h2.widget-title {
			font-weight: 700;
		}

		h3.widget-title {
			font-weight: 700;
		}

		#page {
			display: flex;
			flex-direction: column;
			min-height: 100vh;
		}

		.ast-404-layout-1 h1.page-title {
			color: var(--ast-global-color-2);
		}

		.single .post-navigation a {
			line-height: 1em;
			height: inherit;
		}

		.error-404 .page-sub-title {
			font-size: 1.5rem;
			font-weight: inherit;
		}

		.search .site-content .content-area .search-form {
			margin-bottom: 0;
		}

		#page .site-content {
			flex-grow: 1;
		}

		.widget {
			margin-bottom: 1.25em;
		}

		#secondary li {
			line-height: 1.5em;
		}

		#secondary .wp-block-group h2 {
			margin-bottom: 0.7em;
		}

		#secondary h2 {
			font-size: 1.7rem;
		}

		.ast-separate-container .ast-article-post,
		.ast-separate-container .ast-article-single,
		.ast-separate-container .comment-respond {
			padding: 3em;
		}

		.ast-separate-container .ast-article-single .ast-article-single {
			padding: 0;
		}

		.ast-article-single .wp-block-post-template-is-layout-grid {
			padding-left: 0;
		}

		.ast-separate-container .comments-title,
		.ast-narrow-container .comments-title {
			padding: 1.5em 2em;
		}

		.ast-page-builder-template .comment-form-textarea,
		.ast-comment-formwrap .ast-grid-common-col {
			padding: 0;
		}

		.ast-comment-formwrap {
			padding: 0;
			display: inline-flex;
			column-gap: 20px;
			width: 100%;
			margin-left: 0;
			margin-right: 0;
		}

		.comments-area textarea#comment:focus,
		.comments-area textarea#comment:active,
		.comments-area .ast-comment-formwrap input[type="text"]:focus,
		.comments-area .ast-comment-formwrap input[type="text"]:active {
			box-shadow: none;
			outline: none;
		}

		.archive.ast-page-builder-template .entry-header {
			margin-top: 2em;
		}

		.ast-page-builder-template .ast-comment-formwrap {
			width: 100%;
		}

		.entry-title {
			margin-bottom: 0.6em;
		}

		.ast-archive-description p {
			font-size: inherit;
			font-weight: inherit;
			line-height: inherit;
		}

		.ast-separate-container .ast-comment-list li.depth-1,
		.hentry {
			margin-bottom: 1.5em;
		}

		.site-content section.ast-archive-description {
			margin-bottom: 2em;
		}

		@media (min-width:921px) {

			.ast-left-sidebar.ast-page-builder-template #secondary,
			.archive.ast-right-sidebar.ast-page-builder-template .site-main {
				padding-left: 20px;
				padding-right: 20px;
			}
		}

		@media (max-width:544px) {
			.ast-comment-formwrap.ast-row {
				column-gap: 10px;
				display: inline-block;
			}

			#ast-commentform .ast-grid-common-col {
				position: relative;
				width: 100%;
			}
		}

		@media (min-width:1201px) {

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .ast-author-box,
			.ast-separate-container .ast-404-layout-1,
			.ast-separate-container .no-results {
				padding: 3em;
			}
		}

		@media (max-width:921px) {

			.ast-separate-container #primary,
			.ast-separate-container #secondary {
				padding: 1.5em 0;
			}

			#primary,
			#secondary {
				padding: 1.5em 0;
				margin: 0;
			}

			.ast-left-sidebar #content>.ast-container {
				display: flex;
				flex-direction: column-reverse;
				width: 100%;
			}
		}

		@media (min-width:922px) {

			.ast-separate-container.ast-right-sidebar #primary,
			.ast-separate-container.ast-left-sidebar #primary {
				border: 0;
			}

			.search-no-results.ast-separate-container #primary {
				margin-bottom: 4em;
			}
		}

		.elementor-widget-button .elementor-button {
			border-style: solid;
			text-decoration: none;
			border-top-width: 0;
			border-right-width: 0;
			border-left-width: 0;
			border-bottom-width: 0;
		}

		.elementor-button.elementor-size-sm,
		.elementor-button.elementor-size-xs,
		.elementor-button.elementor-size-md,
		.elementor-button.elementor-size-lg,
		.elementor-button.elementor-size-xl,
		.elementor-button {
			padding-top: 15px;
			padding-right: 30px;
			padding-bottom: 15px;
			padding-left: 30px;
		}

		@media (max-width:921px) {

			.elementor-widget-button .elementor-button.elementor-size-sm,
			.elementor-widget-button .elementor-button.elementor-size-xs,
			.elementor-widget-button .elementor-button.elementor-size-md,
			.elementor-widget-button .elementor-button.elementor-size-lg,
			.elementor-widget-button .elementor-button.elementor-size-xl,
			.elementor-widget-button .elementor-button {
				padding-top: 14px;
				padding-right: 28px;
				padding-bottom: 14px;
				padding-left: 28px;
			}
		}

		@media (max-width:544px) {

			.elementor-widget-button .elementor-button.elementor-size-sm,
			.elementor-widget-button .elementor-button.elementor-size-xs,
			.elementor-widget-button .elementor-button.elementor-size-md,
			.elementor-widget-button .elementor-button.elementor-size-lg,
			.elementor-widget-button .elementor-button.elementor-size-xl,
			.elementor-widget-button .elementor-button {
				padding-top: 12px;
				padding-right: 24px;
				padding-bottom: 12px;
				padding-left: 24px;
			}
		}

		.elementor-widget-button .elementor-button {
			border-color: var(--ast-global-color-0);
			background-color: var(--ast-global-color-0);
		}

		.elementor-widget-button .elementor-button:hover,
		.elementor-widget-button .elementor-button:focus {
			color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-1);
			border-color: var(--ast-global-color-1);
		}

		.wp-block-button .wp-block-button__link,
		.elementor-widget-button .elementor-button,
		.elementor-widget-button .elementor-button:visited {
			color: var(--ast-global-color-2);
		}

		.elementor-widget-button .elementor-button {
			font-weight: 600;
			font-size: 16px;
			font-size: 1rem;
			line-height: 1em;
			text-transform: uppercase;
			letter-spacing: 2px;
		}

		body .elementor-button.elementor-size-sm,
		body .elementor-button.elementor-size-xs,
		body .elementor-button.elementor-size-md,
		body .elementor-button.elementor-size-lg,
		body .elementor-button.elementor-size-xl,
		body .elementor-button {
			font-size: 16px;
			font-size: 1rem;
		}

		.wp-block-button .wp-block-button__link:hover,
		.wp-block-button .wp-block-button__link:focus {
			color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-1);
			border-color: var(--ast-global-color-1);
		}

		.elementor-widget-heading h1.elementor-heading-title {
			line-height: 1.1em;
		}

		.elementor-widget-heading h2.elementor-heading-title {
			line-height: 1.3em;
		}

		.elementor-widget-heading h3.elementor-heading-title {
			line-height: 1.3em;
		}

		.elementor-widget-heading h4.elementor-heading-title {
			line-height: 1.2em;
		}

		.elementor-widget-heading h5.elementor-heading-title {
			line-height: 1.2em;
		}

		.elementor-widget-heading h6.elementor-heading-title {
			line-height: 1.25em;
		}

		.wp-block-button .wp-block-button__link,
		.wp-block-search .wp-block-search__button,
		body .wp-block-file .wp-block-file__button {
			border-color: var(--ast-global-color-0);
			background-color: var(--ast-global-color-0);
			color: var(--ast-global-color-2);
			font-family: inherit;
			font-weight: 600;
			line-height: 1em;
			text-transform: uppercase;
			letter-spacing: 2px;
			font-size: 16px;
			font-size: 1rem;
			padding-top: 15px;
			padding-right: 30px;
			padding-bottom: 15px;
			padding-left: 30px;
		}

		.ast-single-post .entry-content .wp-block-button .wp-block-button__link,
		.ast-single-post .entry-content .wp-block-search .wp-block-search__button,
		body .entry-content .wp-block-file .wp-block-file__button {
			text-decoration: none;
		}

		@media (max-width:921px) {

			.wp-block-button .wp-block-button__link,
			.wp-block-search .wp-block-search__button,
			body .wp-block-file .wp-block-file__button {
				padding-top: 14px;
				padding-right: 28px;
				padding-bottom: 14px;
				padding-left: 28px;
			}
		}

		@media (max-width:544px) {

			.wp-block-button .wp-block-button__link,
			.wp-block-search .wp-block-search__button,
			body .wp-block-file .wp-block-file__button {
				padding-top: 12px;
				padding-right: 24px;
				padding-bottom: 12px;
				padding-left: 24px;
			}
		}

		.menu-toggle,
		button,
		.ast-button,
		.ast-custom-button,
		.button,
		input#submit,
		input[type="button"],
		input[type="submit"],
		input[type="reset"],
		#comments .submit,
		.search .search-submit,
		form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
		body .wp-block-file .wp-block-file__button,
		.search .search-submit {
			border-style: solid;
			border-top-width: 0;
			border-right-width: 0;
			border-left-width: 0;
			border-bottom-width: 0;
			color: var(--ast-global-color-2);
			border-color: var(--ast-global-color-0);
			background-color: var(--ast-global-color-0);
			padding-top: 15px;
			padding-right: 30px;
			padding-bottom: 15px;
			padding-left: 30px;
			font-family: inherit;
			font-weight: 600;
			font-size: 16px;
			font-size: 1rem;
			line-height: 1em;
			text-transform: uppercase;
			letter-spacing: 2px;
		}

		button:focus,
		.menu-toggle:hover,
		button:hover,
		.ast-button:hover,
		.ast-custom-button:hover .button:hover,
		.ast-custom-button:hover,
		input[type=reset]:hover,
		input[type=reset]:focus,
		input#submit:hover,
		input#submit:focus,
		input[type="button"]:hover,
		input[type="button"]:focus,
		input[type="submit"]:hover,
		input[type="submit"]:focus,
		form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:hover,
		form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:focus,
		body .wp-block-file .wp-block-file__button:hover,
		body .wp-block-file .wp-block-file__button:focus {
			color: var(--ast-global-color-2);
			background-color: var(--ast-global-color-1);
			border-color: var(--ast-global-color-1);
		}

		form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button.has-icon {
			padding-top: calc(15px - 3px);
			padding-right: calc(30px - 3px);
			padding-bottom: calc(15px - 3px);
			padding-left: calc(30px - 3px);
		}

		@media (max-width:921px) {

			.menu-toggle,
			button,
			.ast-button,
			.ast-custom-button,
			.button,
			input#submit,
			input[type="button"],
			input[type="submit"],
			input[type="reset"],
			#comments .submit,
			.search .search-submit,
			form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
			body .wp-block-file .wp-block-file__button,
			.search .search-submit {
				padding-top: 14px;
				padding-right: 28px;
				padding-bottom: 14px;
				padding-left: 28px;
			}
		}

		@media (max-width:544px) {

			.menu-toggle,
			button,
			.ast-button,
			.ast-custom-button,
			.button,
			input#submit,
			input[type="button"],
			input[type="submit"],
			input[type="reset"],
			#comments .submit,
			.search .search-submit,
			form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,
			body .wp-block-file .wp-block-file__button,
			.search .search-submit {
				padding-top: 12px;
				padding-right: 24px;
				padding-bottom: 12px;
				padding-left: 24px;
			}
		}

		@media (max-width:921px) {
			.ast-mobile-header-stack .main-header-bar .ast-search-menu-icon {
				display: inline-block;
			}

			.ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon {
				margin: 0;
			}

			.ast-comment-avatar-wrap img {
				max-width: 2.5em;
			}

			.ast-comment-meta {
				padding: 0 1.8888em 1.3333em;
			}
		}

		@media (min-width:544px) {
			.ast-container {
				max-width: 100%;
			}
		}

		@media (max-width:544px) {

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .comments-title,
			.ast-separate-container .ast-archive-description {
				padding: 1.5em 1em;
			}

			.ast-separate-container #content .ast-container {
				padding-left: 0.54em;
				padding-right: 0.54em;
			}

			.ast-separate-container .ast-comment-list .bypostauthor {
				padding: .5em;
			}

			.ast-search-menu-icon.ast-dropdown-active .search-field {
				width: 170px;
			}
		}

		#ast-mobile-header .ast-site-header-cart-li a {
			pointer-events: none;
		}

		.ast-separate-container {
			background-color: var(--ast-global-color-5);
			background-image: none;
		}

		@media (max-width:921px) {
			.site-title {
				display: none;
			}

			.site-header .site-description {
				display: none;
			}

			h1,
			.entry-content :where(h1) {
				font-size: 44px;
				font-size: 2.75rem;
			}

			h2,
			.entry-content :where(h2) {
				font-size: 32px;
				font-size: 2rem;
			}

			h3,
			.entry-content :where(h3) {
				font-size: 26px;
				font-size: 1.625rem;
			}

			h4,
			.entry-content :where(h4) {
				font-size: 22px;
				font-size: 1.375rem;
			}

			h5,
			.entry-content :where(h5) {
				font-size: 20px;
				font-size: 1.25rem;
			}

			h6,
			.entry-content :where(h6) {
				font-size: 18px;
				font-size: 1.125rem;
			}
		}

		@media (max-width:544px) {
			.site-title {
				display: none;
			}

			.site-header .site-description {
				display: none;
			}

			h1,
			.entry-content :where(h1) {
				font-size: 36px;
				font-size: 2.25rem;
			}

			h2,
			.entry-content :where(h2) {
				font-size: 30px;
				font-size: 1.875rem;
			}

			h3,
			.entry-content :where(h3) {
				font-size: 26px;
				font-size: 1.625rem;
			}

			h4,
			.entry-content :where(h4) {
				font-size: 24px;
				font-size: 1.5rem;
			}

			h5,
			.entry-content :where(h5) {
				font-size: 20px;
				font-size: 1.25rem;
			}

			h6,
			.entry-content :where(h6) {
				font-size: 18px;
				font-size: 1.125rem;
			}

			header .custom-logo-link img,
			.ast-header-break-point .site-branding img,
			.ast-header-break-point .custom-logo-link img {
				max-width: 80px;
				width: 80px;
			}

			.astra-logo-svg {
				width: 80px;
			}

			.astra-logo-svg:not(.sticky-custom-logo .astra-logo-svg, .transparent-custom-logo .astra-logo-svg, .advanced-header-logo .astra-logo-svg) {
				height: 19px;
			}

			.ast-header-break-point .site-logo-img .custom-mobile-logo-link img {
				max-width: 80px;
			}
		}

		@media (max-width:921px) {
			html {
				font-size: 91.2%;
			}
		}

		@media (max-width:544px) {
			html {
				font-size: 91.2%;
			}
		}

		@media (min-width:922px) {
			.ast-container {
				max-width: 1240px;
			}
		}

		@media (min-width:922px) {
			.site-content .ast-container {
				display: flex;
			}
		}

		@media (max-width:921px) {
			.site-content .ast-container {
				flex-direction: column;
			}
		}

		.entry-content :where(h1, h2, h3, h4, h5, h6) {
			clear: none;
		}

		@media (min-width:922px) {

			.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover>.sub-menu,
			.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus>.sub-menu {
				margin-left: -0px;
			}
		}

		.ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
			background: transparent;
		}

		.entry-content li>p {
			margin-bottom: 0;
		}

		.site .comments-area {
			padding-bottom: 2em;
			margin-top: 0em;
		}

		.wp-block-file {
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			justify-content: space-between;
		}

		.wp-block-pullquote {
			border: none;
		}

		.wp-block-pullquote blockquote::before {
			content: "\201D";
			font-family: "Helvetica", sans-serif;
			display: flex;
			transform: rotate(180deg);
			font-size: 6rem;
			font-style: normal;
			line-height: 1;
			font-weight: bold;
			align-items: center;
			justify-content: center;
		}

		.has-text-align-right>blockquote::before {
			justify-content: flex-start;
		}

		.has-text-align-left>blockquote::before {
			justify-content: flex-end;
		}

		figure.wp-block-pullquote.is-style-solid-color blockquote {
			max-width: 100%;
			text-align: inherit;
		}

		:root {
			--wp--custom--ast-default-block-top-padding: 3em;
			--wp--custom--ast-default-block-right-padding: 3em;
			--wp--custom--ast-default-block-bottom-padding: 3em;
			--wp--custom--ast-default-block-left-padding: 3em;
			--wp--custom--ast-container-width: 1200px;
			--wp--custom--ast-content-width-size: 1200px;
			--wp--custom--ast-wide-width-size: calc(1200px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));
		}

		.ast-narrow-container {
			--wp--custom--ast-content-width-size: 750px;
			--wp--custom--ast-wide-width-size: 750px;
		}

		@media(max-width: 921px) {
			:root {
				--wp--custom--ast-default-block-top-padding: 3em;
				--wp--custom--ast-default-block-right-padding: 2em;
				--wp--custom--ast-default-block-bottom-padding: 3em;
				--wp--custom--ast-default-block-left-padding: 2em;
			}
		}

		@media(max-width: 544px) {
			:root {
				--wp--custom--ast-default-block-top-padding: 3em;
				--wp--custom--ast-default-block-right-padding: 1.5em;
				--wp--custom--ast-default-block-bottom-padding: 3em;
				--wp--custom--ast-default-block-left-padding: 1.5em;
			}
		}

		.entry-content>.wp-block-group,
		.entry-content>.wp-block-cover,
		.entry-content>.wp-block-columns {
			padding-top: var(--wp--custom--ast-default-block-top-padding);
			padding-right: var(--wp--custom--ast-default-block-right-padding);
			padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);
			padding-left: var(--wp--custom--ast-default-block-left-padding);
		}

		.ast-plain-container.ast-no-sidebar .entry-content>.alignfull,
		.ast-page-builder-template .ast-no-sidebar .entry-content>.alignfull {
			margin-left: calc(-50vw + 50%);
			margin-right: calc(-50vw + 50%);
			max-width: 100vw;
			width: 100vw;
		}

		.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,
		.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,
		.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,
		.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,
		.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,
		.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,
		.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,
		.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,
		.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,
		.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,
		.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,
		.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {
			margin-left: auto;
			margin-right: auto;
			width: 100%;
		}

		[data-ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {
			height: 0;
		}

		[data-ast-blocks-layout] .wp-block-separator {
			margin: 20px auto;
		}

		[data-ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
			max-width: 100px;
		}

		[data-ast-blocks-layout] .wp-block-separator.has-background {
			padding: 0;
		}

		.entry-content[data-ast-blocks-layout]>* {
			max-width: var(--wp--custom--ast-content-width-size);
			margin-left: auto;
			margin-right: auto;
		}

		.entry-content[data-ast-blocks-layout]>.alignwide {
			max-width: var(--wp--custom--ast-wide-width-size);
		}

		.entry-content[data-ast-blocks-layout] .alignfull {
			max-width: none;
		}

		.entry-content .wp-block-columns {
			margin-bottom: 0;
		}

		blockquote {
			margin: 1.5em;
			border-color: rgba(0, 0, 0, 0.05);
		}

		.wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {
			border-left: 5px solid rgba(0, 0, 0, 0.05);
		}

		.has-text-align-right>blockquote,
		blockquote.has-text-align-right {
			border-right: 5px solid rgba(0, 0, 0, 0.05);
		}

		.has-text-align-left>blockquote,
		blockquote.has-text-align-left {
			border-left: 5px solid rgba(0, 0, 0, 0.05);
		}

		.wp-block-site-tagline,
		.wp-block-latest-posts .read-more {
			margin-top: 15px;
		}

		.wp-block-loginout p label {
			display: block;
		}

		.wp-block-loginout p:not(.login-remember):not(.login-submit) input {
			width: 100%;
		}

		.wp-block-loginout input:focus {
			border-color: transparent;
		}

		.wp-block-loginout input:focus {
			outline: thin dotted;
		}

		.entry-content .wp-block-media-text .wp-block-media-text__content {
			padding: 0 0 0 8%;
		}

		.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
			padding: 0 8% 0 0;
		}

		.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
			padding: 8%;
		}

		.entry-content .wp-block-cover:not([class*="background-color"]):not(.has-text-color.has-link-color) .wp-block-cover__inner-container,
		.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-image-text,
		.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-text,
		.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover__inner-container,
		.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-image-text,
		.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-text {
			color: var(--ast-global-color-primary, var(--ast-global-color-5));
		}

		.wp-block-loginout .login-remember input {
			width: 1.1rem;
			height: 1.1rem;
			margin: 0 5px 4px 0;
			vertical-align: middle;
		}

		.wp-block-latest-posts>li>*:first-child,
		.wp-block-latest-posts:not(.is-grid)>li:first-child {
			margin-top: 0;
		}

		.entry-content>.wp-block-buttons,
		.entry-content>.wp-block-uagb-buttons {
			margin-bottom: 1.5em;
		}

		.wp-block-search__inside-wrapper .wp-block-search__input {
			padding: 0 10px;
			color: var(--ast-global-color-3);
			background: var(--ast-global-color-primary, var(--ast-global-color-5));
			border-color: var(--ast-border-color);
		}

		.wp-block-latest-posts .read-more {
			margin-bottom: 1.5em;
		}

		.wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {
			padding-top: 5px;
			padding-bottom: 5px;
		}

		.wp-block-latest-posts .wp-block-latest-posts__post-date,
		.wp-block-latest-posts .wp-block-latest-posts__post-author {
			font-size: 1rem;
		}

		.wp-block-latest-posts>li>*,
		.wp-block-latest-posts:not(.is-grid)>li {
			margin-top: 12px;
			margin-bottom: 12px;
		}

		.ast-page-builder-template .entry-content[data-ast-blocks-layout]>*,
		.ast-page-builder-template .entry-content[data-ast-blocks-layout]>.alignfull:not(.wp-block-group):not(.uagb-is-root-container)>* {
			max-width: none;
		}

		.ast-page-builder-template .entry-content[data-ast-blocks-layout]>.alignwide:not(.uagb-is-root-container)>* {
			max-width: var(--wp--custom--ast-wide-width-size);
		}

		.ast-page-builder-template .entry-content[data-ast-blocks-layout]>.inherit-container-width>*,
		.ast-page-builder-template .entry-content[data-ast-blocks-layout]>*:not(.wp-block-group):not(.uagb-is-root-container)>*,
		.entry-content[data-ast-blocks-layout]>.wp-block-cover .wp-block-cover__inner-container {
			max-width: none;
			margin-left: auto;
			margin-right: auto;
		}

		.entry-content[data-ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {
			width: auto;
		}

		@media(max-width: 1200px) {

			.ast-separate-container .entry-content>.alignfull,
			.ast-separate-container .entry-content[data-ast-blocks-layout]>.alignwide,
			.ast-plain-container .entry-content[data-ast-blocks-layout]>.alignwide,
			.ast-plain-container .entry-content .alignfull {
				margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
				margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
			}
		}

		@media(min-width: 1201px) {
			.ast-separate-container .entry-content>.alignfull {
				margin-left: calc(-1 * var(--ast-container-default-xlg-padding));
				margin-right: calc(-1 * var(--ast-container-default-xlg-padding));
			}

			.ast-separate-container .entry-content[data-ast-blocks-layout]>.alignwide,
			.ast-plain-container .entry-content[data-ast-blocks-layout]>.alignwide {
				margin-left: auto;
				margin-right: auto;
			}
		}

		@media(min-width: 921px) {

			.ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)),
			.ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)) {
				max-width: calc(var(--wp--custom--ast-content-width-size) + 80px);
			}

			.ast-plain-container.ast-right-sidebar .entry-content[data-ast-blocks-layout] .alignfull,
			.ast-plain-container.ast-left-sidebar .entry-content[data-ast-blocks-layout] .alignfull {
				margin-left: -60px;
				margin-right: -60px;
			}
		}

		@media(min-width: 544px) {
			.entry-content>.alignleft {
				margin-right: 20px;
			}

			.entry-content>.alignright {
				margin-left: 20px;
			}
		}

		@media (max-width:544px) {
			.wp-block-columns .wp-block-column:not(:last-child) {
				margin-bottom: 20px;
			}

			.wp-block-latest-posts {
				margin: 0;
			}
		}

		@media(max-width: 600px) {

			.entry-content .wp-block-media-text .wp-block-media-text__content,
			.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
				padding: 8% 0 0;
			}

			.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
				padding: 8%;
			}
		}

		.ast-page-builder-template .entry-header {
			padding-left: 0;
		}

		.ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {
			max-width: 100%;
			margin-left: auto;
			margin-right: auto;
		}

		.entry-content ul,
		.entry-content ol {
			padding: revert;
			margin: revert;
			padding-left: 20px;
		}

		:root .has-ast-global-color-0-color {
			color: var(--ast-global-color-0);
		}

		:root .has-ast-global-color-0-background-color {
			background-color: var(--ast-global-color-0);
		}

		:root .wp-block-button .has-ast-global-color-0-color {
			color: var(--ast-global-color-0);
		}

		:root .wp-block-button .has-ast-global-color-0-background-color {
			background-color: var(--ast-global-color-0);
		}

		:root .has-ast-global-color-1-color {
			color: var(--ast-global-color-1);
		}

		:root .has-ast-global-color-1-background-color {
			background-color: var(--ast-global-color-1);
		}

		:root .wp-block-button .has-ast-global-color-1-color {
			color: var(--ast-global-color-1);
		}

		:root .wp-block-button .has-ast-global-color-1-background-color {
			background-color: var(--ast-global-color-1);
		}

		:root .has-ast-global-color-2-color {
			color: var(--ast-global-color-2);
		}

		:root .has-ast-global-color-2-background-color {
			background-color: var(--ast-global-color-2);
		}

		:root .wp-block-button .has-ast-global-color-2-color {
			color: var(--ast-global-color-2);
		}

		:root .wp-block-button .has-ast-global-color-2-background-color {
			background-color: var(--ast-global-color-2);
		}

		:root .has-ast-global-color-3-color {
			color: var(--ast-global-color-3);
		}

		:root .has-ast-global-color-3-background-color {
			background-color: var(--ast-global-color-3);
		}

		:root .wp-block-button .has-ast-global-color-3-color {
			color: var(--ast-global-color-3);
		}

		:root .wp-block-button .has-ast-global-color-3-background-color {
			background-color: var(--ast-global-color-3);
		}

		:root .has-ast-global-color-4-color {
			color: var(--ast-global-color-4);
		}

		:root .has-ast-global-color-4-background-color {
			background-color: var(--ast-global-color-4);
		}

		:root .wp-block-button .has-ast-global-color-4-color {
			color: var(--ast-global-color-4);
		}

		:root .wp-block-button .has-ast-global-color-4-background-color {
			background-color: var(--ast-global-color-4);
		}

		:root .has-ast-global-color-5-color {
			color: var(--ast-global-color-5);
		}

		:root .has-ast-global-color-5-background-color {
			background-color: var(--ast-global-color-5);
		}

		:root .wp-block-button .has-ast-global-color-5-color {
			color: var(--ast-global-color-5);
		}

		:root .wp-block-button .has-ast-global-color-5-background-color {
			background-color: var(--ast-global-color-5);
		}

		:root .has-ast-global-color-6-color {
			color: var(--ast-global-color-6);
		}

		:root .has-ast-global-color-6-background-color {
			background-color: var(--ast-global-color-6);
		}

		:root .wp-block-button .has-ast-global-color-6-color {
			color: var(--ast-global-color-6);
		}

		:root .wp-block-button .has-ast-global-color-6-background-color {
			background-color: var(--ast-global-color-6);
		}

		:root .has-ast-global-color-7-color {
			color: var(--ast-global-color-7);
		}

		:root .has-ast-global-color-7-background-color {
			background-color: var(--ast-global-color-7);
		}

		:root .wp-block-button .has-ast-global-color-7-color {
			color: var(--ast-global-color-7);
		}

		:root .wp-block-button .has-ast-global-color-7-background-color {
			background-color: var(--ast-global-color-7);
		}

		:root .has-ast-global-color-8-color {
			color: var(--ast-global-color-8);
		}

		:root .has-ast-global-color-8-background-color {
			background-color: var(--ast-global-color-8);
		}

		:root .wp-block-button .has-ast-global-color-8-color {
			color: var(--ast-global-color-8);
		}

		:root .wp-block-button .has-ast-global-color-8-background-color {
			background-color: var(--ast-global-color-8);
		}

		:root {
			--ast-global-color-0: #cbff54;
			--ast-global-color-1: #b4f625;
			--ast-global-color-2: #063231;
			--ast-global-color-3: #495b55;
			--ast-global-color-4: #f6f7f7;
			--ast-global-color-5: #ffffff;
			--ast-global-color-6: #e0e7e3;
			--ast-global-color-7: #D1D5DB;
			--ast-global-color-8: #033231;
		}

		:root {
			--ast-border-color: var(--ast-global-color-7);
		}

		.ast-single-entry-banner {
			-js-display: flex;
			display: flex;
			flex-direction: column;
			justify-content: center;
			text-align: center;
			position: relative;
			background: var(--ast-title-layout-bg);
		}

		.ast-single-entry-banner[data-banner-layout="layout-1"] {
			max-width: 1200px;
			background: inherit;
			padding: 20px 0;
		}

		.ast-single-entry-banner[data-banner-width-type="custom"] {
			margin: 0 auto;
			width: 100%;
		}

		.ast-single-entry-banner+.site-content .entry-header {
			margin-bottom: 0;
		}

		.site .ast-author-avatar {
			--ast-author-avatar-size: ;
		}

		a.ast-underline-text {
			text-decoration: underline;
		}

		.ast-container>.ast-terms-link {
			position: relative;
			display: block;
		}

		a.ast-button.ast-badge-tax {
			padding: 4px 8px;
			border-radius: 3px;
			font-size: inherit;
		}

		header.entry-header:not(.related-entry-header) .entry-title {
			font-weight: 600;
			font-size: 32px;
			font-size: 2rem;
		}

		header.entry-header:not(.related-entry-header)>*:not(:last-child) {
			margin-bottom: 10px;
		}

		header.entry-header:not(.related-entry-header) .post-thumb-img-content {
			text-align: center;
		}

		header.entry-header:not(.related-entry-header) .post-thumb img,
		.ast-single-post-featured-section.post-thumb img {
			aspect-ratio: 16/9;
			width: 100%;
			height: 100%;
		}

		.ast-archive-entry-banner {
			-js-display: flex;
			display: flex;
			flex-direction: column;
			justify-content: center;
			text-align: center;
			position: relative;
			background: var(--ast-title-layout-bg);
		}

		.ast-archive-entry-banner[data-banner-width-type="custom"] {
			margin: 0 auto;
			width: 100%;
		}

		.ast-archive-entry-banner[data-banner-layout="layout-1"] {
			background: inherit;
			padding: 20px 0;
			text-align: left;
		}

		body.archive .ast-archive-description {
			max-width: 1200px;
			width: 100%;
			text-align: left;
			padding-top: 3em;
			padding-right: 3em;
			padding-bottom: 3em;
			padding-left: 3em;
		}

		body.archive .ast-archive-description .ast-archive-title,
		body.archive .ast-archive-description .ast-archive-title * {
			font-weight: 600;
			font-size: 32px;
			font-size: 2rem;
		}

		body.archive .ast-archive-description>*:not(:last-child) {
			margin-bottom: 10px;
		}

		@media (max-width:921px) {
			body.archive .ast-archive-description {
				text-align: left;
			}
		}

		@media (max-width:544px) {
			body.archive .ast-archive-description {
				text-align: left;
			}
		}

		.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
			width: 150px;
		}

		.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
			max-width: 150px;
			width: 150px;
		}

		@media (max-width:921px) {
			.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
				width: 120px;
			}

			.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
				max-width: 120px;
				width: 120px;
			}
		}

		@media (max-width:543px) {
			.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
				width: 100px;
			}

			.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
				max-width: 100px;
				width: 100px;
			}
		}

		@media (min-width:921px) {
			.ast-theme-transparent-header #masthead {
				position: absolute;
				left: 0;
				right: 0;
			}

			.ast-theme-transparent-header .main-header-bar,
			.ast-theme-transparent-header.ast-header-break-point .main-header-bar {
				background: none;
			}

			body.elementor-editor-active.ast-theme-transparent-header #masthead,
			.fl-builder-edit .ast-theme-transparent-header #masthead,
			body.vc_editor.ast-theme-transparent-header #masthead,
			body.brz-ed.ast-theme-transparent-header #masthead {
				z-index: 0;
			}

			.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
				display: none;
			}

			.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
				display: inline-block;
			}

			.ast-theme-transparent-header .ast-above-header,
			.ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
				background-image: none;
				background-color: transparent;
			}

			.ast-theme-transparent-header .ast-below-header,
			.ast-theme-transparent-header .ast-below-header.ast-below-header-bar {
				background-image: none;
				background-color: transparent;
			}
		}

		.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu .menu-link,
		.ast-theme-transparent-header .main-header-menu .menu-item .sub-menu .menu-link {
			background-color: transparent;
		}

		@media (max-width:921px) {
			.ast-theme-transparent-header #masthead {
				position: absolute;
				left: 0;
				right: 0;
			}

			.ast-theme-transparent-header .main-header-bar,
			.ast-theme-transparent-header.ast-header-break-point .main-header-bar {
				background: none;
			}

			body.elementor-editor-active.ast-theme-transparent-header #masthead,
			.fl-builder-edit .ast-theme-transparent-header #masthead,
			body.vc_editor.ast-theme-transparent-header #masthead,
			body.brz-ed.ast-theme-transparent-header #masthead {
				z-index: 0;
			}

			.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
				display: none;
			}

			.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
				display: inline-block;
			}

			.ast-theme-transparent-header .ast-above-header,
			.ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
				background-image: none;
				background-color: transparent;
			}

			.ast-theme-transparent-header .ast-below-header,
			.ast-theme-transparent-header .ast-below-header.ast-below-header-bar {
				background-image: none;
				background-color: transparent;
			}
		}

		.ast-theme-transparent-header #ast-desktop-header>.ast-main-header-wrap>.main-header-bar,
		.ast-theme-transparent-header.ast-header-break-point #ast-mobile-header>.ast-main-header-wrap>.main-header-bar {
			border-bottom-width: 0px;
			border-bottom-style: solid;
		}

		.ast-breadcrumbs .trail-browse,
		.ast-breadcrumbs .trail-items,
		.ast-breadcrumbs .trail-items li {
			display: inline-block;
			margin: 0;
			padding: 0;
			border: none;
			background: inherit;
			text-indent: 0;
			text-decoration: none;
		}

		.ast-breadcrumbs .trail-browse {
			font-size: inherit;
			font-style: inherit;
			font-weight: inherit;
			color: inherit;
		}

		.ast-breadcrumbs .trail-items {
			list-style: none;
		}

		.trail-items li::after {
			padding: 0 0.3em;
			content: "\00bb";
		}

		.trail-items li:last-of-type::after {
			display: none;
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		.entry-content :where(h1, h2, h3, h4, h5, h6) {
			color: var(--ast-global-color-2);
		}

		.entry-title a {
			color: var(--ast-global-color-2);
		}

		@media (max-width:921px) {

			.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row>*:first-child,
			.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row>*:last-child {
				grid-column: 1 / -1;
			}
		}

		@media (max-width:544px) {

			.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row>*:first-child,
			.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row>*:last-child {
				grid-column: 1 / -1;
			}
		}

		@media (max-width:544px) {
			.ast-builder-layout-element .ast-site-identity {
				margin-top: 24px;
				margin-bottom: 24px;
				margin-left: 24px;
				margin-right: 24px;
			}
		}

		.ast-builder-layout-element[data-section="title_tagline"] {
			display: flex;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
				display: flex;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
				display: flex;
			}
		}

		[data-section*="section-hb-button-"] .menu-link {
			display: none;
		}

		.ast-header-button-1 .ast-custom-button {
			border-top-left-radius: 40px;
			border-top-right-radius: 40px;
			border-bottom-right-radius: 40px;
			border-bottom-left-radius: 40px;
		}

		.ast-header-button-1[data-section*="section-hb-button-"] .ast-builder-button-wrap .ast-custom-button {
			padding-top: 15px;
			padding-bottom: 15px;
			padding-left: 30px;
			padding-right: 30px;
		}

		.ast-header-button-1[data-section="section-hb-button-1"] {
			display: flex;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"] {
				display: flex;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-header-button-1[data-section="section-hb-button-1"] {
				display: flex;
			}
		}

		.ast-builder-menu-1 {
			font-family: inherit;
			font-weight: inherit;
		}

		.ast-builder-menu-1 .menu-item>.menu-link {
			color: #ffffff;
		}

		.ast-builder-menu-1 .menu-item>.ast-menu-toggle {
			color: #ffffff;
		}

		.ast-builder-menu-1 .menu-item:hover>.menu-link,
		.ast-builder-menu-1 .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-1 .menu-item:hover>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-1 .menu-item.current-menu-item>.menu-link,
		.ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
		.ast-builder-menu-1 .current-menu-ancestor>.menu-link {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-1 .menu-item.current-menu-item>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-1 .sub-menu,
		.ast-builder-menu-1 .inline-on-mobile .sub-menu {
			border-top-width: 2px;
			border-bottom-width: 0px;
			border-right-width: 0px;
			border-left-width: 0px;
			border-color: #ffffff;
			border-style: solid;
		}

		.ast-builder-menu-1 .sub-menu .sub-menu {
			top: -2px;
		}

		.ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
		.ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
			margin-top: 0px;
		}

		.ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu:before,
		.ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper:before {
			height: calc(0px + 2px + 5px);
		}

		.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link {
			border-style: none;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0;
			}

			.ast-builder-menu-1 .inline-on-mobile .menu-item.menu-item-has-children>.ast-menu-toggle {
				right: -15px;
			}

			.ast-builder-menu-1 .menu-item-has-children>.menu-link:after {
				content: unset;
			}

			.ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
			.ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
				margin-top: 0;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0;
			}

			.ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
			.ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
				margin-top: 0;
			}
		}

		.ast-builder-menu-1 {
			display: flex;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-builder-menu-1 {
				display: flex;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-builder-menu-1 {
				display: flex;
			}
		}

		.ast-desktop .ast-menu-hover-style-underline>.menu-item>.menu-link:before,
		.ast-desktop .ast-menu-hover-style-overline>.menu-item>.menu-link:before {
			content: "";
			position: absolute;
			width: 100%;
			right: 50%;
			height: 1px;
			background-color: transparent;
			transform: scale(0, 0) translate(-50%, 0);
			transition: transform .3s ease-in-out, color .0s ease-in-out;
		}

		.ast-desktop .ast-menu-hover-style-underline>.menu-item:hover>.menu-link:before,
		.ast-desktop .ast-menu-hover-style-overline>.menu-item:hover>.menu-link:before {
			width: calc(100% - 1.2em);
			background-color: currentColor;
			transform: scale(1, 1) translate(50%, 0);
		}

		.ast-desktop .ast-menu-hover-style-underline>.menu-item>.menu-link:before {
			bottom: 0;
		}

		.ast-desktop .ast-menu-hover-style-overline>.menu-item>.menu-link:before {
			top: 0;
		}

		.ast-desktop .ast-menu-hover-style-zoom>.menu-item>.menu-link:hover {
			transition: all .3s ease;
			transform: scale(1.2);
		}

		.footer-widget-area.widget-area.site-footer-focus-item {
			width: auto;
		}

		.ast-footer-row-inline .footer-widget-area.widget-area.site-footer-focus-item {
			width: 100%;
		}

		.elementor-widget-heading .elementor-heading-title {
			margin: 0;
		}

		.elementor-page .ast-menu-toggle {
			color: unset !important;
			background: unset !important;
		}

		.elementor-post.elementor-grid-item.hentry {
			margin-bottom: 0;
		}

		.woocommerce div.product .elementor-element.elementor-products-grid .related.products ul.products li.product,
		.elementor-element .elementor-wc-products .woocommerce[class*='columns-'] ul.products li.product {
			width: auto;
			margin: 0;
			float: none;
		}

		.elementor-toc__list-wrapper {
			margin: 0;
		}

		body .elementor hr {
			background-color: #ccc;
			margin: 0;
		}

		.ast-left-sidebar .elementor-section.elementor-section-stretched,
		.ast-right-sidebar .elementor-section.elementor-section-stretched {
			max-width: 100%;
			left: 0 !important;
		}

		.elementor-posts-container [CLASS*="ast-width-"] {
			width: 100%;
		}

		.elementor-template-full-width .ast-container {
			display: block;
		}

		.elementor-screen-only,
		.screen-reader-text,
		.screen-reader-text span,
		.ui-helper-hidden-accessible {
			top: 0 !important;
		}

		@media (max-width:544px) {
			.elementor-element .elementor-wc-products .woocommerce[class*="columns-"] ul.products li.product {
				width: auto;
				margin: 0;
			}

			.elementor-element .woocommerce .woocommerce-result-count {
				float: none;
			}
		}

		.ast-header-button-1 .ast-custom-button {
			box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0.1);
		}

		.ast-desktop .ast-mega-menu-enabled .ast-builder-menu-1 div:not(.astra-full-megamenu-wrapper) .sub-menu,
		.ast-builder-menu-1 .inline-on-mobile .sub-menu,
		.ast-desktop .ast-builder-menu-1 .astra-full-megamenu-wrapper,
		.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu {
			box-shadow: 0px 4px 10px -2px rgba(0, 0, 0, 0.1);
		}

		.ast-desktop .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
			max-width: 35%;
		}

		@media (max-width:921px) {
			.ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
				max-width: 90%;
			}
		}

		@media (max-width:544px) {
			.ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
				max-width: 90%;
			}
		}

		.ast-header-break-point .main-header-bar {
			border-bottom-width: 1px;
		}

		@media (min-width:922px) {
			.main-header-bar {
				border-bottom-width: 1px;
			}
		}

		.main-header-menu .menu-item,
		#astra-footer-menu .menu-item,
		.main-header-bar .ast-masthead-custom-menu-items {
			-js-display: flex;
			display: flex;
			-webkit-box-pack: center;
			-webkit-justify-content: center;
			-moz-box-pack: center;
			-ms-flex-pack: center;
			justify-content: center;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			-moz-box-orient: vertical;
			-moz-box-direction: normal;
			-ms-flex-direction: column;
			flex-direction: column;
		}

		.main-header-menu>.menu-item>.menu-link,
		#astra-footer-menu>.menu-item>.menu-link {
			height: 100%;
			-webkit-box-align: center;
			-webkit-align-items: center;
			-moz-box-align: center;
			-ms-flex-align: center;
			align-items: center;
			-js-display: flex;
			display: flex;
		}

		.ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg {
			top: .2em;
			margin-top: 0px;
			margin-left: 0px;
			width: .65em;
			transform: translate(0, -2px) rotateZ(270deg);
		}

		.ast-mobile-popup-content .ast-submenu-expanded>.ast-menu-toggle {
			transform: rotateX(180deg);
			overflow-y: auto;
		}

		@media (min-width:922px) {
			.ast-builder-menu .main-navigation>ul>li:last-child a {
				margin-right: 0;
			}
		}

		.ast-separate-container .ast-article-inner {
			background-color: var(--ast-global-color-4);
			background-image: none;
		}

		@media (max-width:921px) {
			.ast-separate-container .ast-article-inner {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		@media (max-width:544px) {
			.ast-separate-container .ast-article-inner {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		.ast-separate-container .ast-article-single:not(.ast-related-post),
		.ast-separate-container .error-404,
		.ast-separate-container .no-results,
		.single.ast-separate-container .site-main .ast-author-meta,
		.ast-separate-container .related-posts-title-wrapper,
		.ast-separate-container .comments-count-wrapper,
		.ast-box-layout.ast-plain-container .site-content,
		.ast-padded-layout.ast-plain-container .site-content,
		.ast-separate-container .ast-archive-description,
		.ast-separate-container .comments-area {
			background-color: var(--ast-global-color-4);
			background-image: none;
		}

		@media (max-width:921px) {

			.ast-separate-container .ast-article-single:not(.ast-related-post),
			.ast-separate-container .error-404,
			.ast-separate-container .no-results,
			.single.ast-separate-container .site-main .ast-author-meta,
			.ast-separate-container .related-posts-title-wrapper,
			.ast-separate-container .comments-count-wrapper,
			.ast-box-layout.ast-plain-container .site-content,
			.ast-padded-layout.ast-plain-container .site-content,
			.ast-separate-container .ast-archive-description {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		@media (max-width:544px) {

			.ast-separate-container .ast-article-single:not(.ast-related-post),
			.ast-separate-container .error-404,
			.ast-separate-container .no-results,
			.single.ast-separate-container .site-main .ast-author-meta,
			.ast-separate-container .related-posts-title-wrapper,
			.ast-separate-container .comments-count-wrapper,
			.ast-box-layout.ast-plain-container .site-content,
			.ast-padded-layout.ast-plain-container .site-content,
			.ast-separate-container .ast-archive-description {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		.ast-separate-container.ast-two-container #secondary .widget {
			background-color: var(--ast-global-color-4);
			background-image: none;
		}

		@media (max-width:921px) {
			.ast-separate-container.ast-two-container #secondary .widget {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		@media (max-width:544px) {
			.ast-separate-container.ast-two-container #secondary .widget {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		.ast-plain-container,
		.ast-page-builder-template {
			background-color: var(--ast-global-color-4);
			background-image: none;
		}

		@media (max-width:921px) {

			.ast-plain-container,
			.ast-page-builder-template {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		@media (max-width:544px) {

			.ast-plain-container,
			.ast-page-builder-template {
				background-color: var(--ast-global-color-4);
				background-image: none;
			}
		}

		#ast-scroll-top {
			display: none;
			position: fixed;
			text-align: center;
			cursor: pointer;
			z-index: 99;
			width: 2.1em;
			height: 2.1em;
			line-height: 2.1;
			color: #ffffff;
			border-radius: 2px;
			content: "";
			outline: inherit;
		}

		@media (min-width: 769px) {
			#ast-scroll-top {
				content: "769";
			}
		}

		#ast-scroll-top .ast-icon.icon-arrow svg {
			margin-left: 0px;
			vertical-align: middle;
			transform: translate(0, -20%) rotate(180deg);
			width: 1.6em;
		}

		.ast-scroll-to-top-right {
			right: 30px;
			bottom: 30px;
		}

		.ast-scroll-to-top-left {
			left: 30px;
			bottom: 30px;
		}

		#ast-scroll-top {
			background-color: var(--ast-global-color-2);
			font-size: 15px;
		}

		@media (max-width:921px) {
			#ast-scroll-top .ast-icon.icon-arrow svg {
				width: 1em;
			}
		}

		.ast-mobile-header-content>*,
		.ast-desktop-header-content>* {
			padding: 10px 0;
			height: auto;
		}

		.ast-mobile-header-content>*:first-child,
		.ast-desktop-header-content>*:first-child {
			padding-top: 10px;
		}

		.ast-mobile-header-content>.ast-builder-menu,
		.ast-desktop-header-content>.ast-builder-menu {
			padding-top: 0;
		}

		.ast-mobile-header-content>*:last-child,
		.ast-desktop-header-content>*:last-child {
			padding-bottom: 0;
		}

		.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,
		.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {
			width: 100%;
		}

		.ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded>.ast-menu-toggle::before {
			transform: rotateX(180deg);
		}

		#ast-desktop-header .ast-desktop-header-content,
		.ast-mobile-header-content .ast-search-icon,
		.ast-desktop-header-content .ast-search-icon,
		.ast-mobile-header-wrap .ast-mobile-header-content,
		.ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,
		.ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {
			display: none;
		}

		.ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,
		.ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {
			display: block;
		}

		.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item>.sub-menu,
		.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item .menu-item>.sub-menu,
		.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item>.sub-menu,
		.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item .menu-item>.sub-menu,
		.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item>.sub-menu,
		.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item .menu-item>.sub-menu {
			opacity: 1;
			visibility: visible;
		}

		.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {
			width: unset;
			margin: unset;
		}

		.ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle,
		.ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle {
			left: calc(20px - 0.907em);
			right: auto;
		}

		.ast-mobile-header-content .ast-search-menu-icon,
		.ast-mobile-header-content .ast-search-menu-icon.slide-search,
		.ast-desktop-header-content .ast-search-menu-icon,
		.ast-desktop-header-content .ast-search-menu-icon.slide-search {
			width: 100%;
			position: relative;
			display: block;
			right: auto;
			transform: none;
		}

		.ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,
		.ast-mobile-header-content .ast-search-menu-icon .search-form,
		.ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,
		.ast-desktop-header-content .ast-search-menu-icon .search-form {
			right: 0;
			visibility: visible;
			opacity: 1;
			position: relative;
			top: auto;
			transform: none;
			padding: 0;
			display: block;
			overflow: hidden;
		}

		.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,
		.ast-mobile-header-content .ast-search-menu-icon .search-field,
		.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,
		.ast-desktop-header-content .ast-search-menu-icon .search-field {
			width: 100%;
			padding-right: 5.5em;
		}

		.ast-mobile-header-content .ast-search-menu-icon .search-submit,
		.ast-desktop-header-content .ast-search-menu-icon .search-submit {
			display: block;
			position: absolute;
			height: 100%;
			top: 0;
			right: 0;
			padding: 0 1em;
			border-radius: 0;
		}

		.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {
			padding-left: 30px;
		}

		.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {
			padding-left: 40px;
		}

		.ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
			background-color: #ffffff;
			;
		}

		.ast-mobile-header-wrap .ast-mobile-header-content,
		.ast-desktop-header-content {
			background-color: #ffffff;
			;
		}

		.ast-mobile-popup-content>*,
		.ast-mobile-header-content>*,
		.ast-desktop-popup-content>*,
		.ast-desktop-header-content>* {
			padding-top: 0px;
			padding-bottom: 0px;
		}

		.content-align-flex-start .ast-builder-layout-element {
			justify-content: flex-start;
		}

		.content-align-flex-start .main-header-menu {
			text-align: left;
		}

		.ast-desktop-header-content,
		.ast-mobile-header-content {
			position: absolute;
			width: 100%;
		}

		.ast-mobile-popup-drawer.active .menu-toggle-close {
			color: #3a3a3a;
		}

		.ast-mobile-header-wrap .ast-primary-header-bar,
		.ast-primary-header-bar .site-primary-header-wrap {
			min-height: 80px;
		}

		.ast-desktop .ast-primary-header-bar .main-header-menu>.menu-item {
			line-height: 80px;
		}

		.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-primary-header-bar,
		.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-below-header-bar,
		.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-above-header-bar {
			padding-left: 20px;
			padding-right: 20px;
		}

		.ast-header-break-point .ast-primary-header-bar {
			border-bottom-width: 1px;
			border-bottom-color: var(--ast-global-color-subtle-background, --ast-global-color-7);
			border-bottom-style: solid;
		}

		@media (min-width:922px) {
			.ast-primary-header-bar {
				border-bottom-width: 1px;
				border-bottom-color: var(--ast-global-color-subtle-background, --ast-global-color-7);
				border-bottom-style: solid;
			}
		}

		.ast-primary-header-bar {
			background-color: var(--ast-global-color-primary, --ast-global-color-4);
			background-image: none;
		}

		@media (max-width:921px) {

			.ast-mobile-header-wrap .ast-primary-header-bar,
			.ast-primary-header-bar .site-primary-header-wrap {
				min-height: 70px;
			}
		}

		@media (max-width:544px) {

			.ast-mobile-header-wrap .ast-primary-header-bar,
			.ast-primary-header-bar .site-primary-header-wrap {
				min-height: 70px;
			}
		}

		@media (max-width:921px) {

			.ast-desktop .ast-primary-header-bar.main-header-bar,
			.ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar {
				padding-top: 0px;
				padding-left: 32px;
				padding-right: 32px;
			}
		}

		@media (max-width:544px) {

			.ast-desktop .ast-primary-header-bar.main-header-bar,
			.ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar {
				padding-top: 0px;
				padding-bottom: 0px;
				padding-left: 0px;
				padding-right: 0px;
				margin-top: 0px;
				margin-bottom: 0px;
				margin-left: 0px;
				margin-right: 0px;
			}
		}

		.ast-primary-header-bar {
			display: block;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-primary-header-bar {
				display: grid;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-primary-header-bar {
				display: grid;
			}
		}

		[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
			color: var(--ast-global-color-0);
			border: none;
			background: transparent;
		}

		[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg {
			width: 24px;
			height: 24px;
			fill: var(--ast-global-color-0);
		}

		[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu {
			color: var(--ast-global-color-0);
		}

		@media (max-width:544px) {
			[data-section="section-header-mobile-trigger"] .ast-button-wrap .menu-toggle {
				margin-top: 24px;
				margin-bottom: 24px;
				margin-left: 24px;
				margin-right: 24px;
			}
		}

		.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
			color: var(--ast-global-color-3);
		}

		.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.ast-menu-toggle {
			color: var(--ast-global-color-3);
		}

		.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover>.menu-link,
		.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-mobile .menu-item:hover>.menu-link,
		.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-mobile .main-navigation .menu-item:hover>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.menu-link,
		.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
		.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.menu-link,
		.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.ast-menu-toggle {
			color: var(--ast-global-color-1);
		}

		.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
			top: 0;
		}

		.ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
			content: unset;
		}

		.ast-hfb-header .ast-builder-menu-mobile .main-header-menu,
		.ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,
		.ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link {
			border-style: none;
		}

		.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
			top: 0;
		}

		@media (max-width:921px) {
			.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
				color: #ffffff;
				padding-top: 0px;
				padding-left: 32px;
				padding-right: 32px;
			}

			.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.ast-menu-toggle {
				color: #ffffff;
			}

			.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item:hover>.menu-link,
			.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
				color: var(--ast-global-color-1);
			}

			.ast-builder-menu-mobile .main-navigation .menu-item:hover>.ast-menu-toggle {
				color: var(--ast-global-color-1);
			}

			.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.menu-link,
			.ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
			.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.menu-link,
			.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.ast-menu-toggle {
				color: var(--ast-global-color-1);
				background: rgba(255, 255, 255, 0.31);
			}

			.ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.ast-menu-toggle {
				color: var(--ast-global-color-1);
			}

			.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0px;
				right: calc(32px - 0.907em);
			}

			.ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
				content: unset;
			}

			.ast-builder-menu-mobile .main-navigation .main-header-menu,
			.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-link,
			.ast-builder-menu-mobile .main-navigation .main-header-menu .sub-menu {
				background-color: var(--ast-global-color-2);
				background-image: none;
			}
		}

		@media (max-width:544px) {
			.ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
				padding-top: 1px;
				padding-bottom: 1px;
				padding-left: 24px;
				padding-right: 24px;
			}

			.ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 1px;
				right: calc(24px - 0.907em);
			}
		}

		.ast-builder-menu-mobile .main-navigation {
			display: block;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-builder-menu-mobile .main-navigation {
				display: block;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-builder-menu-mobile .main-navigation {
				display: block;
			}
		}

		:root {
			--e-global-color-astglobalcolor0: #cbff54;
			--e-global-color-astglobalcolor1: #b4f625;
			--e-global-color-astglobalcolor2: #063231;
			--e-global-color-astglobalcolor3: #495b55;
			--e-global-color-astglobalcolor4: #f6f7f7;
			--e-global-color-astglobalcolor5: #ffffff;
			--e-global-color-astglobalcolor6: #e0e7e3;
			--e-global-color-astglobalcolor7: #D1D5DB;
			--e-global-color-astglobalcolor8: #033231;
		}

		.ast-desktop .astra-menu-animation-slide-up>.menu-item>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item>.sub-menu .sub-menu {
			opacity: 0;
			visibility: hidden;
			transform: translateY(.5em);
			transition: visibility .2s ease, transform .2s ease
		}

		.ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item .menu-item:hover>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-up>.menu-item:hover>.sub-menu {
			opacity: 1;
			visibility: visible;
			transform: translateY(0);
			transition: opacity .2s ease, visibility .2s ease, transform .2s ease
		}

		.ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-up>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
			-js-display: flex;
			display: flex
		}

		.ast-desktop .astra-menu-animation-slide-down>.menu-item>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item>.sub-menu .sub-menu {
			opacity: 0;
			visibility: hidden;
			transform: translateY(-.5em);
			transition: visibility .2s ease, transform .2s ease
		}

		.ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item .menu-item:hover>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-down>.menu-item:hover>.sub-menu {
			opacity: 1;
			visibility: visible;
			transform: translateY(0);
			transition: opacity .2s ease, visibility .2s ease, transform .2s ease
		}

		.ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-slide-down>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
			-js-display: flex;
			display: flex
		}

		.ast-desktop .astra-menu-animation-fade>.menu-item>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu,
		.ast-desktop .astra-menu-animation-fade>.menu-item>.sub-menu .sub-menu {
			opacity: 0;
			visibility: hidden;
			transition: opacity ease-in-out .3s
		}

		.ast-desktop .astra-menu-animation-fade>.menu-item .menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-fade>.menu-item .menu-item:hover>.sub-menu,
		.ast-desktop .astra-menu-animation-fade>.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-fade>.menu-item.focus>.sub-menu,
		.ast-desktop .astra-menu-animation-fade>.menu-item:hover>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-fade>.menu-item:hover>.sub-menu {
			opacity: 1;
			visibility: visible;
			transition: opacity ease-in-out .3s
		}

		.ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item.focus>.astra-full-megamenu-wrapper,
		.ast-desktop .astra-menu-animation-fade>.full-width-mega.menu-item:hover>.astra-full-megamenu-wrapper {
			-js-display: flex;
			display: flex
		}

		.ast-desktop .menu-item.ast-menu-hover>.sub-menu.toggled-on {
			opacity: 1;
			visibility: visible
		}
	</style>

	<link rel='stylesheet' id='hfe-widgets-style-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.4.9' media='all' />
	<style id='wp-emoji-styles-inline-css'>
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 0.07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<style id='global-styles-inline-css'>
		:root {
			--wp--preset--aspect-ratio--square: 1;
			--wp--preset--aspect-ratio--4-3: 4/3;
			--wp--preset--aspect-ratio--3-4: 3/4;
			--wp--preset--aspect-ratio--3-2: 3/2;
			--wp--preset--aspect-ratio--2-3: 2/3;
			--wp--preset--aspect-ratio--16-9: 16/9;
			--wp--preset--aspect-ratio--9-16: 9/16;
			--wp--preset--color--black: #000000;
			--wp--preset--color--cyan-bluish-gray: #abb8c3;
			--wp--preset--color--white: #ffffff;
			--wp--preset--color--pale-pink: #f78da7;
			--wp--preset--color--vivid-red: #cf2e2e;
			--wp--preset--color--luminous-vivid-orange: #ff6900;
			--wp--preset--color--luminous-vivid-amber: #fcb900;
			--wp--preset--color--light-green-cyan: #7bdcb5;
			--wp--preset--color--vivid-green-cyan: #00d084;
			--wp--preset--color--pale-cyan-blue: #8ed1fc;
			--wp--preset--color--vivid-cyan-blue: #0693e3;
			--wp--preset--color--vivid-purple: #9b51e0;
			--wp--preset--color--ast-global-color-0: var(--ast-global-color-0);
			--wp--preset--color--ast-global-color-1: var(--ast-global-color-1);
			--wp--preset--color--ast-global-color-2: var(--ast-global-color-2);
			--wp--preset--color--ast-global-color-3: var(--ast-global-color-3);
			--wp--preset--color--ast-global-color-4: var(--ast-global-color-4);
			--wp--preset--color--ast-global-color-5: var(--ast-global-color-5);
			--wp--preset--color--ast-global-color-6: var(--ast-global-color-6);
			--wp--preset--color--ast-global-color-7: var(--ast-global-color-7);
			--wp--preset--color--ast-global-color-8: var(--ast-global-color-8);
			--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
			--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
			--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
			--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
			--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
			--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
			--wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
			--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
			--wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
			--wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
			--wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
			--wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
			--wp--preset--font-size--small: 13px;
			--wp--preset--font-size--medium: 20px;
			--wp--preset--font-size--large: 36px;
			--wp--preset--font-size--x-large: 42px;
			--wp--preset--spacing--20: 0.44rem;
			--wp--preset--spacing--30: 0.67rem;
			--wp--preset--spacing--40: 1rem;
			--wp--preset--spacing--50: 1.5rem;
			--wp--preset--spacing--60: 2.25rem;
			--wp--preset--spacing--70: 3.38rem;
			--wp--preset--spacing--80: 5.06rem;
			--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
			--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
			--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
		}

		:root {
			--wp--style--global--content-size: var(--wp--custom--ast-content-width-size);
			--wp--style--global--wide-size: var(--wp--custom--ast-wide-width-size);
		}

		:where(body) {
			margin: 0;
		}

		.wp-site-blocks>.alignleft {
			float: left;
			margin-right: 2em;
		}

		.wp-site-blocks>.alignright {
			float: right;
			margin-left: 2em;
		}

		.wp-site-blocks>.aligncenter {
			justify-content: center;
			margin-left: auto;
			margin-right: auto;
		}

		:where(.wp-site-blocks)>* {
			margin-block-start: 24px;
			margin-block-end: 0;
		}

		:where(.wp-site-blocks)> :first-child {
			margin-block-start: 0;
		}

		:where(.wp-site-blocks)> :last-child {
			margin-block-end: 0;
		}

		:root {
			--wp--style--block-gap: 24px;
		}

		:root :where(.is-layout-flow)> :first-child {
			margin-block-start: 0;
		}

		:root :where(.is-layout-flow)> :last-child {
			margin-block-end: 0;
		}

		:root :where(.is-layout-flow)>* {
			margin-block-start: 24px;
			margin-block-end: 0;
		}

		:root :where(.is-layout-constrained)> :first-child {
			margin-block-start: 0;
		}

		:root :where(.is-layout-constrained)> :last-child {
			margin-block-end: 0;
		}

		:root :where(.is-layout-constrained)>* {
			margin-block-start: 24px;
			margin-block-end: 0;
		}

		:root :where(.is-layout-flex) {
			gap: 24px;
		}

		:root :where(.is-layout-grid) {
			gap: 24px;
		}

		.is-layout-flow>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		.is-layout-flow>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		.is-layout-flow>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		.is-layout-constrained>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		.is-layout-constrained>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		.is-layout-constrained>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		.is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
			max-width: var(--wp--style--global--content-size);
			margin-left: auto !important;
			margin-right: auto !important;
		}

		.is-layout-constrained>.alignwide {
			max-width: var(--wp--style--global--wide-size);
		}

		body .is-layout-flex {
			display: flex;
		}

		.is-layout-flex {
			flex-wrap: wrap;
			align-items: center;
		}

		.is-layout-flex> :is(*, div) {
			margin: 0;
		}

		body .is-layout-grid {
			display: grid;
		}

		.is-layout-grid> :is(*, div) {
			margin: 0;
		}

		body {
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}

		a:where(:not(.wp-element-button)) {
			text-decoration: none;
		}

		:root :where(.wp-element-button, .wp-block-button__link) {
			background-color: #32373c;
			border-width: 0;
			color: #fff;
			font-family: inherit;
			font-size: inherit;
			line-height: inherit;
			padding: calc(0.667em + 2px) calc(1.333em + 2px);
			text-decoration: none;
		}

		.has-black-color {
			color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-color {
			color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-color {
			color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-color {
			color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-color {
			color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-color {
			color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-color {
			color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-color {
			color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-color {
			color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-color {
			color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-color {
			color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-color {
			color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-ast-global-color-0-color {
			color: var(--wp--preset--color--ast-global-color-0) !important;
		}

		.has-ast-global-color-1-color {
			color: var(--wp--preset--color--ast-global-color-1) !important;
		}

		.has-ast-global-color-2-color {
			color: var(--wp--preset--color--ast-global-color-2) !important;
		}

		.has-ast-global-color-3-color {
			color: var(--wp--preset--color--ast-global-color-3) !important;
		}

		.has-ast-global-color-4-color {
			color: var(--wp--preset--color--ast-global-color-4) !important;
		}

		.has-ast-global-color-5-color {
			color: var(--wp--preset--color--ast-global-color-5) !important;
		}

		.has-ast-global-color-6-color {
			color: var(--wp--preset--color--ast-global-color-6) !important;
		}

		.has-ast-global-color-7-color {
			color: var(--wp--preset--color--ast-global-color-7) !important;
		}

		.has-ast-global-color-8-color {
			color: var(--wp--preset--color--ast-global-color-8) !important;
		}

		.has-black-background-color {
			background-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-background-color {
			background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-background-color {
			background-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-background-color {
			background-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-background-color {
			background-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-background-color {
			background-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-background-color {
			background-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-background-color {
			background-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-background-color {
			background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-background-color {
			background-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-ast-global-color-0-background-color {
			background-color: var(--wp--preset--color--ast-global-color-0) !important;
		}

		.has-ast-global-color-1-background-color {
			background-color: var(--wp--preset--color--ast-global-color-1) !important;
		}

		.has-ast-global-color-2-background-color {
			background-color: var(--wp--preset--color--ast-global-color-2) !important;
		}

		.has-ast-global-color-3-background-color {
			background-color: var(--wp--preset--color--ast-global-color-3) !important;
		}

		.has-ast-global-color-4-background-color {
			background-color: var(--wp--preset--color--ast-global-color-4) !important;
		}

		.has-ast-global-color-5-background-color {
			background-color: var(--wp--preset--color--ast-global-color-5) !important;
		}

		.has-ast-global-color-6-background-color {
			background-color: var(--wp--preset--color--ast-global-color-6) !important;
		}

		.has-ast-global-color-7-background-color {
			background-color: var(--wp--preset--color--ast-global-color-7) !important;
		}

		.has-ast-global-color-8-background-color {
			background-color: var(--wp--preset--color--ast-global-color-8) !important;
		}

		.has-black-border-color {
			border-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-border-color {
			border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-border-color {
			border-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-border-color {
			border-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-border-color {
			border-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-border-color {
			border-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-border-color {
			border-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-border-color {
			border-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-border-color {
			border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-border-color {
			border-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-ast-global-color-0-border-color {
			border-color: var(--wp--preset--color--ast-global-color-0) !important;
		}

		.has-ast-global-color-1-border-color {
			border-color: var(--wp--preset--color--ast-global-color-1) !important;
		}

		.has-ast-global-color-2-border-color {
			border-color: var(--wp--preset--color--ast-global-color-2) !important;
		}

		.has-ast-global-color-3-border-color {
			border-color: var(--wp--preset--color--ast-global-color-3) !important;
		}

		.has-ast-global-color-4-border-color {
			border-color: var(--wp--preset--color--ast-global-color-4) !important;
		}

		.has-ast-global-color-5-border-color {
			border-color: var(--wp--preset--color--ast-global-color-5) !important;
		}

		.has-ast-global-color-6-border-color {
			border-color: var(--wp--preset--color--ast-global-color-6) !important;
		}

		.has-ast-global-color-7-border-color {
			border-color: var(--wp--preset--color--ast-global-color-7) !important;
		}

		.has-ast-global-color-8-border-color {
			border-color: var(--wp--preset--color--ast-global-color-8) !important;
		}

		.has-vivid-cyan-blue-to-vivid-purple-gradient-background {
			background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
		}

		.has-light-green-cyan-to-vivid-green-cyan-gradient-background {
			background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
		}

		.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-orange-to-vivid-red-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
		}

		.has-very-light-gray-to-cyan-bluish-gray-gradient-background {
			background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
		}

		.has-cool-to-warm-spectrum-gradient-background {
			background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
		}

		.has-blush-light-purple-gradient-background {
			background: var(--wp--preset--gradient--blush-light-purple) !important;
		}

		.has-blush-bordeaux-gradient-background {
			background: var(--wp--preset--gradient--blush-bordeaux) !important;
		}

		.has-luminous-dusk-gradient-background {
			background: var(--wp--preset--gradient--luminous-dusk) !important;
		}

		.has-pale-ocean-gradient-background {
			background: var(--wp--preset--gradient--pale-ocean) !important;
		}

		.has-electric-grass-gradient-background {
			background: var(--wp--preset--gradient--electric-grass) !important;
		}

		.has-midnight-gradient-background {
			background: var(--wp--preset--gradient--midnight) !important;
		}

		.has-small-font-size {
			font-size: var(--wp--preset--font-size--small) !important;
		}

		.has-medium-font-size {
			font-size: var(--wp--preset--font-size--medium) !important;
		}

		.has-large-font-size {
			font-size: var(--wp--preset--font-size--large) !important;
		}

		.has-x-large-font-size {
			font-size: var(--wp--preset--font-size--x-large) !important;
		}

		:root :where(.wp-block-pullquote) {
			font-size: 1.5em;
			line-height: 1.6;
		}
	</style>
	<link rel='stylesheet' id='latepoint-main-front-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/latepoint/public/stylesheets/front.css?ver=5.1.94' media='all' />
	<style id='latepoint-main-front-inline-css'>
		:root {
			--latepoint-brand-primary: #033231;
			--latepoint-body-color: #1f222b;
			--latepoint-headings-color: #14161d;
			--latepoint-color-text-faded: #7c85a3;
			--latepoint-timeslot-selected-color: --latepoint-brand-primary;
			--latepoint-calendar-weekday-label-color: var(--latepoint-headings-color);
			--latepoint-calendar-weekday-label-bg: #fff;
			--latepoint-side-panel-bg: #fff;
			--latepoint-summary-panel-bg: #fff;
		}
	</style>
	<link rel='stylesheet' id='hfe-style-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.4.9' media='all' />
	<link rel='stylesheet' id='elementor-frontend-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.31.2' media='all' />
	<link rel='stylesheet' id='elementor-post-4-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-4.css?ver=1756196223' media='all' />
	<link rel='stylesheet' id='astra-sites-showcase-blocks-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/astra-sites-showcase/assets/css/blocks.css?ver=2.4.12' media='all' />
	<link rel='stylesheet' id='uael-frontend-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/ultimate-elementor/assets/min-css/uael-frontend.min.css?ver=1.39.9' media='all' />
	<link rel='stylesheet' id='wpforms-modern-full-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-full.min.css?ver=1.9.7.3' media='all' />
	<style id='wpforms-modern-full-inline-css'>
		:root {
			--wpforms-field-border-radius: 3px;
			--wpforms-field-border-style: solid;
			--wpforms-field-border-size: 1px;
			--wpforms-field-background-color: #ffffff;
			--wpforms-field-border-color: rgba(0, 0, 0, 0.25);
			--wpforms-field-border-color-spare: rgba(0, 0, 0, 0.25);
			--wpforms-field-text-color: rgba(0, 0, 0, 0.7);
			--wpforms-field-menu-color: #ffffff;
			--wpforms-label-color: rgba(0, 0, 0, 0.85);
			--wpforms-label-sublabel-color: rgba(0, 0, 0, 0.55);
			--wpforms-label-error-color: #d63637;
			--wpforms-button-border-radius: 3px;
			--wpforms-button-border-style: none;
			--wpforms-button-border-size: 1px;
			--wpforms-button-background-color: #066aab;
			--wpforms-button-border-color: #066aab;
			--wpforms-button-text-color: #ffffff;
			--wpforms-page-break-color: #066aab;
			--wpforms-background-image: none;
			--wpforms-background-position: center center;
			--wpforms-background-repeat: no-repeat;
			--wpforms-background-size: cover;
			--wpforms-background-width: 100px;
			--wpforms-background-height: 100px;
			--wpforms-background-color: rgba(0, 0, 0, 0);
			--wpforms-background-url: none;
			--wpforms-container-padding: 0px;
			--wpforms-container-border-style: none;
			--wpforms-container-border-width: 1px;
			--wpforms-container-border-color: #000000;
			--wpforms-container-border-radius: 3px;
			--wpforms-field-size-input-height: 43px;
			--wpforms-field-size-input-spacing: 15px;
			--wpforms-field-size-font-size: 16px;
			--wpforms-field-size-line-height: 19px;
			--wpforms-field-size-padding-h: 14px;
			--wpforms-field-size-checkbox-size: 16px;
			--wpforms-field-size-sublabel-spacing: 5px;
			--wpforms-field-size-icon-size: 1;
			--wpforms-label-size-font-size: 16px;
			--wpforms-label-size-line-height: 19px;
			--wpforms-label-size-sublabel-font-size: 14px;
			--wpforms-label-size-sublabel-line-height: 17px;
			--wpforms-button-size-font-size: 17px;
			--wpforms-button-size-height: 41px;
			--wpforms-button-size-padding-h: 15px;
			--wpforms-button-size-margin-top: 10px;
			--wpforms-container-shadow-size-box-shadow: none;

		}
	</style>
	<link rel='stylesheet' id='uael-teammember-social-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
	<link rel='stylesheet' id='uael-social-share-icons-brands-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='uael-social-share-icons-fontawesome-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='uael-nav-menu-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='e-shapes-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/conditionals/shapes.min.css?ver=3.31.2' media='all' />
	<link rel='stylesheet' id='widget-heading-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.31.2' media='all' />
	<link rel='stylesheet' id='widget-rating-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-rating.min.css?ver=3.31.2' media='all' />
	<link rel='stylesheet' id='elementor-post-22-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-22.css?ver=1756197457' media='all' />
	<link rel='stylesheet' id='elementor-post-536-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/css/post-536.css?ver=1756196223' media='all' />
	<link rel='stylesheet' id='astra-addon-css-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/astra-addon/astra-addon-689579e29583f2-35016433.css?ver=4.11.6' media='all' />
	<style id='astra-addon-css-inline-css'>
		#content:before {
			content: "921";
			position: absolute;
			overflow: hidden;
			opacity: 0;
			visibility: hidden;
		}

		.blog-layout-2 {
			position: relative;
		}

		.single .ast-author-details .author-title {
			color: var(--ast-global-color-2);
		}

		.single.ast-page-builder-template .ast-single-author-box {
			padding: 2em 20px;
		}

		.single.ast-separate-container .ast-author-meta {
			padding: 3em;
		}

		@media (max-width:921px) {
			.single.ast-separate-container .ast-author-meta {
				padding: 1.5em 2.14em;
			}

			.single .ast-author-meta .post-author-avatar {
				margin-bottom: 1em;
			}

			.ast-separate-container .ast-grid-2 .ast-article-post,
			.ast-separate-container .ast-grid-3 .ast-article-post,
			.ast-separate-container .ast-grid-4 .ast-article-post {
				width: 100%;
			}

			.ast-separate-container .ast-grid-md-2 .ast-article-post {
				width: 50%;
			}

			.ast-separate-container .ast-grid-md-2 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-md-3 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-md-4 .ast-article-post.ast-separate-posts {
				padding: 0 .75em 0;
			}

			.blog-layout-1 .post-content,
			.blog-layout-1 .ast-blog-featured-section {
				float: none;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on {
				margin-top: 0;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
				margin-top: 1em;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
				margin-top: -1.5em;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
				margin-left: -2.14em;
				margin-right: -2.14em;
			}

			.ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .entry-header .post-thumb-img-content:first-child {
				margin-top: -1.5em;
			}

			.ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .post-thumb-img-content {
				margin-left: -2.14em;
				margin-right: -2.14em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
				margin-left: -1.5em;
				margin-right: -1.5em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
				margin-left: -0.5em;
				margin-right: -0.5em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .square .posted-on {
				margin-top: 0;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
				margin-top: 1em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
				margin-top: -1.5em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
				margin-left: -1.5em;
				margin-right: -1.5em;
			}

			.blog-layout-2 {
				display: flex;
				flex-direction: column-reverse;
			}

			.ast-separate-container .blog-layout-3,
			.ast-separate-container .blog-layout-1 {
				display: block;
			}

			.ast-plain-container .ast-grid-2 .ast-article-post,
			.ast-plain-container .ast-grid-3 .ast-article-post,
			.ast-plain-container .ast-grid-4 .ast-article-post,
			.ast-page-builder-template .ast-grid-2 .ast-article-post,
			.ast-page-builder-template .ast-grid-3 .ast-article-post,
			.ast-page-builder-template .ast-grid-4 .ast-article-post {
				width: 100%;
			}

			.ast-separate-container .ast-blog-layout-4-grid .ast-article-post {
				display: flex;
			}
		}

		@media (max-width:921px) {
			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
				margin-top: 0;
				margin-left: -2.14em;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
				margin-top: 0;
				margin-left: -1.14em;
			}
		}

		@media (min-width:922px) {

			.ast-separate-container.ast-blog-grid-2 .ast-archive-description,
			.ast-separate-container.ast-blog-grid-3 .ast-archive-description,
			.ast-separate-container.ast-blog-grid-4 .ast-archive-description {
				margin-bottom: 1.33333em;
			}

			.blog-layout-2.ast-no-thumb .post-content,
			.blog-layout-3.ast-no-thumb .post-content {
				width: calc(100% - 5.714285714em);
			}

			.blog-layout-2.ast-no-thumb.ast-no-date-box .post-content,
			.blog-layout-3.ast-no-thumb.ast-no-date-box .post-content {
				width: 100%;
			}

			.ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts {
				border-bottom: 0;
			}

			.ast-separate-container .ast-grid-2>.site-main>.ast-row:before,
			.ast-separate-container .ast-grid-2>.site-main>.ast-row:after,
			.ast-separate-container .ast-grid-3>.site-main>.ast-row:before,
			.ast-separate-container .ast-grid-3>.site-main>.ast-row:after,
			.ast-separate-container .ast-grid-4>.site-main>.ast-row:before,
			.ast-separate-container .ast-grid-4>.site-main>.ast-row:after {
				flex-basis: 0;
				width: 0;
			}

			.ast-separate-container .ast-grid-2 .ast-article-post,
			.ast-separate-container .ast-grid-3 .ast-article-post,
			.ast-separate-container .ast-grid-4 .ast-article-post {
				display: flex;
				padding: 0;
			}

			.ast-plain-container .ast-grid-2>.site-main>.ast-row,
			.ast-plain-container .ast-grid-3>.site-main>.ast-row,
			.ast-plain-container .ast-grid-4>.site-main>.ast-row,
			.ast-page-builder-template .ast-grid-2>.site-main>.ast-row,
			.ast-page-builder-template .ast-grid-3>.site-main>.ast-row,
			.ast-page-builder-template .ast-grid-4>.site-main>.ast-row {
				margin-left: -1em;
				margin-right: -1em;
				display: flex;
				flex-flow: row wrap;
				align-items: stretch;
			}

			.ast-plain-container .ast-grid-2>.site-main>.ast-row:before,
			.ast-plain-container .ast-grid-2>.site-main>.ast-row:after,
			.ast-plain-container .ast-grid-3>.site-main>.ast-row:before,
			.ast-plain-container .ast-grid-3>.site-main>.ast-row:after,
			.ast-plain-container .ast-grid-4>.site-main>.ast-row:before,
			.ast-plain-container .ast-grid-4>.site-main>.ast-row:after,
			.ast-page-builder-template .ast-grid-2>.site-main>.ast-row:before,
			.ast-page-builder-template .ast-grid-2>.site-main>.ast-row:after,
			.ast-page-builder-template .ast-grid-3>.site-main>.ast-row:before,
			.ast-page-builder-template .ast-grid-3>.site-main>.ast-row:after,
			.ast-page-builder-template .ast-grid-4>.site-main>.ast-row:before,
			.ast-page-builder-template .ast-grid-4>.site-main>.ast-row:after {
				flex-basis: 0;
				width: 0;
			}

			.ast-plain-container .ast-grid-2 .ast-article-post,
			.ast-plain-container .ast-grid-3 .ast-article-post,
			.ast-plain-container .ast-grid-4 .ast-article-post,
			.ast-page-builder-template .ast-grid-2 .ast-article-post,
			.ast-page-builder-template .ast-grid-3 .ast-article-post,
			.ast-page-builder-template .ast-grid-4 .ast-article-post {
				display: flex;
			}

			.ast-plain-container .ast-grid-2 .ast-article-post:last-child,
			.ast-plain-container .ast-grid-3 .ast-article-post:last-child,
			.ast-plain-container .ast-grid-4 .ast-article-post:last-child,
			.ast-page-builder-template .ast-grid-2 .ast-article-post:last-child,
			.ast-page-builder-template .ast-grid-3 .ast-article-post:last-child,
			.ast-page-builder-template .ast-grid-4 .ast-article-post:last-child {
				margin-bottom: 1.5em;
			}

			.ast-separate-container .ast-grid-2>.site-main>.ast-row,
			.ast-separate-container .ast-grid-3>.site-main>.ast-row,
			.ast-separate-container .ast-grid-4>.site-main>.ast-row {
				margin-left: -1em;
				margin-right: -1em;
				display: flex;
				flex-flow: row wrap;
				align-items: stretch;
			}

			.single .ast-author-meta .ast-author-details {
				display: flex;
				align-items: center;
			}

			.post-author-bio .author-title {
				margin-bottom: 10px;
			}
		}

		@media (min-width:922px) {

			.single .post-author-avatar,
			.single .post-author-bio {
				float: left;
				clear: right;
			}

			.single .ast-author-meta .post-author-avatar {
				margin-right: 1.33333em;
			}

			.single .ast-author-meta .about-author-title-wrapper,
			.single .ast-author-meta .post-author-bio {
				text-align: left;
			}

			.blog-layout-2 .post-content {
				padding-right: 2em;
			}

			.blog-layout-2.ast-no-date-box.ast-no-thumb .post-content {
				padding-right: 0;
			}

			.blog-layout-3 .post-content {
				padding-left: 2em;
			}

			.blog-layout-3.ast-no-date-box.ast-no-thumb .post-content {
				padding-left: 0;
			}

			.ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts:nth-child(2n+0),
			.ast-separate-container .ast-grid-2 .ast-article-post.ast-separate-posts:nth-child(2n+1),
			.ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts:nth-child(2n+0),
			.ast-separate-container .ast-grid-3 .ast-article-post.ast-separate-posts:nth-child(2n+1),
			.ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts:nth-child(2n+0),
			.ast-separate-container .ast-grid-4 .ast-article-post.ast-separate-posts:nth-child(2n+1) {
				padding: 0 1em 0;
			}
		}

		@media (max-width:544px) {
			.ast-separate-container .ast-grid-sm-1 .ast-article-post {
				width: 100%;
			}

			.ast-separate-container .ast-grid-sm-2 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-sm-3 .ast-article-post.ast-separate-posts,
			.ast-separate-container .ast-grid-sm-4 .ast-article-post.ast-separate-posts {
				padding: 0 .5em 0;
			}

			.ast-separate-container .ast-grid-sm-1 .ast-article-post.ast-separate-posts {
				padding: 0;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
				margin-top: 0.5em;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
			.ast-separate-container .ast-article-single.remove-featured-img-padding .single-layout-1 .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
				margin-left: -1em;
				margin-right: -1em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
				margin-left: -0.5em;
				margin-right: -0.5em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section:first-child .circle .posted-on {
				margin-top: 0.5em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-content .ast-blog-featured-section:first-child .post-thumb-img-content {
				margin-top: -1.33333em;
			}

			.ast-separate-container.ast-blog-grid-2 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-3 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content,
			.ast-separate-container.ast-blog-grid-4 .ast-article-post.remove-featured-img-padding .blog-layout-1 .post-thumb-img-content {
				margin-left: -1em;
				margin-right: -1em;
			}

			.ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-1,
			.ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-2,
			.ast-separate-container .ast-grid-2 .ast-article-post .blog-layout-3 {
				padding: 1.33333em 1em;
			}

			.ast-separate-container .ast-grid-3 .ast-article-post .blog-layout-1,
			.ast-separate-container .ast-grid-4 .ast-article-post .blog-layout-1 {
				padding: 1.33333em 1em;
			}

			.single.ast-separate-container .ast-author-meta {
				padding: 1.5em 1em;
			}
		}

		@media (max-width:544px) {
			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .square .posted-on {
				margin-left: -1em;
			}

			.ast-separate-container .ast-article-post.remove-featured-img-padding.has-post-thumbnail .blog-layout-1 .post-content .ast-blog-featured-section .circle .posted-on {
				margin-left: -0.5em;
			}
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			margin-bottom: 20px;
		}

		@media (min-width:922px) {
			.ast-hide-display-device-desktop {
				display: none;
			}

			[class^="astra-advanced-hook-"] .wp-block-query .wp-block-post-template .wp-block-post {
				width: 100%;
			}
		}

		@media (min-width:545px) and (max-width:921px) {
			.ast-hide-display-device-tablet {
				display: none;
			}
		}

		@media (max-width:544px) {
			.ast-hide-display-device-mobile {
				display: none;
			}
		}

		.ast-article-post .ast-date-meta .posted-on,
		.ast-article-post .ast-date-meta .posted-on * {
			background: var(--ast-global-color-2);
			color: #ffffff;
		}

		.ast-article-post .ast-date-meta .posted-on .date-month,
		.ast-article-post .ast-date-meta .posted-on .date-year {
			color: #ffffff;
		}

		.ast-loader>div {
			background-color: var(--ast-global-color-2);
		}

		.ast-page-builder-template .ast-archive-description {
			margin-bottom: 2em;
		}

		.ast-load-more {
			cursor: pointer;
			display: none;
			border: 2px solid var(--ast-border-color);
			transition: all 0.2s linear;
			color: #000;
		}

		.ast-load-more.active {
			display: inline-block;
			padding: 0 1.5em;
			line-height: 3em;
		}

		.ast-load-more.no-more:hover {
			border-color: var(--ast-border-color);
			color: #000;
		}

		.ast-load-more.no-more:hover {
			background-color: inherit;
		}

		.ast-header-search .ast-search-menu-icon .search-field {
			border-radius: 2px;
		}

		.ast-header-search .ast-search-menu-icon .search-submit {
			border-radius: 2px;
		}

		.ast-header-search .ast-search-menu-icon .search-form {
			border-top-width: 1px;
			border-bottom-width: 1px;
			border-left-width: 1px;
			border-right-width: 1px;
			border-color: #ddd;
			border-radius: 2px;
		}

		.ast-separate-container .primary:not(.ast-grid-1) .ast-article-inner,
		.ast-narrow-container .primary:not(.ast-grid-1) .ast-article-inner {
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}

		@media (max-width:921px) {

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .ast-comment-list li.depth-1,
			.ast-separate-container .comment-respond .ast-separate-container .ast-related-posts-wrap {
				padding-top: 1.5em;
				padding-bottom: 1.5em;
			}

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .comments-count-wrapper,
			.ast-separate-container .ast-comment-list li.depth-1,
			.ast-separate-container .comment-respond,
			.ast-separate-container .related-posts-title-wrapper,
			.ast-separate-container .related-posts-title-wrapper .single.ast-separate-container .about-author-title-wrapper,
			.ast-separate-container .ast-related-posts-wrap {
				padding-right: 2.14em;
				padding-left: 2.14em;
			}

			.ast-narrow-container .ast-article-post,
			.ast-narrow-container .ast-article-single,
			.ast-narrow-container .ast-comment-list li.depth-1,
			.ast-narrow-container .comment-respond,
			.ast-narrow-container .ast-related-posts-wrap,
			.ast-narrow-container .ast-single-related-posts-container {
				padding-top: 1.5em;
				padding-bottom: 1.5em;
			}

			.ast-narrow-container .ast-article-post,
			.ast-narrow-container .ast-article-single,
			.ast-narrow-container .comments-count-wrapper,
			.ast-narrow-container .ast-comment-list li.depth-1,
			.ast-narrow-container .comment-respond,
			.ast-narrow-container .related-posts-title-wrapper,
			.ast-narrow-container .related-posts-title-wrapper,
			.single.ast-narrow-container .about-author-title-wrapper,
			.ast-narrow-container .ast-related-posts-wrap,
			.ast-narrow-container .ast-single-related-posts-container {
				padding-right: 2.14em;
				padding-left: 2.14em;
			}

			.ast-separate-container.ast-right-sidebar #primary,
			.ast-separate-container.ast-left-sidebar #primary,
			.ast-separate-container #primary,
			.ast-plain-container #primary,
			.ast-narrow-container #primary {
				margin-top: 1.5em;
				margin-bottom: 1.5em;
			}

			.ast-left-sidebar #primary,
			.ast-right-sidebar #primary,
			.ast-separate-container.ast-right-sidebar #primary,
			.ast-separate-container.ast-left-sidebar #primary,
			.ast-separate-container #primary,
			.ast-narrow-container #primary {
				padding-left: 0em;
				padding-right: 0em;
			}

			.ast-no-sidebar.ast-separate-container .entry-content .alignfull,
			.ast-no-sidebar.ast-narrow-container .entry-content .alignfull {
				margin-right: -2.14em;
				margin-left: -2.14em;
			}
		}

		@media (max-width:544px) {

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .ast-comment-list li.depth-1,
			.ast-separate-container .comment-respond,
			.ast-separate-container .ast-related-posts-wrap {
				padding-top: 1.5em;
				padding-bottom: 1.5em;
			}

			.ast-narrow-container .ast-article-post,
			.ast-narrow-container .ast-article-single,
			.ast-narrow-container .ast-comment-list li.depth-1,
			.ast-narrow-container .comment-respond,
			.ast-narrow-container .ast-related-posts-wrap,
			.ast-narrow-container .ast-single-related-posts-container {
				padding-top: 1.5em;
				padding-bottom: 1.5em;
			}

			.ast-separate-container .ast-article-post,
			.ast-separate-container .ast-article-single,
			.ast-separate-container .comments-count-wrapper,
			.ast-separate-container .ast-comment-list li.depth-1,
			.ast-separate-container .comment-respond,
			.ast-separate-container .related-posts-title-wrapper,
			.ast-separate-container .related-posts-title-wrapper,
			.single.ast-separate-container .about-author-title-wrapper,
			.ast-separate-container .ast-related-posts-wrap {
				padding-right: 1em;
				padding-left: 1em;
			}

			.ast-narrow-container .ast-article-post,
			.ast-narrow-container .ast-article-single,
			.ast-narrow-container .comments-count-wrapper,
			.ast-narrow-container .ast-comment-list li.depth-1,
			.ast-narrow-container .comment-respond,
			.ast-narrow-container .related-posts-title-wrapper,
			.ast-narrow-container .related-posts-title-wrapper,
			.single.ast-narrow-container .about-author-title-wrapper,
			.ast-narrow-container .ast-related-posts-wrap,
			.ast-narrow-container .ast-single-related-posts-container {
				padding-right: 1em;
				padding-left: 1em;
			}

			.ast-no-sidebar.ast-separate-container .entry-content .alignfull,
			.ast-no-sidebar.ast-narrow-container .entry-content .alignfull {
				margin-right: -1em;
				margin-left: -1em;
			}
		}

		@media (max-width:544px) {

			.ast-header-break-point .header-main-layout-2 .site-branding,
			.ast-header-break-point .ast-mobile-header-stack .ast-mobile-menu-buttons {
				padding-bottom: 0px;
			}
		}

		@media (max-width:921px) {

			.ast-separate-container.ast-two-container #secondary .widget,
			.ast-separate-container #secondary .widget {
				margin-bottom: 1.5em;
			}
		}

		@media (max-width:921px) {

			.ast-separate-container #primary,
			.ast-narrow-container #primary {
				padding-top: 0px;
			}
		}

		@media (max-width:921px) {

			.ast-separate-container #primary,
			.ast-narrow-container #primary {
				padding-bottom: 0px;
			}
		}

		.ast-builder-menu-1 .main-header-menu.submenu-with-border .astra-megamenu,
		.ast-builder-menu-1 .main-header-menu.submenu-with-border .astra-full-megamenu-wrapper {
			border-top-width: 2px;
			border-bottom-width: 0px;
			border-right-width: 0px;
			border-left-width: 0px;
			border-color: #ffffff;
			border-style: solid;
		}

		@media (max-width:921px) {
			.ast-header-break-point .ast-builder-menu-1 .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0;
			}
		}

		@media (max-width:544px) {
			.ast-header-break-point .ast-builder-menu-1 .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0;
			}
		}

		@media (max-width:921px) {
			.ast-hfb-header .ast-builder-menu-mobile .ast-nav-menu .sub-menu .menu-item.menu-item-has-children>.ast-menu-toggle {
				top: 0px;
				right: calc(0px - 0.907em);
			}
		}

		.site-title,
		.site-title a {
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			line-height: 1.23em;
		}

		.ast-blog-meta-container {
			font-weight: 600;
		}

		.ast-read-more-container a {
			font-size: 14px;
			font-size: 0.875rem;
		}

		.ast-excerpt-container {
			font-size: 16px;
			font-size: 1rem;
		}

		.ast-pagination .page-numbers,
		.ast-pagination .page-navigation {
			font-size: 16px;
			font-size: 1rem;
		}

		#secondary .widget-title {
			font-size: 26px;
			font-size: 1.625rem;
			font-weight: 700;
			font-family: 'Inter', sans-serif;
			line-height: 1.23em;
		}

		.secondary .widget>*:not(.widget-title) {
			font-size: 16px;
			font-size: 1rem;
		}

		.blog .entry-title,
		.blog .entry-title a,
		.archive .entry-title,
		.archive .entry-title a,
		.search .entry-title,
		.search .entry-title a {
			font-family: 'Inter', sans-serif;
			font-weight: 600;
			line-height: 1.23em;
		}

		button,
		.ast-button,
		input#submit,
		input[type="button"],
		input[type="submit"],
		input[type="reset"] {
			font-size: 16px;
			font-size: 1rem;
			font-weight: 600;
			text-transform: uppercase;
		}

		h4.widget-title {
			font-weight: 700;
		}

		h5.widget-title {
			font-weight: 700;
		}

		h6.widget-title {
			font-weight: 700;
		}

		.elementor-widget-heading h4.elementor-heading-title {
			line-height: 1.2em;
		}

		.elementor-widget-heading h5.elementor-heading-title {
			line-height: 1.2em;
		}

		.elementor-widget-heading h6.elementor-heading-title {
			line-height: 1.25em;
		}
	</style>
	<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
	<link rel='stylesheet' id='hfe-icons-list-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
	<link rel='stylesheet' id='hfe-social-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
	<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
	<link rel='stylesheet' id='elementor-gf-local-roboto-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/google-fonts/css/roboto.css?ver=1752129083' media='all' />
	<link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/elementor/google-fonts/css/robotoslab.css?ver=1752129091' media='all' />
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
	<script id="jquery-js-after">
		! function($) {
			"use strict";
			$(document).ready(function() {
				$(this).scrollTop() > 100 && $(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"), $(window).scroll(function() {
					$(this).scrollTop() < 100 ? $(".hfe-scroll-to-top-wrap").fadeOut(300) : $(".hfe-scroll-to-top-wrap").fadeIn(300)
				}), $(".hfe-scroll-to-top-wrap").on("click", function() {
					$("html, body").animate({
						scrollTop: 0
					}, 300);
					return !1
				})
			})
		}(jQuery);
		! function($) {
			'use strict';
			$(document).ready(function() {
				var bar = $('.hfe-reading-progress-bar');
				if (!bar.length) return;
				$(window).on('scroll', function() {
					var s = $(window).scrollTop(),
						d = $(document).height() - $(window).height(),
						p = d ? s / d * 100 : 0;
					bar.css('width', p + '%')
				});
			});
		}(jQuery);
	</script>
	<!--[if IE]>
<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/themes/astra/assets/js/minified/flexibility.min.js?ver=4.11.10" id="astra-flexibility-js"></script>
<script id="astra-flexibility-js-after">
flexibility(document.documentElement);
</script>
<![endif]-->
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/latepoint/public/javascripts/vendor-front.js?ver=5.1.94" id="latepoint-vendor-front-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
	<script id="wp-i18n-js-after">
		wp.i18n.setLocaleData({
			'text direction\u0004ltr': ['ltr']
		});
	</script>
	<script id="latepoint-main-front-js-extra">
		var latepoint_helper = {
			"route_action": "latepoint_route_call",
			"response_status": {
				"success": "success",
				"error": "error"
			},
			"ajaxurl": "https:\/\/websitedemos.net\/brikly-construction-company-04\/wp-admin\/admin-ajax.php",
			"time_pick_style": "timebox",
			"string_today": "Today",
			"reload_booking_form_summary_route": "steps__reload_booking_form_summary_panel",
			"time_system": "12",
			"msg_not_available": "Not Available",
			"booking_button_route": "steps__start",
			"remove_cart_item_route": "carts__remove_item_from_cart",
			"show_booking_end_time": "yes",
			"customer_dashboard_url": "https:\/\/websitedemos.net\/brikly-construction-company-04\/customer-cabinet",
			"demo_mode": "",
			"cancel_booking_prompt": "Are you sure you want to cancel this appointment?",
			"single_space_message": "Space Available",
			"many_spaces_message": "Spaces Available",
			"body_font_family": "\"latepoint\", -apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif ",
			"headings_font_family": "\"latepoint\", -apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif ",
			"currency_symbol_before": "$",
			"currency_symbol_after": "",
			"thousand_separator": ",",
			"decimal_separator": ".",
			"number_of_decimals": "2",
			"included_phone_countries": "[]",
			"default_phone_country": "us",
			"is_timezone_selected": "",
			"start_from_order_intent_route": "steps__start_from_order_intent",
			"start_from_order_intent_key": "",
			"is_enabled_show_dial_code_with_flag": "1",
			"mask_phone_number_fields": "1",
			"msg_validation_presence": "can not be blank",
			"msg_validation_presence_checkbox": "has to be checked",
			"msg_validation_invalid": "is invalid",
			"msg_minutes_suffix": " minutes",
			"is_stripe_connect_enabled": "",
			"check_order_intent_bookable_route": "steps__check_order_intent_bookable",
			"generate_timeslots_for_day_route": "steps__generate_timeslots_for_day",
			"payment_environment": "live",
			"style_border_radius": "rounded",
			"datepicker_timeslot_selected_label": "Selected",
			"invoices_payment_form_route": "invoices__payment_form",
			"invoices_summary_before_payment_route": "invoices__summary_before_payment",
			"reset_presets_when_adding_new_item": "",
			"start_from_transaction_access_key": "",
			"stripe_connect_route_create_payment_intent": "stripe_connect__create_payment_intent",
			"stripe_connect_route_create_payment_intent_for_transaction_intent": "stripe_connect__create_payment_intent_for_transaction"
		};
	</script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/latepoint/public/javascripts/front.js?ver=5.1.94" id="latepoint-main-front-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
	<script src="https://websitedemos.net/brikly-construction-company-04/wp-includes/js/dist/url.min.js?ver=c2964167dfe2477c14ea" id="wp-url-js"></script>
	<script id="showcase-cta-preview-js-js-after">
		(window.self !== window.top) || document.write('<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/astra-sites-server/dist/template-preview/main.js?ver=ae2e87f495819b6e9f4f"></scr' + 'ipt>');
	</script>
	<script id="starter-templates-preview-js-js-extra">
		var starterTemplatesPreview = {
			"site_url": "https:\/\/websitedemos.net\/brikly-construction-company-04",
			"AstColorPaletteVarPrefix": "--ast-global-color-",
			"AstEleColorPaletteVarPrefix": ["ast-global-color-0", "ast-global-color-1", "ast-global-color-2", "ast-global-color-3", "ast-global-color-4", "ast-global-color-5", "ast-global-color-6", "ast-global-color-7", "ast-global-color-8"],
			"templateTheme": "astra"
		};
	</script>
	<script id="starter-templates-preview-js-js-after">
		(window.self === window.top) || document.write('<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/plugins/astra-sites-server/dist/template-preview/main.js?ver=ae2e87f495819b6e9f4f"></scr' + 'ipt>');
	</script>
	<link rel="https://api.w.org/" href="https://websitedemos.net/brikly-construction-company-04/wp-json/" />
	<link rel="alternate" title="JSON" type="application/json" href="https://websitedemos.net/brikly-construction-company-04/wp-json/wp/v2/pages/22" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://websitedemos.net/brikly-construction-company-04/xmlrpc.php?rsd" />
	<meta name="generator" content="WordPress 6.8.2" />
	<link rel='shortlink' href='https://websitedemos.net/brikly-construction-company-04/?p=22' />
	<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://websitedemos.net/brikly-construction-company-04/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Fbrikly-construction-company-04%2Fcontact%2F" />
	<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://websitedemos.net/brikly-construction-company-04/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Fbrikly-construction-company-04%2Fcontact%2F&#038;format=xml" />
	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-PW78FQ8');
	</script>
	<!-- End Google Tag Manager -->
	<meta name="generator" content="Elementor 3.31.2; features: e_font_icon_svg, additional_custom_breakpoints, e_element_cache; settings: css_print_method-external, google_font-enabled, font_display-swap">
	<style>
		.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
		.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
			background-image: none !important;
		}

		@media screen and (max-height: 1024px) {

			.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
			.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
				background-image: none !important;
			}
		}

		@media screen and (max-height: 640px) {

			.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
			.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
				background-image: none !important;
			}
		}
	</style>
	<link rel="icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-32x32.png" sizes="32x32" />
	<link rel="icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-192x192.png" sizes="192x192" />
	<link rel="apple-touch-icon" href="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-180x180.png" />
	<meta name="msapplication-TileImage" content="https://websitedemos.net/brikly-construction-company-04/wp-content/uploads/sites/1544/2025/07/cropped-Site-Logo-270x270.png" />
</head>

<?php echo $__env->make('website.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="content" class="site-content">
	<div class="ast-container">
		<div id="primary" class="content-area primary">
			<main id="main" class="site-main">
				<article class="post-22 page type-page status-publish ast-article-single" id="post-22" itemtype="https://schema.org/CreativeWork" itemscope="itemscope">
					<header class="entry-header ast-no-thumbnail ast-no-title ast-header-without-markup">
					</header> <!-- .entry-header -->

					<div class="entry-content clear" itemprop="text">
						<div data-elementor-type="wp-page" data-elementor-id="22" class="elementor elementor-22">
							<div class="elementor-element elementor-element-9d5bca4 e-flex e-con-boxed e-con e-parent" data-id="9d5bca4" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
								<div class="e-con-inner">
									<div class="elementor-shape elementor-shape-bottom" aria-hidden="true" data-negative="true">
										<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
											<path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" />
										</svg>
									</div>
									<div class="elementor-element elementor-element-cba2c18 e-con-full e-flex e-con e-child" data-id="cba2c18" data-element_type="container">
										<div class="elementor-element elementor-element-9542e78 e-con-full e-flex e-con e-child" data-id="9542e78" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
											<div class="elementor-element elementor-element-7e6c384 elementor-widget elementor-widget-text-editor" data-id="7e6c384" data-element_type="widget" data-widget_type="text-editor.default">
												<div class="elementor-widget-container">
													<p>Contact</p>
												</div>
											</div>
										</div>
										<div class="elementor-element elementor-element-97c908f elementor-widget elementor-widget-uael-infobox" data-id="97c908f" data-element_type="widget" data-widget_type="uael-infobox.default">
											<div class="elementor-widget-container">

												<div class="uael-module-content uael-infobox uael-imgicon-style-normal  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-none">
													<div class="uael-infobox-left-right-wrap">
														<div class="uael-infobox-content">
															<div class="uael-module-content uael-imgicon-wrap ">
															</div>
															<div>
																<h2 style="color: white;">Get in Touch with Vishu Real Estate</h2>
																<div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
																	Your dream property is just a call away - schedule a free consultation. </div>

															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="elementor-element elementor-element-a068243 e-flex e-con-boxed e-con e-parent" data-id="a068243" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
								<div class="e-con-inner">
									<div class="elementor-element elementor-element-bc41412 e-con-full e-flex e-con e-child" data-id="bc41412" data-element_type="container">
										<div class="elementor-element elementor-element-95920aa elementor-widget elementor-widget-sureforms_form" data-id="95920aa" data-element_type="widget" data-widget_type="sureforms_form.default">
											<div class="elementor-widget-container">
												<div class="srfm-form-container srfm-form-container-305 srfm-bg-color">
													<style>
														/* Need to check and remove the input variables related to the Style Tab. */
														.srfm-form-container-305 {
															/* New test variables */
															--srfm-color-scheme-primary: var(--ast-global-color-0);
															--srfm-color-scheme-text-on-primary: var(--ast-global-color-2);
															--srfm-color-scheme-text: var(--ast-global-color-2);
															--srfm-quill-editor-color: var(--ast-global-color-0);

															--srfm-color-input-label: var(--ast-global-color-2);
															--srfm-color-input-description: hsl(from var(--ast-global-color-2) h s l / 0.65);
															--srfm-color-input-placeholder: hsl(from var(--ast-global-color-2) h s l / 0.5);
															--srfm-color-input-text: var(--ast-global-color-2);
															--srfm-color-input-prefix: hsl(from var(--ast-global-color-2) h s l / 0.65);
															--srfm-color-input-background: hsl(from var(--ast-global-color-2) h s l / 0.02);
															--srfm-color-input-background-hover: hsl(from var(--ast-global-color-2) h s l / 0.05);
															--srfm-color-input-background-disabled: hsl(from var(--ast-global-color-2) h s l / 0.07);
															--srfm-color-input-border: hsl(from var(--ast-global-color-2) h s l / 0.25);
															--srfm-color-input-border-disabled: hsl(from var(--ast-global-color-2) h s l / 0.15);
															--srfm-color-multi-choice-svg: hsl(from var(--ast-global-color-2) h s l / 0.7);
															--srfm-color-input-border-hover: hsl(from var(--ast-global-color-0) h s l / 0.65);
															--srfm-color-input-border-focus-glow: hsl(from var(--ast-global-color-0) h s l / 0.15);
															--srfm-color-input-selected: hsl(from var(--ast-global-color-0) h s l / 0.1);
															--srfm-btn-color-hover: hsl(from var(--ast-global-color-0) h s l / 0.9);
															--srfm-btn-color-disabled: hsl(from var(--ast-global-color-0) h s l / 0.25);

															/* Dropdown Variables */
															--srfm-dropdown-input-background-hover: hsl(from var(--ast-global-color-2) h s l / 0.05);
															--srfm-dropdown-option-background-hover: hsl(from var(--ast-global-color-2) h s l / 0.10);
															--srfm-dropdown-option-background-selected: hsl(from var(--ast-global-color-2) h s l / 0.05);
															--srfm-dropdown-option-selected-icon: hsl(from var(--ast-global-color-2) h s l / 0.65);
															--srfm-dropdown-option-text-color: hsl(from var(--ast-global-color-2) h s l / 0.80);
															--srfm-dropdown-option-selected-text: var(--ast-global-color-2);
															--srfm-dropdown-badge-background: hsl(from var(--ast-global-color-2) h s l / 0.05);
															--srfm-dropdown-badge-background-hover: hsl(from var(--ast-global-color-2) h s l / 0.10);
															--srfm-dropdown-menu-border-color: hsl(from var(--ast-global-color-2) h s l / 0.10);
															--srfm-dropdown-placeholder-color: hsl(from var(--ast-global-color-2) h s l / 0.50);
															--srfm-dropdown-icon-color: hsl(from var(--ast-global-color-2) h s l / 0.65);
															--srfm-dropdown-icon-disabled: hsl(from var(--ast-global-color-2) h s l / 0.25);

															/* Background Control Variables */
															--srfm-instant-form-padding-top: 32px;
															--srfm-instant-form-padding-right: 32px;
															--srfm-instant-form-padding-bottom: 32px;
															--srfm-instant-form-padding-left: 32px;
															--srfm-instant-form-border-radius-top: 12px;
															--srfm-instant-form-border-radius-right: 12px;
															--srfm-instant-form-border-radius-bottom: 12px;
															--srfm-instant-form-border-radius-left: 12px;
															--srfm-form-padding-top: 0px;
															--srfm-form-padding-right: 0px;
															--srfm-form-padding-bottom: 0px;
															--srfm-form-padding-left: 0px;
															--srfm-form-border-radius-top: 99px;
															--srfm-form-border-radius-right: 99px;
															--srfm-form-border-radius-bottom: 99px;
															--srfm-form-border-radius-left: 99px;
															--srfm-bg-overlay-opacity: 1;
															--srfm-row-gap-between-blocks: 18px;
															--srfm-address-label-font-size: 16px;
															--srfm-address-label-line-height: 24px;
															--srfm-address-description-font-size: 14px;
															--srfm-address-description-line-height: 20px;
															--srfm-col-gap-between-fields: 16px;
															--srfm-row-gap-between-fields: 16px;
															--srfm-gap-below-address-label: 14px;
															--srfm-dropdown-font-size: 14px;
															--srfm-dropdown-gap-between-input-menu: 4px;
															--srfm-dropdown-badge-padding: 2px 6px;
															--srfm-dropdown-multiselect-font-size: 12px;
															--srfm-dropdown-multiselect-line-height: 16px;
															--srfm-dropdown-padding-right: 12px;
															--srfm-dropdown-padding-right-icon: calc(var(--srfm-dropdown-padding-right) + 20px);
															--srfm-dropdown-multiselect-padding: 8px var(--srfm-dropdown-padding-right-icon) 8px 8px;
															--srfm-input-height: 44px;
															--srfm-input-field-padding: 10px 12px;
															--srfm-input-field-font-size: 16px;
															--srfm-input-field-line-height: 24px;
															--srfm-input-field-margin-top: 6px;
															--srfm-input-field-margin-bottom: 6px;
															--srfm-checkbox-label-font-size: 16px;
															--srfm-checkbox-label-line-height: 24px;
															--srfm-checkbox-description-font-size: 14px;
															--srfm-checkbox-description-line-height: 20px;
															--srfm-check-ctn-width: 16px;
															--srfm-check-ctn-height: 16px;
															--srfm-check-svg-size: 10px;
															--srfm-checkbox-margin-top-frontend: 4px;
															--srfm-checkbox-margin-top-editor: 6px;
															--srfm-check-gap: 8px;
															--srfm-checkbox-description-margin-left: 24px;
															--srfm-flag-section-padding: 10px 0 10px 12px;
															--srfm-gap-between-icon-text: 8px;
															--srfm-label-font-size: 16px;
															--srfm-label-line-height: 24px;
															--srfm-description-font-size: 14px;
															--srfm-description-line-height: 20px;
															--srfm-btn-padding: 10px 14px;
															--srfm-btn-font-size: 16px;
															--srfm-btn-line-height: 24px;
															--srfm-multi-choice-horizontal-padding: 20px;
															--srfm-multi-choice-vertical-padding: 20px;
															--srfm-multi-choice-internal-option-gap: 8px;
															--srfm-multi-choice-vertical-svg-size: 40px;
															--srfm-multi-choice-horizontal-image-size: 24px;
															--srfm-multi-choice-vertical-image-size: 120px;
															--srfm-multi-choice-outer-padding: 2px;
														}
													</style>
													<form method="post" enctype="multipart/form-data">
														<div>
															<label for="first_name">First Name<span class="srfm-required" aria-hidden="true"> *</span></label>
															<input type="text" name="first_name" id="first_name" placeholder="Enter first name" />
														</div>

														<div>
															<label for="last_name">Last Name<span class="srfm-required" aria-hidden="true"> *</span></label>
															<input type="text" name="last_name" id="last_name" placeholder="Enter last name" />
														</div>


														<div>
															<label for="email">Email<span class="srfm-required" aria-hidden="true"> *</span></label>
															<input type="email" name="email" id="email" placeholder="Enter email" />
														</div>


														<div>
															<label for="number">Phone Number<span class="srfm-required" aria-hidden="true"> *</span></label>
															<input type="number" name="number" id="number" placeholder="Enter mobile number" />
														</div>


														<div>
															<label for="message">Your Message<span class="srfm-required" aria-hidden="true"> *</span></label>
															<textarea rows="4" id="message">Enter your message</textarea>
														</div>

														<div class="d-flex justify-content-center">
															<button type="submit">Submit</button>
														</div>
													</form>
													<div class="srfm-single-form srfm-success-box in-page">
														<div aria-live="polite" aria-atomic="true" role="alert" id="srfm-success-message-page-305" class="srfm-success-box-description"></div>
													</div>
												</div>
												<style></style>
												<script></script>
											</div>
										</div>
									</div>
									<div class="elementor-element elementor-element-cb0bbad e-con-full e-flex e-con e-child" data-id="cb0bbad" data-element_type="container">
										<div class="elementor-element elementor-element-565ad34 elementor-widget elementor-widget-text-editor" data-id="565ad34" data-element_type="widget" data-widget_type="text-editor.default">
											<div class="elementor-widget-container">
												<p>We’re Here to Help</p>
											</div>
										</div>
										<div class="elementor-element elementor-element-021b933 elementor-widget__width-initial elementor-widget-tablet__width-inherit elementor-widget elementor-widget-heading" data-id="021b933" data-element_type="widget" data-widget_type="heading.default">
											<div class="elementor-widget-container">
												<h2 class="elementor-heading-title elementor-size-default">Let’s Talk About Your Next Build!</h2>
											</div>
										</div>
										<div class="elementor-element elementor-element-caba5b3 elementor-widget__width-initial elementor-widget-tablet__width-inherit elementor-widget elementor-widget-text-editor" data-id="caba5b3" data-element_type="widget" data-widget_type="text-editor.default">
											<div class="elementor-widget-container">
												<p>Fill out the form, give us a call, or stop by our office in Austin. Let’s start building something great together.</p>
											</div>
										</div>
										<div class="elementor-element elementor-element-7bc51c3 e-con-full e-flex e-con e-child" data-id="7bc51c3" data-element_type="container">
											<div class="elementor-element elementor-element-da3cf49 elementor-view-default elementor-widget elementor-widget-icon" data-id="da3cf49" data-element_type="widget" data-widget_type="icon.default">
												<div class="elementor-widget-container">
													<div class="elementor-icon-wrapper">
														<div class="elementor-icon">
															<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 60 60" fill="none">
																<g clip-path="url(#clip0_2072_1161)">
																	<path d="M30 60C46.5685 60 60 46.5685 60 30C60 13.4315 46.5685 0 30 0C13.4315 0 0 13.4315 0 30C0 46.5685 13.4315 60 30 60Z" fill="#5C5560"></path>
																	<path d="M30 60C46.5685 60 60 46.5685 60 30C60 13.4315 46.5685 0 30 0C13.4315 0 0 13.4315 0 30C0 46.5685 13.4315 60 30 60Z" fill="#EEEEEE"></path>
																	<path d="M55.8967 25.0762H44.8789H30.5794V35.5032H44.6732C43.4047 38.889 40.9962 41.7174 37.9146 43.5247C35.5932 44.8874 32.8879 45.668 30.0002 45.668C23.2821 45.668 17.5515 41.4392 15.3256 35.4987C14.6826 33.7884 14.3322 31.9347 14.3322 29.9999C14.3322 28.2172 14.6305 26.504 15.178 24.9081C17.2922 18.7547 23.1301 14.332 30.0002 14.332C33.0428 14.332 35.8828 15.1994 38.2853 16.7013L46.824 9.7108C42.2592 5.92095 36.3955 3.64294 30.0002 3.64294C19.8137 3.64294 10.9768 9.42123 6.5901 17.8788C4.70596 21.5078 3.64307 25.6293 3.64307 30.0001C3.64307 34.5199 4.7799 38.7732 6.78428 42.4907C11.236 50.7468 19.9628 56.3572 30.0002 56.3572C36.2462 56.3572 41.984 54.185 46.5009 50.5543C51.1453 46.8208 54.4978 41.5451 55.781 35.5032C56.159 33.7277 56.3573 31.887 56.3573 30.0001C56.3573 28.3172 56.1994 26.6706 55.8967 25.0762Z" fill="#FBBB00"></path>
																	<path d="M46.4994 50.5528L46.5009 50.5543C41.9839 54.1849 36.2462 56.3571 30.0001 56.3571C19.9627 56.3571 11.2359 50.7469 6.78418 42.4907L15.3256 35.4988C17.5515 41.4392 23.282 45.6681 30.0002 45.6681C32.8879 45.6681 35.5932 44.8875 37.9146 43.5247L46.4994 50.5528Z" fill="#28B446"></path>
																	<path d="M55.8965 25.0762C56.1992 26.6706 56.3571 28.3172 56.3571 30C56.3571 31.887 56.1587 33.7277 55.7807 35.5032C54.4977 41.545 51.145 46.8208 46.5007 50.5543L46.4991 50.5527L37.9142 43.5247C40.996 41.7173 43.4043 38.8889 44.6729 35.5032H30.5791V25.0762H44.8787H55.8965Z" fill="#518EF8"></path>
																	<path d="M46.8236 9.71091L38.2851 16.7014C35.8825 15.1995 33.0427 14.3321 29.9999 14.3321C23.1297 14.3321 17.292 18.7549 15.1777 24.9083L6.59137 17.8788H6.58984C10.9765 9.42123 19.8133 3.64294 29.9999 3.64294C36.3952 3.64294 42.2589 5.92095 46.8236 9.71091Z" fill="#FC3F1D"></path>
																</g>
																<defs>
																	<clipPath id="clip0_2072_1161">
																		<rect width="60" height="60" fill="white"></rect>
																	</clipPath>
																</defs>
															</svg>
														</div>
													</div>
												</div>
											</div>
											<div class="elementor-element elementor-element-c08bc76 e-con-full e-flex e-con e-child" data-id="c08bc76" data-element_type="container">
												<div class="elementor-element elementor-element-284ea04 elementor-widget-mobile__width-initial elementor-widget elementor-widget-rating" data-id="284ea04" data-element_type="widget" data-widget_type="rating.default">
													<div class="elementor-widget-container">
														<div class="e-rating" itemtype="https://schema.org/Rating" itemscope="" itemprop="reviewRating">
															<meta itemprop="worstRating" content="0">
															<meta itemprop="bestRating" content="5">
															<div class="e-rating-wrapper" itemprop="ratingValue" content="5" role="img" aria-label="Rated 5 out of 5">
																<div class="e-icon">
																	<div class="e-icon-wrapper e-icon-marked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																	<div class="e-icon-wrapper e-icon-unmarked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																</div>
																<div class="e-icon">
																	<div class="e-icon-wrapper e-icon-marked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																	<div class="e-icon-wrapper e-icon-unmarked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																</div>
																<div class="e-icon">
																	<div class="e-icon-wrapper e-icon-marked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																	<div class="e-icon-wrapper e-icon-unmarked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																</div>
																<div class="e-icon">
																	<div class="e-icon-wrapper e-icon-marked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																	<div class="e-icon-wrapper e-icon-unmarked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																</div>
																<div class="e-icon">
																	<div class="e-icon-wrapper e-icon-marked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																	<div class="e-icon-wrapper e-icon-unmarked">
																		<svg aria-hidden="true" class="e-font-icon-svg e-eicon-star" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg">
																			<path d="M450 75L338 312 88 350C46 354 25 417 58 450L238 633 196 896C188 942 238 975 275 954L500 837 725 954C767 975 813 942 804 896L763 633 942 450C975 417 954 358 913 350L663 312 550 75C529 33 471 33 450 75Z"></path>
																		</svg>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-fe9d6d7 elementor-widget-mobile__width-initial elementor-widget elementor-widget-text-editor" data-id="fe9d6d7" data-element_type="widget" data-widget_type="text-editor.default">
													<div class="elementor-widget-container">
														<p>260+ reviews (4.95 of 5)</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vishu\resources\views/website/contact.blade.php ENDPATH**/ ?>