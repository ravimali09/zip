<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
            <div class='footer-width-fixer'>
                <div data-elementor-type="wp-post" data-elementor-id="536" class="elementor elementor-536">
                    <div class="elementor-element elementor-element-aae073a e-flex e-con-boxed e-con e-parent" data-id="aae073a" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                        <div class="e-con-inner">
                            <div class="elementor-element elementor-element-a868966 e-con-full e-flex e-con e-child" data-id="a868966" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                <div class="elementor-element elementor-element-775830b e-grid e-con-full e-con e-child" data-id="775830b" data-element_type="container">
                                    <div class="elementor-element elementor-element-733bd64 e-con-full e-flex e-con e-child" data-id="733bd64" data-element_type="container">
                                        <div class="elementor-element elementor-element-2d315a2 elementor-widget elementor-widget-text-editor" data-id="2d315a2" data-element_type="widget" data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <p>Ready to Start Your Project?</p>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-75e2b65 elementor-widget__width-initial elementor-widget elementor-widget-heading" data-id="75e2b65" data-element_type="widget" data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h3 class="elementor-heading-title elementor-size-default">From Idea to Reality, Let’s Begin</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-e4bd526 elementor-widget elementor-widget-uael-infobox" data-id="e4bd526" data-element_type="widget" data-widget_type="uael-infobox.default">
                                        <div class="elementor-widget-container">

                                            <div class="uael-module-content uael-infobox uael-imgicon-style-normal  uael-infobox-left  infobox-has-icon uael-infobox-icon-above-title  uael-infobox-link-type-button">
                                                <div class="uael-infobox-left-right-wrap">
                                                    <div class="uael-infobox-content">
                                                        <div class="uael-module-content uael-imgicon-wrap ">
                                                        </div>
                                                        <div class='uael-infobox-title-wrap'></div>
                                                        <div class="uael-infobox-text-wrap">
                                                            <div class="uael-infobox-text elementor-inline-editing" data-elementor-setting-key="infobox_description" data-elementor-inline-editing-toolbar="advanced">
                                                                Your home is more than just four walls; it’s a reflection of your lifestyle, your values, and your dreams. At Vishu Real Estate, we’re here to turn those dreams into spaces you’ll be proud to call your own.</div>

                                                            <div class="uael-button-wrapper elementor-widget-button">
                                                                <a href="#" class="elementor-button-link  elementor-button elementor-size-sm">
                                                                    <span class="elementor-button-content-wrapper">
                                                                        <span class="elementor-align-icon-right elementor-button-icon">
                                                                        </span>

                                                                        <span class="elementor-button-text elementor-inline-editing" data-elementor-setting-key="infobox_button_text" data-elementor-inline-editing-toolbar="none">Let’s Talk</span>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-2db1636 e-con-full e-flex e-con e-child" data-id="2db1636" data-element_type="container">
                                <div class="elementor-element elementor-element-d649689 e-con-full e-flex e-con e-child" data-id="d649689" data-element_type="container">
                                    <div class="elementor-element elementor-element-4d11490 e-con-full e-flex e-con e-child" data-id="4d11490" data-element_type="container">
                                        <div class="elementor-element elementor-element-83d26f8 elementor-widget elementor-widget-image" data-id="83d26f8" data-element_type="widget" data-widget_type="image.default">
                                            <div>
                                                <h5 style="color: white;">Vishu Real Estate</h5>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-8d57348 elementor-widget__width-initial elementor-widget-tablet__width-inherit elementor-widget elementor-widget-icon-box" data-id="8d57348" data-element_type="widget" data-widget_type="icon-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-box-wrapper">


                                                    <div class="elementor-icon-box-content">


                                                        <p class="elementor-icon-box-description">
                                                          At Vishu Real Estate, we are committed to turning your property dreams into reality with trust, transparency, and excellence.
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-48336a8 e-con-full e-flex e-con e-child" data-id="48336a8" data-element_type="container">
                                            <div class="elementor-element elementor-element-a53eb8c elementor-view-default elementor-widget elementor-widget-icon" data-id="a53eb8c" data-element_type="widget" data-widget_type="icon.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-wrapper">
                                                        <div class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fab-facebook" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-001e960 elementor-view-default elementor-widget elementor-widget-icon" data-id="001e960" data-element_type="widget" data-widget_type="icon.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-wrapper">
                                                        <div class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-3886a43 elementor-view-default elementor-widget elementor-widget-icon" data-id="3886a43" data-element_type="widget" data-widget_type="icon.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-wrapper">
                                                        <div class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fab-youtube" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-dcea67c elementor-view-default elementor-widget elementor-widget-icon" data-id="dcea67c" data-element_type="widget" data-widget_type="icon.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-icon-wrapper">
                                                        <div class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fab-x-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-75227e7 e-grid e-con-full e-con e-child" data-id="75227e7" data-element_type="container">
                                    <div class="elementor-element elementor-element-793e908 e-con-full e-flex e-con e-child" data-id="793e908" data-element_type="container">
                                        <div class="elementor-element elementor-element-6f4c998 elementor-widget elementor-widget-heading" data-id="6f4c998" data-element_type="widget" data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h6 class="elementor-heading-title elementor-size-default">Company</h6>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-d669d17 uael-nav-menu__breakpoint-none uael-nav-menu__align-left uael-submenu-icon-arrow uael-link-redirect-child elementor-widget elementor-widget-uael-nav-menu" data-id="d669d17" data-element_type="widget" data-widget_type="uael-nav-menu.default">
                                            <div class="elementor-widget-container">
                                                <div class="uael-nav-menu uael-layout-vertical uael-nav-menu-layout" data-layout="vertical">
                                                    <div role="button" class="uael-nav-menu__toggle elementor-clickable">
                                                        <span class="screen-reader-text">Main Menu</span>
                                                        <div class="uael-nav-menu-icon">
                                                        </div>
                                                    </div>
                                                    <nav class="uael-nav-menu__layout-vertical uael-nav-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                        <ul id="menu-1-d669d17" class="uael-nav-menu">
                                                            <li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-6 current_page_item parent uael-creative-menu"><a href="{{route('index')}}" class="uael-menu-item">Home</a></li>
                                                            <li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="{{route('about')}}" class="uael-menu-item">About</a></li>
                                                            <li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="{{route('services')}}" class="uael-menu-item">Services</a></li>
                                                            <li id="menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="{{route('projects')}}" class="uael-menu-item">Projects</a></li>
                                                            <li id="menu-item-32" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="#" class="uael-menu-item">Contact</a></li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-9d29921 e-con-full e-flex e-con e-child" data-id="9d29921" data-element_type="container">
                                        <div class="elementor-element elementor-element-7e24f24 elementor-widget elementor-widget-heading" data-id="7e24f24" data-element_type="widget" data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h6 class="elementor-heading-title elementor-size-default">Support</h6>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-f570ce2 uael-nav-menu__breakpoint-none uael-nav-menu__align-left uael-submenu-icon-arrow uael-link-redirect-child elementor-widget elementor-widget-uael-nav-menu" data-id="f570ce2" data-element_type="widget" data-widget_type="uael-nav-menu.default">
                                            <div class="elementor-widget-container">
                                                <div class="uael-nav-menu uael-layout-vertical uael-nav-menu-layout" data-layout="vertical">
                                                    <div role="button" class="uael-nav-menu__toggle elementor-clickable">
                                                        <span class="screen-reader-text">Main Menu</span>
                                                        <div class="uael-nav-menu-icon">
                                                        </div>
                                                    </div>
                                                    <nav class="uael-nav-menu__layout-vertical uael-nav-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                        <ul id="menu-1-f570ce2" class="uael-nav-menu">
                                                            <li id="menu-item-546" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="#" class="uael-menu-item">Blog</a></li>
                                                            <li id="menu-item-544" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="#" class="uael-menu-item">Testimonials</a></li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-45d3aef e-con-full e-flex e-con e-child" data-id="45d3aef" data-element_type="container">
                                        <div class="elementor-element elementor-element-85c0fed elementor-widget elementor-widget-heading" data-id="85c0fed" data-element_type="widget" data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h6 class="elementor-heading-title elementor-size-default">Contact Us</h6>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-0960167 elementor-view-stacked elementor-position-left elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="0960167" data-element_type="widget" data-widget_type="icon-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-box-wrapper">

                                                    <div class="elementor-icon-box-icon">
                                                        <span class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fas-phone-alt" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z"></path>
                                                            </svg> </span>
                                                    </div>

                                                    <div class="elementor-icon-box-content">

                                                        <div class="elementor-icon-box-title">
                                                            <span>
                                                                Call us </span>
                                                        </div>

                                                        <p class="elementor-icon-box-description">+91 1234567890 </p>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-33205a8 elementor-view-stacked elementor-position-left elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="33205a8" data-element_type="widget" data-widget_type="icon-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-box-wrapper">

                                                    <div class="elementor-icon-box-icon">
                                                        <span class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fas-envelope" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                                            </svg> </span>
                                                    </div>

                                                    <div class="elementor-icon-box-content">

                                                        <div class="elementor-icon-box-title">
                                                            <span>
                                                                Send Email </span>
                                                        </div>
                                                        <p class="elementor-icon-box-description">vishurealestate@gmail.com</p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-c321ef2 elementor-view-stacked elementor-position-left elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="c321ef2" data-element_type="widget" data-widget_type="icon-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-box-wrapper">

                                                    <div class="elementor-icon-box-icon">
                                                        <span class="elementor-icon">
                                                            <svg aria-hidden="true" class="e-font-icon-svg e-fas-location-arrow" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M444.52 3.52L28.74 195.42c-47.97 22.39-31.98 92.75 19.19 92.75h175.91v175.91c0 51.17 70.36 67.17 92.75 19.19l191.9-415.78c15.99-38.39-25.59-79.97-63.97-63.97z"></path>
                                                            </svg> </span>
                                                    </div>

                                                    <div class="elementor-icon-box-content">

                                                        <div class="elementor-icon-box-title">
                                                            <span>
                                                                Address </span>
                                                        </div>

                                                        <p class="elementor-icon-box-description">
                                                            Ahmedabad, Gujarat, India
                                                        </p>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-a28a25e e-con-full e-flex e-con e-child" data-id="a28a25e" data-element_type="container">
                                <div class="elementor-element elementor-element-b7645fb elementor-widget elementor-widget-text-editor" data-id="b7645fb" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p>© {{date('Y')}} Copyright by Vishu Real Estate</p>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-221d335 uael-nav-menu__breakpoint-none elementor-widget-mobile__width-inherit uael-nav-menu__align-left uael-submenu-open-hover uael-submenu-icon-arrow uael-submenu-animation-none uael-link-redirect-child elementor-widget elementor-widget-uael-nav-menu" data-id="221d335" data-element_type="widget" data-settings="{&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="uael-nav-menu.default">
                                    <div class="elementor-widget-container">
                                        <div class="uael-nav-menu uael-layout-horizontal uael-nav-menu-layout uael-pointer__none" data-layout="horizontal">
                                            <div role="button" class="uael-nav-menu__toggle elementor-clickable">
                                                <span class="screen-reader-text">Main Menu</span>
                                                <div class="uael-nav-menu-icon">
                                                </div>
                                            </div>
                                            <nav class="uael-nav-menu__layout-horizontal uael-nav-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                <ul id="menu-1-221d335" class="uael-nav-menu">
                                                    <li id="menu-item-559" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="#" class="uael-menu-item">Privacy Policy</a></li>
                                                    <li id="menu-item-558" class="menu-item menu-item-type-post_type menu-item-object-page parent uael-creative-menu"><a href="#" class="uael-menu-item">Terms &amp; Condition</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <div id="ast-scroll-top" tabindex="0" class="ast-scroll-top-icon ast-scroll-to-top-right" data-on-devices="both">
        <span class="ast-icon icon-arrow"><svg class="ast-arrow-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z" />
            </svg></span> <span class="screen-reader-text">Scroll to Top</span>
    </div>
    
    <div id="showcase-cta-entry-root" class="st-customizer-cta st-section-root"></div>
            <script id="astra-theme-js-js-extra">
    var astra = {
        "break_point": "921",
        "isRtl": "",
        "is_scroll_to_id": "1",
        "is_scroll_to_top": "1",
        "is_header_footer_builder_active": "1",
        "responsive_cart_click": "flyout",
        "is_dark_palette": "",
        "revealEffectEnable": "",
        "edit_post_url": "https:\/\/websitedemos.net\/brikly-construction-company-04\/wp-admin\/post.php?post=id&action=edit",
        "ajax_url": "https:\/\/websitedemos.net\/brikly-construction-company-04\/wp-admin\/admin-ajax.php",
        "infinite_count": "2",
        "infinite_total": "0",
        "pagination": "number",
        "infinite_scroll_event": "scroll",
        "no_more_post_message": "No more posts to show.",
        "grid_layout": {
            "desktop": 3,
            "tablet": 2,
            "mobile": 1
        },
        "site_url": "https:\/\/websitedemos.net\/brikly-construction-company-04",
        "blogArchiveTitleLayout": "layout-2",
        "blogArchiveTitleOn": "1",
        "show_comments": "Show Comments",
        "masonryEnabled": "",
        "blogMasonryBreakPoint": "0"
    };
</script>
<script src="https://websitedemos.net/brikly-construction-company-04/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=4.11.10" id="astra-theme-js-js"></script>

</body>

</html>