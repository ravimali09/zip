<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\FoodController;



Route::get('/', [WebController::class, 'index'])->name('index');
Route::get('/index', [WebController::class, 'index'])->name('index');
Route::get('/about', [WebController::class, 'about'])->name('about');
Route::get('/service', [WebController::class, 'service'])->name('service');
Route::get('/menu', [WebController::class, 'menu'])->name('menu');
Route::get('/contact', [WebController::class, 'contact'])->name('contact');
Route::post('/contact', [WebController::class, 'store'])->name('store');
Route::get('/login', [CustomerController::class, 'login'])->name('login');
Route::get('/signup', [CustomerController::class, 'signup'])->name('signup');


Route::get('/admin-login', [AdminController::class, 'AdminLogin'])->name('admin_login');
Route::post('/admin-logincheck', [AdminController::class, 'AdminLoginCheck'])->name('admin_logincheck');
Route::get('/admin-logout', [AdminController::class, 'AdminLogout'])->name('admin_logout');

//Protected routes (only after login)
    Route::get('/admin/index', [AdminController::class, 'dashboard'])->name('admin_index');

    // Food management routes
    Route::get('/admin/food/add', [FoodController::class, 'AddFood'])->name('admin_add_food');
    Route::get('/admin/food/manage', [FoodController::class, 'ManageFood'])->name('admin_manage_food');
    Route::post('/admin/food/', [FoodController::class, 'FoodStore'])->name('food.store');
    Route::delete('/admin/food/delete/{id}', [FoodController::class, 'DeleteFood'])->name('food.delete');
    Route::get('/admin/food/edit/{id}', [FoodController::class, 'EditFood'])->name('food.edit');
    Route::put('/admin/food/update/{id}', [FoodController::class, 'UpdateFood'])->name('food.update');