<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">

        <!-- dashboard -->
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin_index')); ?>">
                <i class="typcn typcn-device-desktop menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>

        <!-- Food Management -->
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <i class="fas fa-hamburger me-3"></i>
                <span class="menu-title"> Food Management</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">                        
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin_add_food')); ?>">Add Food</a></li>
                    <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin_manage_food')); ?>">Manage Food</a></li>
                </ul>
            </div>
        </li>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>