<?php echo $__env->make('website.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container-xxl py-5 bg-dark hero-header mb-5">
    <div class="container my-5 py-5">
        <div class="row align-items-center g-5">
            <div class="col-lg-6 text-center text-lg-start">
                <h1 class="display-3 text-white animated slideInLeft">Where Every Bite is a Delight!</h1>
                <p class="text-white animated slideInLeft mb-4 pb-2">Savor the flavors of freshly made dishes, crafted with love and care. From quick bites to full-course meals, we bring you the best dining experience at your fingertips.
                </p>
            </div>
            <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                <img class="img-fluid" src="<?php echo e(url('website/img/hero.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
</div>
<!-- Navbar & Hero End -->


<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-user-tie text-primary mb-4"></i>
                        <h5>Master Chefs</h5>
                        <p>Our chefs are culinary artists, bringing years of expertise and passion to every dish we serve.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-utensils text-primary mb-4"></i>
                        <h5>Quality Food</h5>
                        <p>We use only the freshest ingredients to craft meals that are both delicious and wholesome.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-cart-plus text-primary mb-4"></i>
                        <h5>Online Order</h5>
                        <p>Enjoy the convenience of seamless online ordering with just a few clicks from your home.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-headset text-primary mb-4"></i>
                        <h5>24/7 Service</h5>
                        <p>Craving something late at night? We’re here round the clock to serve you anytime, anywhere.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->


<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6 text-start">
                        <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.1s" src="<?php echo e(url('website/img/about-1.jpg')); ?>">
                    </div>
                    <div class="col-6 text-start">
                        <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.3s" src="<?php echo e(url('website/img/about-2.jpg')); ?>" style="margin-top: 25%;">
                    </div>
                    <div class="col-6 text-end">
                        <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.5s" src="<?php echo e(url('website/img/about-3.jpg')); ?>">
                    </div>
                    <div class="col-6 text-end">
                        <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.7s" src="<?php echo e(url('website/img/about-4.jpg')); ?>">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <h5 class="section-title ff-secondary text-start text-primary fw-normal">About Us</h5>
                <h1 class="mb-4">Welcome to <img src="<?php echo e(url('website/img/logo.png')); ?>" style="height: 100px;" alt="">Food Hub</h1>
                <p class="mb-4">At Food Hub, we believe that great food brings people together. Our passion lies in crafting delicious meals that combine fresh ingredients, bold flavors, and a touch of love in every dish.
                    .</p>
                <p class="mb-4">With a perfect blend of tradition and innovation, we aim to deliver an unforgettable dining experience. Whether you're ordering online, dining in, or booking a table for your special occasions, Food Hub is here to make every moment flavorful.
                    .</p>
                <div class="row g-4 mb-4">
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center border-start border-5 border-primary px-3">
                            <h1 class="flex-shrink-0 display-5 text-primary mb-0" data-toggle="counter-up">5</h1>
                            <div class="ps-4">
                                <p class="mb-0">Years of</p>
                                <h6 class="text-uppercase mb-0">Experience</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center border-start border-5 border-primary px-3">
                            <h1 class="flex-shrink-0 display-5 text-primary mb-0" data-toggle="counter-up">10</h1>
                            <div class="ps-4">
                                <p class="mb-0">Popular</p>
                                <h6 class="text-uppercase mb-0">Master Chefs</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About End -->

<!-- Contact Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h5 class="section-title ff-secondary text-center text-primary fw-normal">Contact Us</h5>
            <h1 class="mb-5">Contact For Any Query</h1>
        </div>
        <div class="row g-4">
            
            <div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
                <img src="<?php echo e(url('website/img/contact.jfif')); ?>" alt="" style="width: 100%;">
            </div>
            <div class="col-md-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <form method="post" action="<?php echo e(route('store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="name" placeholder="Your Name"
                                        name="name" value="<?php echo e(old('name')); ?>">
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="email" placeholder="Your Email"
                                        name="email" value="<?php echo e(old('email')); ?>">
                                    <label for="email">Your Email</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating">
                                    <input type="mobile" class="form-control" id="mobile" placeholder="Mobile Number"
                                        name="mobile" value="<?php echo e(old('mobile')); ?>">
                                    <label for="mobile">Mobile Number</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="subject" placeholder="Subject"
                                        name="subject" value="<?php echo e(old('subject')); ?>">
                                    <label for="subject">Subject</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a message here" id="message" style="height: 150px"
                                        name="message"><?php echo e(old('message')); ?></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show text-center reg_success" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Contact End -->


<!-- Testimonial Start -->
<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="text-center">
            <h5 class="section-title ff-secondary text-center text-primary fw-normal">Testimonial</h5>
            <h1 class="mb-5">Our Clients Say!!!</h1>
        </div>
        <div class="owl-carousel testimonial-carousel">
            <div class="testimonial-item bg-transparent border rounded p-4">
                <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
                <p>I’ve tried many platforms, but Food Hub stands out. The food always arrives hot, fresh, and
                    packed with flavor. Highly recommended</p>
                <div class="d-flex align-items-center">
                    <!-- <img class="img-fluid flex-shrink-0 rounded-circle" src="<?php echo e(url('website/img/testimonial-1.jpg')); ?>" -->
                    <!-- style="width: 50px; height: 50px;"> -->
                    <div class="ps-3">
                        <h5 class="mb-1">Shivangi D.</h5>
                        <!-- <small>Profession</small> -->
                    </div>
                </div>
            </div>
            <div class="testimonial-item bg-transparent border rounded p-4">
                <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
                <p>Honestly, I was surprised by how delicious everything was. Delivery was quicker than expected, and
                    the portions were generous.</p>
                <div class="d-flex align-items-center">
                    <!-- <img class="img-fluid flex-shrink-0 rounded-circle" src="<?php echo e(url('website/img/testimonial-2.jpg')); ?>" -->
                    <!-- style="width: 50px; height: 50px;"> -->
                    <div class="ps-3">
                        <h5 class="mb-1">Rohan S.</h5>
                        <!-- <small></small> -->
                    </div>
                </div>
            </div>
            <div class="testimonial-item bg-transparent border rounded p-4">
                <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
                <p>I’ve tried multiple platform, but none compare to Food Hub. Great variety, smooth web app
                    experience, and top-notch food quality</p>
                <div class="d-flex align-items-center">
                    <!-- <img class="img-fluid flex-shrink-0 rounded-circle" src="<?php echo e(url('website/img/testimonial-3.jpg')); ?>"
                        style="width: 50px; height: 50px;"> -->
                    <div class="ps-3">
                        <h5 class="mb-1">Ayesha A.</h5>
                        <!-- <small>Profession</small> -->
                    </div>
                </div>
            </div>
            <div class="testimonial-item bg-transparent border rounded p-4">
                <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
                <p>Food Hub is my new favorite! Easy to use, great variety, and the meals taste just like homemade.</p>
                <div class="d-flex align-items-center">
                    <!-- <img class="img-fluid flex-shrink-0 rounded-circle" src="<?php echo e(url('website/img/testimonial-4.jpg')); ?>"
                        style="width: 50px; height: 50px;"> -->
                    <div class="ps-3">
                        <h5 class="mb-1">Imran S.</h5>
                        <!-- <small>Profession</small> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial End -->


<?php echo $__env->make('website.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script>
    $(document).ready(function() {
        $('.home').addClass('active');
    })
</script><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/website/index.blade.php ENDPATH**/ ?>