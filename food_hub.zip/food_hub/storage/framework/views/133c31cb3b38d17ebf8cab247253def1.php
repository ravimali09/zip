<footer class="footer">
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y'); ?> <a href="<?php echo e(route('admin_index')); ?>" class="text-muted" target="_blank">Food Hub</a>. All rights reserved.</span>
            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->

<!-- base:js -->
<script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="<?php echo e(asset('admin/assets/vendors/chart.js/chart.umd.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.cookie.js')); ?>"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
<!-- End custom js for this page--><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>