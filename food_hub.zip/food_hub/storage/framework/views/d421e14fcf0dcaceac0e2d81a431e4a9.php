<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container-fluid page-body-wrapper"> 

        <!-- left sildebar start-->
        <?php echo $__env->make('admin.layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- left sidebar end -->

        <!-- center contect -->
        <div class="main-panel">
            <div class="content-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success_msg">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h2>Dashboard Comming Soon</h2>
            </div>

            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                setTimeout(function() {
                    $("#success_msg").fadeOut("slow");
                }, 2000); // 2000ms = 2 seconds
            </script>
        <!-- content-wrapper ends -->

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>  
<!-- footer start-->
</body>
</html><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/admin/index.blade.php ENDPATH**/ ?>