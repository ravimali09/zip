<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Food Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/typicons/typicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/food-logo.png')); ?>" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-scroller">
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="<?php echo e(route('admin_index')); ?>">
                        <img src="<?php echo e(asset('admin/assets/images/food-logo.png')); ?>" style="width: 63px !important; height: 80px !important;" alt="logo" />
                    </a>
                    <a class="navbar-brand brand-logo-mini" href="<?php echo e(route('admin_index')); ?>">
                        <img src="<?php echo e(asset('admin/assets/images/food-logo.png')); ?>" style="width: 63px !important; height: 80px !important;" alt="logo" />
                    </a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                        <span class="typcn typcn-th-menu"></span>
                    </button>
                </div>
            </div>

            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav me-lg-2">
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="<?php echo e(asset('admin/assets/images/faces/face5.jpg')); ?>" alt="profile" />
                            <span class="nav-profile-name"><?php echo e(session('admin_name')); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a href="<?php echo e(route('admin_logout')); ?>" class="dropdown-item">
                                <i class="typcn typcn-eject text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                </ul>

                <ul class="navbar-nav navbar-nav-right">

                    <!-- show date -->
                    <li class="nav-item nav-date dropdown">
                        <a class="nav-link d-flex justify-content-center align-items-center" href="javascript:;">
                            <h6 class="date mb-0">Today : <?php echo e(\Carbon\Carbon::now()->format('M d')); ?></h6>
                            <i class="typcn typcn-calendar"></i>
                        </a>
                    </li>


                    <!-- Notifications -->
                    <li class="nav-item dropdown me-0">
                        <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center"
                            id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="typcn typcn-bell mx-0"></i>
                            <span class="count"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-end navbar-dropdown p-2"
                            aria-labelledby="notificationDropdown" style="width: 320px;">

                            <!-- Heading -->
                            <p class="mb-2 fw-bold">Notifications</p>

                            <!-- Notification List -->
                            <div class="list-group overflow-auto" style="max-height: 40vh; overflow-x: hidden;">
                                <?php for($i = 1; $i <= 10; $i++): ?>
                                <a href="#" class="list-group-item list-group-item-action d-flex align-items-center">

                                <!-- Small Green Circle with Icon -->
                                <div class="rounded-circle bg-success d-flex align-items-center justify-content-center me-3"
                                    style="width: 28px; height: 28px;">
                                    <i class="typcn typcn-info text-white" style="font-size:14px;"></i>
                                </div>

                                <div>
                                    <div class="fw-semibold">login notification</div>
                                    <small class="text-muted">
                                        2 days ago
                                    </small>
                                </div>
                                </a>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                    <span class="typcn typcn-th-menu"></span>
                </button>
            </div>
        </nav><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>