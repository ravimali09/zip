     <?php echo $__env->make('website.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <style>
         .pagination {
             flex-wrap: wrap;
             justify-content: center;
         }

         .page-item .page-link {
             min-width: 36px;
             text-align: center;
             padding: 6px 10px;
         }

         .fixed-size-img {
             width: 120px;
             height: 120px;
             object-fit: cover;
         }

         @media (max-width: 768px) {
             .fixed-size-img {
                 width: 100%;
                 height: 200px;
             }
         }
     </style>
     <div class="container-xxl py-5 bg-dark hero-header mb-5">
         <div class="container text-center my-5 pt-5 pb-4">
             <h1 class="display-3 text-white mb-3 animated slideInDown">Food Menu</h1>
             <nav aria-label="breadcrumb">
                 <ol class="breadcrumb justify-content-center text-uppercase">
                     <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                     <li class="breadcrumb-item"><a href="#">Pages</a></li>
                     <li class="breadcrumb-item text-white active" aria-current="page">Menu</li>
                 </ol>
             </nav>
         </div>
     </div>
     </div>
     <!-- Navbar & Hero End -->


     <!-- Menu Start -->
     <div class="container-xxl py-5">
         <div class="container">
             <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                 <h5 class="section-title ff-secondary text-center text-primary fw-normal">Food Menu</h5>
                 <h1 class="mb-5">Most Popular Items</h1>
             </div>
             <div class="tab-class text-center wow fadeInUp" data-wow-delay="0.1s">

                 <div class="tab-content">
                     <div id="tab-1" class="tab-pane fade show p-0 active">
                         <div class="row g-4">
                             <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="col-lg-6 col-md-6 col-sm-12">
                                 <div class="border rounded p-2 h-100 d-flex flex-column flex-md-row align-items-stretch">
                                     <!-- Food Image -->
                                     <div class="flex-shrink-0 text-center mb-3 mb-md-0">
                                         <img class="img-fluid rounded fixed-size-img"
                                             src="<?php echo e(asset('uploads/' . $food->food_image)); ?>"
                                             alt="<?php echo e($food->food_name); ?>">
                                     </div>

                                     <!-- Food Details -->
                                     <div class="w-100 d-flex flex-column text-start ps-md-4">
                                         <h5 class="d-flex justify-content-between border-bottom pb-2">
                                             <span><?php echo e($food->food_name); ?></span>
                                             <span class="text-primary">₹<?php echo e($food->food_price); ?></span>
                                         </h5>
                                         <small class="fst-italic mb-2"><?php echo e($food->food_description); ?></small>

                                         <!-- Quantity + Add to Cart -->
                                         <div class="d-flex align-items-center mt-auto">
                                             <div class="input-group input-group-sm w-50 me-2">
                                                 <button class="btn btn-outline-secondary btn-sm" type="button" onclick="decreaseQty(this)">
                                                     <i class="fa fa-minus"></i>
                                                 </button>
                                                 <input type="number" class="form-control text-center" value="1" min="1">
                                                 <button class="btn btn-outline-secondary btn-sm" type="button" onclick="increaseQty(this)">
                                                     <i class="fa fa-plus"></i>
                                                 </button>
                                             </div>
                                             <button class="btn btn-sm btn-primary">
                                                 <i class="fa-solid fa-cart-shopping me-1"></i> Add to Cart
                                             </button>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div>

                         <!-- Pagination -->
                         <div class="d-flex justify-content-center mt-3">
                             <?php echo e($foods->links()); ?>

                         </div>
                     </div>


                 </div>
             </div>
         </div>
     </div>
     <!-- Menu End -->
     <?php echo $__env->make('website.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <script>
         $(document).ready(function() {
             $('.menu').addClass('active');
         });


         function increaseQty(button) {
             const input = button.parentElement.querySelector('input[type="number"]');
             input.stepUp();
         }

         function decreaseQty(button) {
             const input = button.parentElement.querySelector('input[type="number"]');
             if (parseInt(input.value) > 1) {
                 input.stepDown();
             }
         }
     </script><?php /**PATH C:\xampp\htdocs\food_hub\resources\views/website/menu.blade.php ENDPATH**/ ?>