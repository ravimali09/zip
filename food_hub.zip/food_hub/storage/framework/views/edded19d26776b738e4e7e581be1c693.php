<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container-fluid page-body-wrapper">
    <?php echo $__env->make('admin.layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Manage Food Menu</h2>
                <a href="<?php echo e(route('admin_add_food')); ?>" class="btn btn-primary">+ Add New Food</a>
            </div>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" id="success_msg">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table id="foods_table" class="table table-striped table-hover align-middle text-center nowrap" style="width:100%">
                            <thead class="table-primary">
                                <tr>
                                    <th>SR No</th>
                                    <th>Food Name</th>
                                    <th>Price</th>
                                    <th>Food Image</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($foods->firstItem() + $key); ?></td> <!-- correct numbering with pagination -->
                                    <td><?php echo e($food->food_name); ?></td>
                                    <td>₹<?php echo e(number_format($food->food_price,2)); ?></td>
                                    <td>
                                        <?php if($food->food_image): ?>
                                        <img src="<?php echo e(asset('uploads/foods/'.$food->food_image)); ?>" alt="Food Image" class="img-fluid rounded" style="width:80px; height:60px; object-fit:cover;">
                                        <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-start" style="white-space:normal; word-break:break-word;"><?php echo e($food->food_description); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('food.edit', $food->id)); ?>" class="btn btn-sm btn-primary mb-1 w-100">Edit</a>
                                        <form action="<?php echo e(route('food.delete', $food->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this food?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger w-100">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination links -->
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($foods->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>

        </div>

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Auto hide success message
    setTimeout(function() {
        $('#success_msg').fadeOut('slow');
    }, 3000);
});
</script>
<?php /**PATH C:\xampp\htdocs\food_hub\resources\views/admin/manage_food.blade.php ENDPATH**/ ?>