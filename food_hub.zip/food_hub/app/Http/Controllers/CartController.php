<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Food;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function index()
    {
        $customerId = session('customer_id');

        if (!$customerId) {
            return redirect()->route('login')->with('error', 'Please login to view your cart');
        }

        $cartItems = Cart::with('food')
            ->where('customer_id', $customerId)
            ->get();

        return view('website.cart', compact('cartItems'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'food_id' => 'required',
            'quantity' => 'required',
            'price' => 'required'
        ]);

        $customerId = session('customer_id');

        if (!$customerId) {
            return redirect()->route('login')->with('error', 'Please login to add items to cart');
        }

        // Food ka price database se lo
        $food = Food::findOrFail($request->food_id);
        $totalPrice = $food->food_price * $request->quantity;

        Cart::create([
            'customer_id' => $customerId,
            'food_item_id' => $request->food_id,
            'quantity' => $request->quantity,
            'price' => $totalPrice
        ]);

        return redirect()->back()->with('success', 'Item added to cart successfully!');
    }
}
