<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Food;

class FoodController extends Controller
{
    public function AddFood()
    {
        return view('admin.add_food');
    }

    public function ManageFood()
    {
        $foods = Food::paginate(5); // 5-5 records per page
        return view('admin.manage_food', compact('foods'));
    }

    public function FoodStore(Request $request)
    {
        $data = $request->only(['food_name', 'food_price', 'food_description']);

        if ($request->hasFile('food_image')) {
            $image = $request->file('food_image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->move(public_path('uploads/foods'), $imageName);
            $data['food_image'] = $imageName;
        }

        Food::create($data);

        return redirect()->back()->with('success', 'Food added successfully!');
    }

    public function EditFood($id)
    {
        $food = Food::findOrFail($id); // Fetch the food by id
        return view('admin.edit_food', compact('food'));
    }

    public function UpdateFood(Request $request, $id)
    {
        $food = Food::findOrFail($id);

        $data = $request->all();

        if ($request->hasFile('food_image')) {

            // Delete old image if exists
            if ($food->food_image && file_exists(public_path('uploads/foods/' . $food->food_image))) {
                unlink(public_path('uploads/foods/' . $food->food_image));
            }

            // Upload new image
            $image = $request->file('food_image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->move(public_path('uploads/foods'), $imageName);
            $data['food_image'] = $imageName;
        }

        $food->update($data);

        return redirect()->route('food.edit', $id)->with('success', 'Food updated successfully!');
    }

    public function DeleteFood($id)
    {
        // find food item
        $food = Food::findOrFail($id);

        // delete eixts image 
        if ($food->food_image && file_exists(public_path('uploads/foods/' . $food->food_image))) {
            unlink(public_path('uploads/foods/' . $food->food_image));
        }

        $food->delete();

        // redirect with success message
        return redirect()->back()->with('success', 'Food deleted successfully!');
    }
}
