<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AdminUser;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{

    public function AdminLogin()
    {
        return view('admin.admin_login');
    }

    public function dashboard()
    {
        return view('admin.index');
    }

    public function AdminLoginCheck(Request $request)
    {
        // Validation
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        $admin = AdminUser::where('email', $request->email)->first();

        if ($admin && $request->password === $admin->password) {

            Session::put('admin_id', $admin->id);
            Session::put('admin_name', $admin->name);

            return redirect()->route('admin_index')
                ->with('success', 'Welcome back, ' . $admin->name . '!');
        }

        // Agar galat email ya password
        return back()->withErrors([
            'email' => 'Invalid email or password.',
        ])->onlyInput('email');
    }

    public function AdminLogout()
    {
        // Session clear karna
        Session::forget('admin_id');
        Session::forget('admin_name');

        return redirect()->route('admin_login')
            ->with('success', 'You have been logged out successfully!');
    }
}