<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Food Hub | Sign Up</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="{{ asset('admin/assets/vendors/typicons/typicons.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/assets/vendors/css/vendor.bundle.base.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/assets/css/style.css') }}">
    <link rel="shortcut icon" href="{{ asset('admin/assets/images/food-logo.png') }}">
</head>

<body>
    <div class="container-scroller">
        <div class="container-fluid page-body-wrapper full-page-wrapper">
            <div class="content-wrapper d-flex align-items-center auth px-0">
                <div class="row w-100 mx-0">
                    <div class="col-lg-4 mx-auto">
                        <div class="auth-form-light text-start py-5 px-4 px-sm-5">
                            <!-- Success Message -->
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg">
                                    {{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            @endif

                            <!-- Error Message -->

                            @if(session('error'))
                                <div class="alert alert-danger alert-dismissible fade show text-center" role="alert" id="success_msg">
                                    {{ session('error') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            @endif

                            <!-- Error Message -->
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error_msg">
                                    {{ $errors->first() }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            @endif

                            <div class="brand-logo mb-4 text-center">
                                <img src="{{ asset('admin/assets/images/food-logo.png') }}" style="height: 70px; width: 60px;" alt="logo">
                            </div>

                            <h4 class="mb-3 text-center">Sign Up</h4>

                            <!-- Login Form -->
                            <form class="pt-3" method="POST" action="{{ route('signup_store') }}">
                                @csrf
                                 <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg" placeholder="Enter Name" required>
                                </div>

                                 <div class="form-group">
                                    <input type="number" name="mobile" class="form-control form-control-lg" placeholder="Enter Number" required>
                                </div>


                                <div class="form-group">
                                    <input type="email" name="email" class="form-control form-control-lg" placeholder="Enter Email" required>
                                </div>

                                <div class="form-group">
                                    <input type="password" name="password" class="form-control form-control-lg" placeholder="Enter Password" required>
                                </div>
                                <p>Already have an account? <a href="{{route('login')}}" style="text-decoration: none;">Login</a></p>

                                <div class="mt-3 d-grid gap-2">
                                    <button type="submit" class="btn btn-block btn-primary btn-lg fw-medium auth-form-btn">
                                        SIGN UP
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>

    <!-- JS -->
    <script src="{{ asset('admin/assets/vendors/js/vendor.bundle.base.js') }}"></script>
    <script src="{{ asset('admin/assets/js/off-canvas.js') }}"></script>
    <script src="{{ asset('admin/assets/js/hoverable-collapse.js') }}"></script>
    <script src="{{ asset('admin/assets/js/template.js') }}"></script>
    <script src="{{ asset('admin/assets/js/settings.js') }}"></script>
    <script src="{{ asset('admin/assets/js/todolist.js') }}"></script>
</body>
</html>
