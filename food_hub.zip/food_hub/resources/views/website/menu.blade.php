@include('website.layout.header')
<style>
    .pagination {
        flex-wrap: wrap;
        justify-content: center;
    }

    .page-item .page-link {
        min-width: 36px;
        text-align: center;
        padding: 6px 10px;
    }

    .fixed-size-img {
        width: 120px;
        height: 120px;
        object-fit: cover;
    }

    @media (max-width: 768px) {
        .fixed-size-img {
            width: 100%;
            height: 200px;
        }
    }
</style>
<div class="container-xxl py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Food Menu</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center text-uppercase">
                <li class="breadcrumb-item"><a href="{{route('index')}}">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item text-white active" aria-current="page">Menu</li>
            </ol>
        </nav>
    </div>
</div>
</div>
<!-- Navbar & Hero End -->


<!-- Menu Start -->
<div class="container-xxl py-5">
    <div class="container">


        <!-- Success Message -->
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        @endif

        <!-- Error Message -->

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert" id="success_msg">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        @endif

        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h5 class="section-title ff-secondary text-center text-primary fw-normal">Food Menu</h5>
            <h1 class="mb-5">Most Popular Items</h1>
        </div>
        <div class="tab-class text-center wow fadeInUp" data-wow-delay="0.1s">
            <div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">
                    <div class="row g-4">
                        @foreach($foods as $food)
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="border rounded p-2 h-100 d-flex flex-column flex-md-row align-items-stretch">
                                <!-- Food Image -->
                                <div class="flex-shrink-0 text-center mb-3 mb-md-0">
                                    <img class="img-fluid rounded fixed-size-img"
                                        src="{{ asset('uploads/' . $food->food_image) }}"
                                        alt="{{ $food->food_name }}">
                                </div>

                                <!-- Food Details -->
                                <div class="w-100 d-flex flex-column text-start ps-md-4">
                                    <h5 class="d-flex justify-content-between border-bottom pb-2">
                                        <span>{{ $food->food_name }}</span>
                                        <span class="text-primary">₹{{ $food->food_price }}</span>
                                    </h5>
                                    <small class="fst-italic mb-2">{{ $food->food_description }}</small>

                                    <!-- Quantity + Add to Cart -->
                                    <form action="{{ route('cart.store') }}" method="POST" class="d-flex align-items-center mt-auto">
                                        @csrf
                                        <!-- Hidden Fields -->
                                        <input type="hidden" name="food_id" value="{{ $food->id }}">
                                        <input type="hidden" name="price" value="{{ $food->food_price }}">

                                        <div class="input-group input-group-sm w-50 me-2">
                                            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="decreaseQty(this)">
                                                <i class="fa fa-minus"></i>
                                            </button>
                                            <input type="number" name="quantity" class="form-control text-center" value="1" min="1">
                                            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="increaseQty(this)">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary">
                                            <i class="fa-solid fa-cart-shopping me-1"></i> Add to Cart
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-center mt-3">
                        {{ $foods->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Menu End -->
@include('website.layout.footer')

<script>
    $(document).ready(function() {
        $('.menu').addClass('active');
    });

    function increaseQty(button) {
        const input = button.parentElement.querySelector('input[type="number"]');
        input.stepUp();
    }

    function decreaseQty(button) {
        const input = button.parentElement.querySelector('input[type="number"]');
        if (parseInt(input.value) > 1) {
            input.stepDown();
        }
    }
</script>