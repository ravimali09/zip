@include('admin.layout.header')

<div class="container-fluid page-body-wrapper">
    @include('admin.layout.sidebar')

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Edit Food</h2>
                <a href="{{ route('admin_add_food') }}" class="btn btn-primary">+ Add New Food</a>
            </div>

            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show text-center" id="success_msg">
                    {{ session('success') }}
                </div>
            @endif

            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <form id="foodForm" enctype="multipart/form-data" method="POST" action="{{ route('food.update', $food->id) }}">
                        @csrf
                        @method('PUT')

                        <!-- Food Name -->
                        <div class="mb-3">
                            <label for="food_name" class="form-label">Food Name</label>
                            <input type="text" class="form-control" id="food_name" name="food_name" value="{{ old('food_name', $food->food_name) }}" placeholder="Enter food name">
                            <div class="invalid-feedback" id="food_name_error"></div>
                        </div>

                        <!-- Food Price -->
                        <div class="mb-3">
                            <label for="food_price" class="form-label">Food Price</label>
                            <input type="number" step="0.01" class="form-control" id="food_price" name="food_price" value="{{ old('food_price', $food->food_price) }}" placeholder="Enter food price">
                            <div class="invalid-feedback" id="food_price_error"></div>
                        </div>

                        <!-- Existing Food Image -->
                        @if($food->food_image)
                            <div class="mb-3">
                                <label class="form-label">Current Food Image</label><br>
                                <img src="{{ asset('uploads/foods/'.$food->food_image) }}" alt="Food Image" class="img-fluid rounded mb-2" style="width:120px; height:80px; object-fit:cover;">
                            </div>
                        @endif

                        <!-- Food Image (Optional) -->
                        <div class="mb-3">
                            <label for="food_image" class="form-label">Change Food Image (Optional)</label>
                            <input type="file" class="form-control" id="food_image" name="food_image" accept="image/*">
                            <div class="invalid-feedback" id="food_image_error"></div>
                        </div>

                        <!-- Food Description -->
                        <div class="mb-3">
                            <label for="food_description" class="form-label">Food Description</label>
                            <textarea class="form-control" id="food_description" name="food_description" rows="4" placeholder="Enter food description">{{ old('food_description', $food->food_description) }}</textarea>
                            <div class="invalid-feedback" id="food_description_error"></div>
                        </div>

                        <a href="{{route('admin_manage_food')}}" class="btn btn-primary">Back</a>
                        <button type="submit" class="btn btn-primary">Update Food</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@include('admin.layout.footer')

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Auto hide success message
    setTimeout(function() {
        $('#success_msg').fadeOut('slow');
    }, 3000);

    $('#foodForm').submit(function(e) {
        e.preventDefault();

        // Clear previous errors
        $('.form-control').removeClass('is-invalid');
        $('#food_name_error, #food_price_error, #food_image_error, #food_description_error').text('');

        let valid = true;
        let foodName = $('#food_name').val().trim();
        let foodPrice = $('#food_price').val().trim();
        let foodImage = $('#food_image').val();
        let foodDesc = $('#food_description').val().trim();

        // Food Name Validation
        if(foodName === '') {
            $('#food_name_error').text('Food name is required.');
            $('#food_name').addClass('is-invalid');
            valid = false;
        }

        // Food Price Validation
        if(foodPrice === '') {
            $('#food_price_error').text('Food price is required.');
            $('#food_price').addClass('is-invalid');
            valid = false;
        } else if(isNaN(foodPrice) || Number(foodPrice) <= 0) {
            $('#food_price_error').text('Enter a valid price.');
            $('#food_price').addClass('is-invalid');
            valid = false;
        }

        // Food Image Validation (Optional)
        if(foodImage !== '') {
            let ext = foodImage.split('.').pop().toLowerCase();
            if($.inArray(ext, ['png','jpg','jpeg','gif']) === -1) {
                $('#food_image_error').text('Invalid image format. Only png, jpg, jpeg, gif allowed.');
                $('#food_image').addClass('is-invalid');
                valid = false;
            }
        }

        // Food Description Validation
        if(foodDesc === '') {
            $('#food_description_error').text('Food description is required.');
            $('#food_description').addClass('is-invalid');
            valid = false;
        }

        if(valid) {
            this.submit(); // submit form if all validations pass
        }
    });
});
</script>
