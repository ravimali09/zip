@include('admin.layout.header')
<div class="container-fluid page-body-wrapper">
    @include('admin.layout.sidebar')

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Manage Food Menu</h2>
                <a href="{{route('admin_add_food')}}" class="btn btn-primary">+ Add New Food</a>
            </div>

            @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" id="success_msg">
                {{ session('success') }}
            </div>
            @endif

            <div class="card shadow-sm border-0">
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table id="foods_table" class="table table-striped table-hover align-middle text-center nowrap" style="width:100%">
                            <thead class="table-primary">
                                <tr>
                                    <th>SR No</th>
                                    <th>Food Name</th>
                                    <th>Price</th>
                                    <th>Food Image</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($foods as $key => $food)
                                <tr>
                                    <td>{{ $foods->firstItem() + $key }}</td> <!-- correct numbering with pagination -->
                                    <td>{{ $food->food_name }}</td>
                                    <td>₹{{ number_format($food->food_price,2) }}</td>
                                    <td>
                                        @if($food->food_image)
                                        <img src="{{ asset('uploads/foods/'.$food->food_image) }}" alt="Food Image" class="img-fluid rounded" style="width:80px; height:60px; object-fit:cover;">
                                        @else
                                        <span class="text-muted">N/A</span>
                                        @endif
                                    </td>
                                    <td class="text-start" style="white-space:normal; word-break:break-word;">{{ $food->food_description }}</td>
                                    <td>
                                        <a href="{{ route('food.edit', $food->id) }}" class="btn btn-sm btn-primary mb-1 w-100">Edit</a>
                                        <form action="{{ route('food.delete', $food->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this food?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger w-100">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination links -->
                    <div class="d-flex justify-content-center mt-3">
                        {{ $foods->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>

        </div>

@include('admin.layout.footer')

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Auto hide success message
    setTimeout(function() {
        $('#success_msg').fadeOut('slow');
    }, 3000);
});
</script>
