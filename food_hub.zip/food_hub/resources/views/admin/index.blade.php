@include('admin.layout.header')

    <div class="container-fluid page-body-wrapper"> 

        <!-- left sildebar start-->
        @include('admin.layout.sidebar')
        <!-- left sidebar end -->

        <!-- center contect -->
        <div class="main-panel">
            <div class="content-wrapper">

                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success_msg">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <h2>Dashboard Comming Soon</h2>
            </div>

            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                setTimeout(function() {
                    $("#success_msg").fadeOut("slow");
                }, 2000); // 2000ms = 2 seconds
            </script>
        <!-- content-wrapper ends -->

@include('admin.layout.footer')  
<!-- footer start-->
</body>
</html>