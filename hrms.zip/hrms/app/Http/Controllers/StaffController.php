<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Staff;
use App\Models\BankDetail;
use App\Models\EmergencyContact;
use Illuminate\Support\Facades\Hash;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $staff = Staff::with(['BankDetail', 'EmergencyContact'])->paginate(5);

        return view('admin.staff.manage', compact('staff'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.staff.add');
    }

    public function add_activity()
    {
        return view('admin.activity.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required',
            'last_name'  => 'required',
            'email'      => 'required|email|unique:staffs',
            'password'   => 'required',
            'mobile'     => 'required',
            'image'      => 'nullable',
        ]);

        // Staff save
        $staff = new Staff;
        $staff->first_name = $request->first_name;
        $staff->last_name  = $request->last_name;
        $staff->email      = $request->email;
        $staff->password   = Hash::make($request->password);
        $staff->mobile     = $request->mobile;

        $staff->save();

        // Bank detail entry with staff_id
        BankDetail::create([
            'staff_id' => $staff->id,
        ]);

        // Emergency contact entry with staff_id
        EmergencyContact::create([
            'staff_id' => $staff->id,
        ]);

        return redirect()->route('add_staff')->with('success', 'Staff added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $staffId = base64_decode($id);
        $staff = Staff::findOrFail($staffId);

        return view('admin.staff.edit', compact('staff'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $staffId = base64_decode($id);
        $staff = Staff::findOrFail($staffId);

        $staff->first_name = $request->first_name;
        $staff->last_name  = $request->last_name;
        $staff->email      = $request->email;
        $staff->mobile     = $request->mobile;

        $staff->save();

        return redirect()->route('manage_staff')->with('success', 'Staff updated successfully.');
    }


    /**
     * Remove the specified resource from storage.
     */

    public function destroy(string $id)
    {
        $staffId = base64_decode($id);
        $staff = Staff::findOrFail($staffId);

        if (!empty($staff->image) && file_exists(public_path('uploads/staff/' . $staff->image))) {
            unlink(public_path('uploads/staff/' . $staff->image));
        }

        BankDetail::where('staff_id', $staffId)->delete();
        EmergencyContact::where('staff_id', $staffId)->delete();

        $staff->delete();

        return redirect()->route('manage_staff')->with('success', 'Staff deleted successfully.');
    }
}
