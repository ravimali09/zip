<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Leave;

class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $leaves = Leave::with('staff')->orderBy('id', 'desc')->paginate(5);

        return view('admin.leave.manage', compact('leaves'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    public function apply_for_leave()
    {
        return view('website.leave.apply');
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(Request $request)
    {
        // Validate request
        $validated = $request->validate([
            'leave_type' => 'required|in:casual,sick,half_day',
            'start_date' => 'required|date|after_or_equal:today',
            'end_date'   => 'required|date|after_or_equal:start_date',
            'reason'     => 'required|string|max:1000',
        ]);

        // Create new leave record
        $leave = new Leave;
        $leave->staff_id   = '5';
        $leave->leave_type = $request->leave_type;
        $leave->start_date = $request->start_date;
        $leave->end_date   = $request->end_date;
        $leave->reason     = $request->reason;
        $leave->status     = 'pending';

        $leave->save();

        // Redirect with success message
        return redirect()->back()->with('success', 'Leave request submitted successfully!');
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function updateStatus(Request $request, $id)
    {
        $leave = Leave::findOrFail($id);
        $leave->status = $request->status;
        $leave->admin_remark = $request->admin_remark;
        $leave->save();

        $message = $request->status == 'approved'
            ? 'Leave request approved successfully!'
            : 'Leave request rejected successfully!';

        return redirect()->back()->with('success', $message);
    }


    public function destroy($id)
    {
        $leave_id = base64_decode($id);
        Leave::findOrFail($leave_id)->delete();
        return redirect()->back()->with('success', 'Leave deleted successfully!');
    }
}
