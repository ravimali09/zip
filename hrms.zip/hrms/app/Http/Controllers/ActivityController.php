<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Activity;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $activities = Activity::paginate(5);
        return view('admin.activity.manage', compact('activities'));
    }

    /**
     * Show the form for creating a new resource.
     */

    public function create()
    {
        return view('admin.activity.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'activity_date' => 'required',
        ]);

        $activity = new Activity();
        $activity->title = $request->title;
        $activity->activity_date = $request->activity_date;
        $activity->save();

        return redirect()->back()->with('success', 'Activity added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $activityId = base64_decode($id);
        $activity = Activity::findOrFail($activityId);
        return view('admin.activity.edit', compact('activity'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $activityId = base64_decode($id);
        $request->validate([
            'title' => 'required',
            'activity_date' => 'required',
        ]);

        $activity = Activity::findOrFail($activityId);
       

        $activity->title = $request->title;
        $activity->activity_date = $request->activity_date;
        $activity->save();

        return redirect()->route('manage_activity')->with('success', 'Activity updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $activityId = base64_decode($id);
        $activity = Activity::findOrFail($activityId);

        $activity->delete();

        return redirect()->route('manage_activity')->with('success', 'Activity deleted successfully.');
    }
}
