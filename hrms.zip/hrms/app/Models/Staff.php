<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    protected $table = 'staffs';

    public function bankDetail()
    {
        return $this->hasOne(BankDetail::class, 'staff_id');
    }

    public function emergencyContact()
    {
        return $this->hasOne(EmergencyContact::class, 'staff_id');
    }

    public function leaves()
    {
        return $this->hasMany(Leave::class, 'staff_id');
    }
}
