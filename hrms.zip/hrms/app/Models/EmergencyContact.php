<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyContact extends Model
{
    protected $table = 'emergency_contacts';
    protected $fillable = ['staff_id','name','relation','mobile','alternate_mobile'];

    public function staff()
    {
        return $this->belongsTo(Staff::class, 'staff_id');
    }
}
