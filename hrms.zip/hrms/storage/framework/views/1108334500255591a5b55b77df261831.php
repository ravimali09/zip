<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper bg-white">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12 stretch-card">
                <form style="width: 100%;" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="first_name">First Name:</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" 
                               value="<?php echo e(old('first_name', $staff->first_name)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name:</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" 
                               value="<?php echo e(old('last_name', $staff->last_name)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo e(old('email', $staff->email)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="mobile">Mobile Number:</label>
                        <input type="number" class="form-control" id="mobile" name="mobile" 
                               value="<?php echo e(old('mobile', $staff->mobile)); ?>">
                    </div>
                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-info">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/staff/edit.blade.php ENDPATH**/ ?>