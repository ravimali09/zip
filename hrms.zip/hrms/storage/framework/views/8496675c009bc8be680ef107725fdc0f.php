<!-- partial:partials/_footer.html -->
       <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo e(date("Y")); ?> <a
                href="<?php echo e(route('index')); ?>" target="_blank">hrms</a>. All rights reserved.</span>
          </div>
      </footer>   
      <!-- partial -->
    </div>
    <!-- main-panel ends -->
  </div>
  <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo e(url('website/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo e(url('website/assets/vendors/chart.js/chart.umd.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(url('website/assets/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/js/template.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(url('website/assets/js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(url('website/assets/js/proBanner.js')); ?>"></script>

  <!-- End custom js for this page-->
  <script src="<?php echo e(url('website/assets/js/jquery.cookie.js')); ?>" type="text/javascript"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\hrms\resources\views/website/layout/footer.blade.php ENDPATH**/ ?>