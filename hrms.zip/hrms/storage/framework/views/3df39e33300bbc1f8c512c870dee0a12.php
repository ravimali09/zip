<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .table {
        width: 100%;
        white-space: nowrap;
    }

    .table th, .table td {
        vertical-align: middle;
        padding: 8px 12px;
        text-align: center;
    }

    .btn {
        padding: 4px 8px;
        font-size: 14px;
        white-space: nowrap;
    }
</style>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Manage Activities</h3>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Activity List</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Activity Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($activities->firstItem() + $index); ?></td>
                                <td><?php echo e($activity->title); ?></td>
                                <td><?php echo e($activity->activity_date); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit_activity', base64_encode($activity->id))); ?>" class="btn btn-success btn-sm">Edit</a>
                                    <a href="<?php echo e(route('delete_activity', base64_encode($activity->id))); ?>" 
                                    onclick="return confirm('Do you really want to delete this activity?')" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No Activities Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($activities->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/activity/manage.blade.php ENDPATH**/ ?>