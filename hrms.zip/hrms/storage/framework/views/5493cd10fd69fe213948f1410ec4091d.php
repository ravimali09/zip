<?php echo $__env->make('website.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper bg-white">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12 stretch-card">
                <form style="width: 100%;" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="leave_type">Leave Type:</label>
                        <select name="leave_type" id="leave_type" class="form-control" required>
                            <option value="">Select Type of Leave</option>
                            <option value="casual">Casual Leave</option>
                            <option value="sick">Sick Leave</option>
                            <option value="half_day">Half Day</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="start_date">Start Date:</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" 
                         required value="<?php echo e(old('start_date')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="end_date">End Date:</label>
                        <input type="date" class="form-control" id="end_date" name="end_date"
                        required value="<?php echo e(old('end_date')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="reason">Reason:</label>
                        <textarea name="reason" id="reason" class="form-control"
                        required placeholder="Enter reason"><?php echo e(old('reason')); ?></textarea>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-info">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('website.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/website/leave/apply.blade.php ENDPATH**/ ?>