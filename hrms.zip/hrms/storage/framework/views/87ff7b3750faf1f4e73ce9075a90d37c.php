<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    .table {
        width: max-content;
        min-width: 100%;
        white-space: nowrap;
    }
    .table th,
    .table td {
        vertical-align: middle;
        white-space: nowrap;
        padding: 8px 12px;
    }
    .btn {
        white-space: nowrap;
        padding: 5px 10px;
    }
</style>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Manage Leave</h3>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center reg_success" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Manage Leave</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Leave Type</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Total Days</th>
                                        <th>Reason</th>
                                        <th>Status</th>
                                        <th>Admin Remark</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($leaves->firstItem() + $index); ?></td>
                                        <td><?php echo e($leave->staff->first_name); ?> <?php echo e($leave->staff->last_name); ?></td>
                                        <td><?php echo e(ucfirst($leave->leave_type)); ?></td>
                                        <td><?php echo e($leave->start_date); ?></td>
                                        <td><?php echo e($leave->end_date); ?></td>
                                        <td>
                                            <?php echo e(\Carbon\Carbon::parse($leave->start_date)->diffInDays(\Carbon\Carbon::parse($leave->end_date)) + 1); ?> days
                                        </td>
                                        <td><?php echo e($leave->reason ?? '-'); ?></td>
                                        <td>
                                            <span class="badge 
                                                <?php if($leave->status == 'approved'): ?> bg-success 
                                                <?php elseif($leave->status == 'rejected'): ?> bg-danger 
                                                <?php else: ?> bg-warning <?php endif; ?>">
                                                <?php echo e(ucfirst($leave->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($leave->admin_remark ?? '-'); ?></td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <?php if($leave->status == 'pending'): ?>
                                                    <!-- Approve Button -->
                                                    <button class="btn btn-success btn-sm" 
                                                            onclick="openRemarkModal(<?php echo e($leave->id); ?>, 'approved')">Approve</button>

                                                    <!-- Reject Button -->
                                                    <button class="btn btn-danger btn-sm" 
                                                            onclick="openRemarkModal(<?php echo e($leave->id); ?>, 'rejected')">Reject</button>
                                                <?php endif; ?>

                                                <!-- Delete -->
                                                <a href="<?php echo e(route('delete_leave', base64_encode($leave->id))); ?>" onclick="return confirm('Do you really want to delete this leave?')" class="btn btn-danger">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">No Leave Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($leaves->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Modal for Remark -->
<div class="modal fade" id="remarkModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" id="remarkForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Leave Remark</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="status" id="leaveStatus">
                    <div class="mb-3">
                        <label class="form-label">Remark</label>
                        <textarea name="admin_remark" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function openRemarkModal(leaveId, status) {
        const form = document.getElementById('remarkForm');
        form.action = `/admin/leave/update-status/${leaveId}`; // Dynamic URL
        document.getElementById('leaveStatus').value = status;
        new bootstrap.Modal(document.getElementById('remarkModal')).show();
    }
</script>

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/leave/manage.blade.php ENDPATH**/ ?>