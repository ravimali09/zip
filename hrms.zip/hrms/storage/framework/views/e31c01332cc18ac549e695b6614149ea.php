<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper bg-white">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12 stretch-card">
                <form style="width: 100%;" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title')); ?>" 
                        placeholder="Enter acivity title" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="activity_date" 
                        value="<?php echo e(old('activity_date')); ?>" required>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-info">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/activity/add.blade.php ENDPATH**/ ?>