<?php echo $__env->make('website.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="main-panel">
    <div class="content-wrapper">

        <!-- Employee Welcome + Working Hours -->
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0 rounded-4">
                    <div class="card-body d-flex flex-wrap justify-content-between align-items-center">
                        <div>
                            <h4 class="fw-bold text-primary mb-1">Welcome, Rajesh Mali</h4>
                            <p class="text-muted mb-0">Manage your work activities below</p>
                        </div>
                        <div class="text-end mt-3 mt-lg-0">
                            <h6 class="fw-bold text-secondary">Total Working Hours</h6>
                            <h4 class="text-success fw-bold">08:30 Hrs</h4>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="card-footer bg-light border-0 text-center">
                        <div class="d-flex flex-wrap justify-content-center gap-3">
                            <button class="btn btn-success px-4 py-2 rounded-pill shadow-sm">
                                <i class="bi bi-clock me-2"></i> Check In
                            </button>
                            <button class="btn btn-warning px-4 py-2 rounded-pill shadow-sm">
                                <i class="bi bi-cup-hot me-2"></i> Break In
                            </button>
                            <button class="btn btn-info px-4 py-2 rounded-pill shadow-sm text-white">
                                <i class="bi bi-cup-straw me-2"></i> Break Out
                            </button>
                            <button class="btn btn-danger px-4 py-2 rounded-pill shadow-sm">
                                <i class="bi bi-box-arrow-right me-2"></i> Check Out
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Monthly Events + Employee on Leave -->
        <div class="row mb-4">
            <!-- Monthly Events -->
            <div class="col-lg">
                <div class="card shadow-lg border-0 rounded-4 h-100">
                    <div class="card-header text-white rounded-top-4"
                        style="background: linear-gradient(45deg, #28a745, #20c997);">
                        <h6 class="mb-0 fw-bold text-center text-uppercase">Monthly Events</h6>
                    </div>
                    <div class="card-body p-2">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 table-sm">
                                <tbody>
                                    <tr>
                                        <td>05-Aug-2025</td>
                                        <td>Ravi Sharma</td>
                                        <td>Birthday</td>
                                    </tr>
                                    <tr>
                                        <td>12-Aug-2025</td>
                                        <td>Neha Verma</td>
                                        <td>Birthday</td>
                                    </tr>
                                    <tr>
                                        <td>25-Aug-2025</td>
                                        <td>Amit Kumar</td>
                                        <td>Birthday</td>
                                    </tr>
                                    <tr>
                                        <td>28-Aug-2025</td>
                                        <td>Pooja Singh</td>
                                        <td>Birthday</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Employee on Leave -->
            <div class="col-lg-auto mt-4 mt-lg-0">
                <div class="card shadow-lg border-0 rounded-4">
                    <div class="card-header text-white rounded-top-4"
                        style="background: linear-gradient(45deg, #28a745, #20c997);">
                        <h6 class="mb-0 fw-bold text-center text-uppercase">Employees on Leave</h6>
                    </div>
                    <div class="card-body p-2">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 table-sm">
                                <tbody>
                                    <tr>
                                        <td>10-Aug-2025</td>
                                        <td>Rahul Mehta</td>
                                    </tr>
                                    <tr>
                                        <td>14-Aug-2025</td>
                                        <td>Sneha Kapoor</td>
                                    </tr>
                                    <tr>
                                        <td>20-Aug-2025</td>
                                        <td>Vikas Yadav</td>
                                    </tr>
                                    <tr>
                                        <td>27-Aug-2025</td>
                                        <td>Anjali Gupta</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <?php echo $__env->make('website.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/website/index.blade.php ENDPATH**/ ?>