<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch; /* smooth scroll on mobile */
    }

    .table {
        width: max-content; /* table jitni content ho utni width le */
        min-width: 100%; /* kam se kam full width */
        white-space: nowrap; /* wrap nahi hoga */
    }

    .table th,
    .table td {
        vertical-align: middle; /* vertically center */
        white-space: nowrap; /* wrap disable */
        padding: 8px 12px;
    }

    .btn {
        white-space: nowrap;
        padding: 5px 10px;
    }
</style>

<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Manage User</h3>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center reg_success" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Manage User</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Father</th>
                                        <th>Mother</th>
                                        <th>DOB</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Image</th>
                                        <th>Bank Name</th>
                                        <th>Branch</th>
                                        <th>Account No</th>
                                        <th>IFSC</th>
                                        <th>Account Type</th>
                                        <th>Emergency Contacts</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($staff->firstItem() + $index); ?></td>
                                        <td><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></td>
                                        <td><?php echo e($member->father_name ?? '-'); ?></td>
                                        <td><?php echo e($member->mother_name ?? '-'); ?></td>
                                        <td><?php echo e($member->dob ?? '-'); ?></td>
                                        <td><?php echo e($member->mobile ?? '-'); ?></td>
                                        <td><?php echo e($member->email ?? '-'); ?></td>
                                        <td>
                                            <?php if($member->image): ?>
                                                <img src="<?php echo e(asset('uploads/staff/' . $member->image)); ?>" width="50" height="50" class="img-thumbnail">
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($member->bankDetail->bank_name ?? '-'); ?></td>
                                        <td><?php echo e($member->bankDetail->branch_name ?? '-'); ?></td>
                                        <td><?php echo e($member->bankDetail->account_number ?? '-'); ?></td>
                                        <td><?php echo e($member->bankDetail->ifsc_code ?? '-'); ?></td>
                                        <td><?php echo e($member->bankDetail->account_type ?? '-'); ?></td>
                                        <td>
                                            <?php echo e($member->EmergencyContact->name ?? '-'); ?> 
                                            (<?php echo e($member->EmergencyContact->relation ?? '-'); ?>) - 
                                            <?php echo e($member->EmergencyContact->mobile ?? '-'); ?> /
                                            <?php echo e($member->EmergencyContact->alternate_mobile ?? '-'); ?>

                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="<?php echo e(route('edit_staff', base64_encode($member->id))); ?>" class="btn btn-success btn-sm">Edit</a>
                                                <a href="<?php echo e(route('delete_staff', base64_encode($member->id))); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Do you really want to delete this staff?')">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="15" class="text-center">No Staff Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($staff->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/staff/manage.blade.php ENDPATH**/ ?>