<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>HRMS | Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="{{ url('admin/assets/vendors/mdi/css/materialdesignicons.min.css')}}">
    <link rel="stylesheet" href="{{ url('admin/assets/vendors/css/vendor.bundle.base.css')}}">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="{{ url('admin/assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')}}">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="{{ url('admin/assets/css/style.css')}}">
    <!-- endinject -->
    <link rel="shortcut icon" href="{{ url('admin/assets/images/favicon.ico')}}" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.7/js/bootstrap.min.js" 
    integrity="sha512-zKeerWHHuP3ar7kX2WKBSENzb+GJytFSBL6HrR2nPSR1kOX1qjm+oHooQtbDpDBSITgyl7QXZApvDfDWvKjkUw==" 
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="{{route('dashboard')}}">Staff Management</a>
                    
                    <a class="navbar-brand brand-logo-mini" href="{{route('dashboard')}}"><img src="{{ url('admin/assets/images/logo-mini.svg')}}"
                            alt="logo" /></a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                        <span class="mdi mdi-sort-variant"></span>
                    </button>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="{{ url('admin/assets/images/faces/face5.jpg')}}" alt="profile" />
                            <span class="nav-profile-name">Ravi Kumar</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('dashboard')}}">
                            <i class="mdi mdi-home menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#staff" aria-expanded="false" aria-controls="ui-basic">
                            <i class="mdi mdi-account-group menu-icon"></i>
                            <span class="menu-title">Staff</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="staff">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="{{route('add_staff')}}">Add</a></li>
                                <li class="nav-item"> <a class="nav-link" href="{{route('manage_staff')}}">Manage</a></li>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#activity" aria-expanded="false" aria-controls="ui-basic">
                            <i class="mdi mdi-timer menu-icon"></i>
                            <span class="menu-title">Activity</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="activity">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="{{route('add_activity')}}">Add</a></li>
                                <li class="nav-item"> <a class="nav-link" href="{{route('manage_activity')}}">Manage</a></li>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#leave" aria-expanded="false" aria-controls="ui-basic">
                            <i class="mdi mdi-calendar-clock menu-icon"></i>
                            <span class="menu-title">Leave</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="leave">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="{{route('manage_leave')}}">Manage</a></li>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#task_update" aria-expanded="false" aria-controls="ui-basic">
                            <i class="mdi mdi-clipboard-text menu-icon"></i>
                            <span class="menu-title">Task Update</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="task_update">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="{{route('manage_task')}}">Manage Task Update</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </nav>