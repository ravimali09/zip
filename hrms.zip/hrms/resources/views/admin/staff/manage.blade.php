@include('admin.layout.header')

<style>
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch; /* smooth scroll on mobile */
    }

    .table {
        width: max-content; /* table jitni content ho utni width le */
        min-width: 100%; /* kam se kam full width */
        white-space: nowrap; /* wrap nahi hoga */
    }

    .table th,
    .table td {
        vertical-align: middle; /* vertically center */
        white-space: nowrap; /* wrap disable */
        padding: 8px 12px;
    }

    .btn {
        white-space: nowrap;
        padding: 5px 10px;
    }
</style>

<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Manage User</h3>
        </div>

        @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show text-center reg_success" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Manage User</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Father</th>
                                        <th>Mother</th>
                                        <th>DOB</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Image</th>
                                        <th>Bank Name</th>
                                        <th>Branch</th>
                                        <th>Account No</th>
                                        <th>IFSC</th>
                                        <th>Account Type</th>
                                        <th>Emergency Contacts</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($staff as $index => $member)
                                    <tr>
                                        <td>{{ $staff->firstItem() + $index }}</td>
                                        <td>{{ $member->first_name }} {{ $member->last_name }}</td>
                                        <td>{{ $member->father_name ?? '-' }}</td>
                                        <td>{{ $member->mother_name ?? '-' }}</td>
                                        <td>{{ $member->dob ?? '-' }}</td>
                                        <td>{{ $member->mobile ?? '-' }}</td>
                                        <td>{{ $member->email ?? '-' }}</td>
                                        <td>
                                            @if($member->image)
                                                <img src="{{ asset('uploads/staff/' . $member->image) }}" width="50" height="50" class="img-thumbnail">
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td>{{ $member->bankDetail->bank_name ?? '-' }}</td>
                                        <td>{{ $member->bankDetail->branch_name ?? '-' }}</td>
                                        <td>{{ $member->bankDetail->account_number ?? '-' }}</td>
                                        <td>{{ $member->bankDetail->ifsc_code ?? '-' }}</td>
                                        <td>{{ $member->bankDetail->account_type ?? '-' }}</td>
                                        <td>
                                            {{ $member->EmergencyContact->name ?? '-' }} 
                                            ({{ $member->EmergencyContact->relation ?? '-' }}) - 
                                            {{ $member->EmergencyContact->mobile ?? '-' }} /
                                            {{ $member->EmergencyContact->alternate_mobile ?? '-' }}
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="{{ route('edit_staff', base64_encode($member->id)) }}" class="btn btn-success btn-sm">Edit</a>
                                                <a href="{{ route('delete_staff', base64_encode($member->id)) }}" class="btn btn-danger btn-sm" onclick="return confirm('Do you really want to delete this staff?')">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="15" class="text-center">No Staff Found</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            {{ $staff->links('pagination::bootstrap-5') }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@include('admin.layout.footer')
