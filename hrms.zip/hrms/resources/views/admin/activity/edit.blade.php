@include('admin.layout.header')

<div class="main-panel">
    <div class="content-wrapper bg-white">
        @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        <div class="row">
            <div class="col-md-12 stretch-card">
                <form style="width: 100%;" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" class="form-control" id="title" name="title"
                            value="{{ old('title', $activity->title) }}" placeholder="Enter activity title" required>
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="activity_date"
                            value="{{ old('activity_date', $activity->activity_date) }}" required>
                    </div>

                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-info">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@include('admin.layout.footer')