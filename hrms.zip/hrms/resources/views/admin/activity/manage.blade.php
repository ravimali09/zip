@include('admin.layout.header')

<style>
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .table {
        width: 100%;
        white-space: nowrap;
    }

    .table th, .table td {
        vertical-align: middle;
        padding: 8px 12px;
        text-align: center;
    }

    .btn {
        padding: 4px 8px;
        font-size: 14px;
        white-space: nowrap;
    }
</style>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">Manage Activities</h3>
        </div>

        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show text-center">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Activity List</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Activity Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($activities as $index => $activity)
                            <tr>
                                <td>{{ $activities->firstItem() + $index }}</td>
                                <td>{{ $activity->title }}</td>
                                <td>{{ $activity->activity_date }}</td>
                                <td>
                                    <a href="{{ route('edit_activity', base64_encode($activity->id)) }}" class="btn btn-success btn-sm">Edit</a>
                                    <a href="{{ route('delete_activity', base64_encode($activity->id)) }}" 
                                    onclick="return confirm('Do you really want to delete this activity?')" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center">No Activities Found</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    {{ $activities->links('pagination::bootstrap-5') }}
                </div>
            </div>
        </div>
    </div>
</div>

@include('admin.layout.footer')
