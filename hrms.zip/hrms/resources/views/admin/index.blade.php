@include('admin.layout.header')
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between flex-wrap">
                    <div class="d-flex align-items-end flex-wrap">
                        <div class="me-md-3 me-xl-5">
                            <h2>Welcome back, Admin</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          
        </div>
        <!-- content-wrapper ends -->
@include('admin.layout.footer')