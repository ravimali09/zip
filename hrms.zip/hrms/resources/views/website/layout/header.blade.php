<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Staff Management System</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="{{ url('website/assets/vendors/mdi/css/materialdesignicons.min.css') }}">
  <link rel="stylesheet" href="{{ url('website/assets/vendors/css/vendor.bundle.base.css') }}">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="{{ url('website/assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="{{ url('website/assets/css/style.css') }}">

  <!-- custome css -->
  <link rel="stylesheet" href="{{ url('website/custom_css/style.css') }}">

  <!-- endinject -->
  <link rel="shortcut icon" href="{{ url('website/assets/images/favicon.ico') }}" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
          <a class="navbar-brand brand-logo" href="{{route('index')}}">Staff Management</a>
          <a class="navbar-brand brand-logo-white" href="{{route('index')}}"><img src="{{ url('website/assets/images/logo-white.svg')}}"
              alt="logo" /></a>
          <a class="navbar-brand brand-logo-mini" href="{{route('index')}}"><img src="{{ url('website/assets/images/logo-mini.svg')}}"
              alt="logo" /></a>
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-sort-variant"></span>
          </button>
        </div>
      </div>

      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav navbar-nav-right">

          <!-- Notifications -->
          <li class="nav-item dropdown me-4">
            <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown"
              id="notificationDropdown" href="#" data-bs-toggle="dropdown">
              <i class="mdi mdi-bell mx-0"></i>
              <span class="count"></span>
            </a>
          </li>

          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
              <img src="{{ url('website/assets/images/faces/face5.jpg')}}" alt="profile" />
              <span class="nav-profile-name">Rajesh Mali</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a href="#" class="dropdown-item">
                <i class="mdi mdi-account text-primary"></i>
                Edit Profile
              </a>
              <a href="#" class="dropdown-item">
                <i class="mdi mdi-logout text-primary"></i>
                Logout
              </a>
            </div>
          </li>

        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
          data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">

          <!-- Dashboard -->
          <li class="nav-item">
            <a class="nav-link" href="{{route('index')}}">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>

          <!-- Activity section -->
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#activity" aria-expanded="false"
              aria-controls="activity">
              <i class="mdi mdi-clock-time-four-outline menu-icon menu-icon"></i>
              <span class="menu-title">Activity</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="activity">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/dropdowns.html">View Activity</a></li>
              </ul>
            </div>
          </li>

          <!-- leave section -->
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#leave" aria-expanded="false"
              aria-controls="leave">
              <i class="mdi mdi-calendar menu-icon"></i>
              <span class="menu-title">Leave</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="leave">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="{{route('apply_for_leave')}}">Apply For Leave</a></li>
                <li class="nav-item"> <a class="nav-link" href="{{route('leave_summary')}}">Leave Summary</a></li>
              </ul>
            </div>
          </li>

          <!-- task section -->
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#task" aria-expanded="false"
              aria-controls="task">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Task</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="task">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/dropdowns.html">Add Task Update</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Manage Task</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </nav>