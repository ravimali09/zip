<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\ActivityController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\WebController;



Route::get('/index', [WebController::class, 'index'])->name('index');
Route::get('/leave/apply', [LeaveController::class, 'apply_for_leave'])->name('apply_for_leave');
Route::post('/leave/apply', [LeaveController::class, 'store'])->name('store_apply_for_leave');
Route::get('/leave/summary', [LeaveController::class, 'leave_summary'])->name('leave_summary');

// Ammin routes
Route::get('/admin/index', [AdminController::class, 'index'])->name('dashboard');
Route::get('/staff/add', [StaffController::class, 'create'])->name('add_staff');
Route::get('/staff/edit/{id}', [StaffController::class, 'edit'])->name('edit_staff');
Route::post('/staff/edit/{id}', [StaffController::class, 'update'])->name('update_staff');
Route::get('/staff/delete/{id}', [StaffController::class, 'destroy'])->name('delete_staff');
Route::post('/staff/add', [StaffController::class, 'store'])->name('store_staff');
Route::get('/staff/manage', [StaffController::class, 'index'])->name('manage_staff');
Route::get('/activity/add', [ActivityController::class, 'create'])->name('add_activity');
Route::post('/activity/add', [ActivityController::class, 'store'])->name('store_activity');
Route::get('/activity/manage', [ActivityController::class, 'index'])->name('manage_activity');
Route::get('/activity/edit/{id}', [ActivityController::class, 'edit'])->name('edit_activity');
Route::post('/activity/edit/{id}', [ActivityController::class, 'update'])->name('update_activity');
Route::get('/activity/delete/{id}', [ActivityController::class, 'destroy'])->name('delete_activity');
Route::get('/leave/manage', [LeaveController::class, 'index'])->name('manage_leave');
Route::patch('/admin/leave/update-status/{id}', [LeaveController::class, 'updateStatus'])->name('leave_updateStatus');
Route::get('/admin/leave/delete/{id}', [LeaveController::class, 'destroy'])->name('delete_leave');
Route::get('/task/manage', [TaskController::class, 'index'])->name('manage_task');